#include <bits/stdc++.h>

#define int long long
#define N 100100
#define endl '\n'

using namespace std;

int n, m, id[N], rt, cnt, ch[N][2], fa[N], siz[N], key[N], val[N];

inline int read(){int x=0,f=1;char ch=getchar();while(!isdigit(ch)){f=ch!='-';ch=getchar();}while(isdigit(ch)){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}return f?x:-x;}

inline void push_up(int x) {siz[x] = 1 + siz[ch[x][0]] + siz[ch[x][1]];}

inline int node(int x)
{
	cnt ++;
	val[cnt] = x;
	key[cnt] = rand();
	siz[cnt] = 1;
	id[x] = cnt;//记录当前值在平衡树中的结点中的编号
	return cnt ;
}

inline void split(int x, int k, int &xx, int &yy, int fx = 0, int fy = 0)
{
	if(x == 0) return xx = yy = 0, void();//下面要维护父节点的信息 
	if(siz[ch[x][0]] + 1 <= k) fa[x] = fx, xx = x, split(ch[x][1], k - siz[ch[x][0]] - 1, ch[x][1], yy, x, fy);
	else fa[x] = fy, yy = x, split(ch[x][0], k, xx, ch[x][0], fx, x);
	push_up(x);
}
 
inline int merge(int x, int y)
{
	if(! x || ! y) return x + y;
	if(key[x] < key[y])
	{
		ch[x][1] = merge(ch[x][1], y);
		fa[ch[x][1]] = x;//维护父节点的信息 
		push_up(x);
		return x;
	}
	else
	{
		ch[y][0] = merge(x, ch[y][0]);
		fa[ch[y][0]] = y; 
		push_up(y);
		return y;
	}
}

inline int fid(int x)//查找当前编号的书上面有多少本书 
{
	int xx = x, res = siz[ch[x][0]] + 1;
	while(xx != rt && x)
	{
		if(ch[fa[x]][1] == x) res += siz[ch[fa[x]][0]] + 1;
		x = fa[x];
	}
	return res;
}

signed main()
{
	srand((unsigned)time(NULL));
	string op;
	n = read(), m = read();
	for(int i = 1; i <= n; i ++)
	{
		int a = read();
		rt = merge(rt, node(a));
	}
	for(int i = 1; i <= m; i ++)
	{
		int x, y, z, z1, k, o;
		cin >> op;
		o = read();
//		if(op[0] != 'Q')
//			cout << "find:" << fid(id[o]) << endl;
		if(op[0] == 'T')
		{
			int xx = fid(id[o]);//找到上面有几本书之后按排名分裂 
			split(rt, xx, x, y);
			split(x, xx - 1, x, z);
			rt = merge(z, merge(x, y));//把当前编号的书放到顶端 
		}
		if(op[0] == 'B')
		{
			int xx = fid(id[o]);//同理把当前编号的书放到最下面 
			split(rt, xx, x, y, 0);
			split(x, xx - 1, x, z, 0);
			rt = merge(merge(x, y), z);
		}
		if(op[0] == 'I')
		{
			k = read();
			int xx = fid(id[o]);
			if(k == 0) continue;//放回原位就直接跳过 
			if(k == 1)//上面的书多了一本 
			{
				split(rt, xx + 1, x, y);//相当于和在平衡树中的后继互换位置 
				split(x, xx, x, z);
				split(x, xx - 1, x, z1);
				rt = merge(merge(merge(x, z), z1), y);
			}
			if(k == -1)//上面的书少了一本 
			{
				split(rt, xx, x, y);//相当于和在平衡树中的前驱互换位置 
				split(x, xx - 1, x, z);
				split(x, xx - 2, x, z1);
				rt = merge(merge(merge(x, z), z1), y);
			}
		}
		if(op[0] == 'A')
		{
			int xx = fid(id[o]);//查找上面有多少本书 
			cout << xx - 1 << endl;//因为里面的是包含自己的，所以要减去 
		}
		if(op[0] == 'Q')
		{
			split(rt, o, x, y);//按照o的排名分裂 
			int xx = x;
			while(ch[xx][1]) xx = ch[xx][1];//一直跳到最大值 
			cout << val[xx] << endl;
			rt = merge(x, y);
		}
	}
	return 0;
}
