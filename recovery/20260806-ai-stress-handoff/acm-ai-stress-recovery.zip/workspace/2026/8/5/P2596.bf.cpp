#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, m;
    cin >> n >> m;
    vector<int> a(n);
    for (int i = 0; i < n; ++i) cin >> a[i];

    auto findPos = [&](int id) -> int {
        for (int i = 0; i < n; ++i) {
            if (a[i] == id) return i;
        }
        return -1;
    };

    string op;
    for (int i = 0; i < m; ++i) {
        cin >> op;
        if (op == "Top") {
            int s;
            cin >> s;
            int pos = findPos(s);
            int val = a[pos];
            a.erase(a.begin() + pos);
            a.insert(a.begin(), val);
        } else if (op == "Bottom") {
            int s;
            cin >> s;
            int pos = findPos(s);
            int val = a[pos];
            a.erase(a.begin() + pos);
            a.push_back(val);
        } else if (op == "Insert") {
            int s, t;
            cin >> s >> t;
            int pos = findPos(s);
            if (t == -1) {
                swap(a[pos - 1], a[pos]);
            } else if (t == 1) {
                swap(a[pos], a[pos + 1]);
            }
        } else if (op == "Ask") {
            int s;
            cin >> s;
            cout << findPos(s) << '\n';
        } else if (op == "Query") {
            int s;
            cin >> s;
            cout << a[s - 1] << '\n';
        }
    }

    return 0;
}
