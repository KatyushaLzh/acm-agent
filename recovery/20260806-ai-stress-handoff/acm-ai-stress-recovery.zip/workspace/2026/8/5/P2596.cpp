#include <bits/stdc++.h>

using ll = long long;
using pii = std::pair <int, int>;

constexpr int MAXN = 8e4 + 5;
std::mt19937 Rand(time(0));

struct FHQ{
    struct Node {
        int ls, rs, val, siz, rnd, fa;
    }t[MAXN];
    void pushup(int p) {
        t[p].siz = t[t[p].ls].siz + t[t[p].rs].siz + 1;
    }
    void split(int now, int k, int &x, int &y, int fax, int fay) {
        if (!now) {
            x = y = 0;
            return;
        }
        if (t[t[now].ls].siz + 1 <= k) {
            x = now;
            t[now].fa = fax;
            split(t[now].rs, k - t[t[now].ls].siz - 1, t[now].rs, y, now, fay);
        }
        else {
            y = now;
            t[now].fa = fay;
            split(t[now].ls, k, x, t[now].ls, fax, now);
        }
        pushup(now);
    }
    int merge(int u, int v) {
        if (!u || !v) return u + v;
        if (t[u].rnd < t[v].rnd) {
            int _v = merge(t[u].rs, v);
            t[u].rs = _v;
            t[_v].fa = u;
            pushup(u);
            return u;
        }
        int _u = merge(u, t[v].ls);
        t[v].ls = _u;
        t[_u].fa = v;
        pushup(v);
        return v;
    }
    int get_rank(int x) {
        int ret = t[t[x].ls].siz;
        while (t[x].fa) {
            int fa = t[x].fa;
            if (t[fa].rs == x) ret += t[t[fa].ls].siz + 1;
            x = t[x].fa; 
        }
        return ret + 1;
    }
    int New(int a) {
        t[a].siz = 1; t[a].val = a; t[a].rnd = Rand();
        return a;
    }
    int rt;
    void build(int n, std::vector <int> &a) {
        for (int i = 1; i <= n; i++) {
            rt = merge(rt, New(a[i]));
        }
    }
    void Top(int a) {
        int x, y, z;
        int rk = get_rank(a);
        split(rt, rk - 1, x, y, 0, 0);
        split(y, 1, y, z, 0, 0);
        rt = merge(merge(y, x), z);
    }
    void Bottom(int a) {
        int x, y, z;
        int rk = get_rank(a);
        split(rt, rk - 1, x, y, 0, 0);
        split(y, 1, y, z, 0, 0);
        rt = merge(merge(x, z), y);        
    }
    void Insert(int a, int t) {
        int x, y, z, w;
        int rk = get_rank(a);
        if (t == -1) {
            split(rt, rk - 2, x, y, 0, 0);
            split(y, 1, y, z, 0, 0);
            split(z, 1, z, w, 0 ,0);
            rt = merge(merge(x, z), merge(y, w));
        }      
        else if (t == 1){
            split(rt, rk - 1, x, y, 0, 0);
            split(y, 1, y, z, 0, 0);
            split(z, 1, z, w, 0, 0);
            rt = merge(merge(x, z), merge(y, w));
        }
    }
    int Ask(int a) {
        return get_rank(a) - 1;
    }
    int kth(int now, int k) {
        if (k <= t[t[now].ls].siz) return kth(t[now].ls, k);
        if (t[t[now].ls].siz + 1 < k) return kth(t[now].rs, k - t[t[now].ls].siz - 1);
        return t[now].val;
    }
    int Query(int a) {
        return kth(rt, a);
    }
}t;

void solve() {
    int n, m;
    std::cin >> n >> m;
    std::vector <int> a(n + 1);
    for (int i = 1; i <= n; i++) std::cin >> a[i];
    t.build(n, a);
    while (m--) {
        std::string op;
        int s, v;
        std::cin >> op >> s;
        if (op == "Top") {
            t.Top(s);
        }
        if (op == "Bottom") {
            t.Bottom(s);
        }
        if (op == "Insert") {
            std::cin >> v;
            t.Insert(s, v);
        }
        if (op == "Ask") {
            std::cout << t.Ask(s) << '\n';
        }
        if (op == "Query") {
            std::cout << t.Query(s) << '\n';
        }
    }
}

int main() {
    std::ios::sync_with_stdio(0);
    std::cin.tie(0);
    std::cout.tie(0);

    int T = 1;
    // std::cin >> T;
    while (T--) {
        solve();
    }

    return 0;
}