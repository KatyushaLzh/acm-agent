#include <bits/stdc++.h>
using namespace std;

static uint64_t splitmix64(uint64_t x) {
    x += 0x9e3779b97f4a7c15ULL;
    x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ULL;
    x = (x ^ (x >> 27)) * 0x94d049bb133111ebULL;
    return x ^ (x >> 31);
}

struct Gen {
    uint64_t seed;
    Gen(uint64_t s) : seed(s) {}
    uint64_t next() {
        seed = splitmix64(seed);
        return seed;
    }
    int rand_int(int lo, int hi) {
        uint64_t r = next();
        return lo + (int)(r % (uint64_t)(hi - lo + 1));
    }
};

struct Op {
    string name;
    int a, b;
};

int main(int argc, char** argv) {
    if (argc == 2 && string(argv[1]) == "--capabilities") {
        cout << "{\"profile_version\":2,\"profiles\":[\"small\",\"large\"],\"case_kinds\":[\"lower_bound\",\"upper_bound\",\"random\"]}";
        return 0;
    }
    if (argc < 4) return 1;
    uint64_t seed = strtoull(argv[1], nullptr, 10);
    string profile = argv[2];
    string kind = argv[3];
    Gen gen(seed);

    int n, m;
    vector<int> init;
    vector<Op> ops;

    if (profile == "small") {
        if (kind == "lower_bound") {
            n = 3; m = 3;
            init = {1,2,3};
            ops = {{"Top",3,0}, {"Insert",1,1}, {"Query",2,0}};
        } else if (kind == "upper_bound") {
            n = 8; m = 10;
            init = {1,2,3,4,5,6,7,8};
            ops = {
                {"Top",8,0}, {"Bottom",1,0}, {"Insert",2,-1}, {"Insert",3,1},
                {"Ask",1,0}, {"Query",1,0}, {"Ask",8,0}, {"Query",8,0},
                {"Insert",4,0}, {"Top",5,0}
            };
        } else { // random
            n = gen.rand_int(3,8);
            m = gen.rand_int(3,10);
            init.resize(n);
            iota(init.begin(), init.end(), 1);
            for (int i = n-1; i > 0; --i) {
                int j = gen.rand_int(0,i);
                swap(init[i], init[j]);
            }
            vector<int> cur = init;
            vector<int> pos(n+1);
            for (int i=0;i<n;i++) pos[cur[i]]=i;
            for (int i=0;i<m;i++) {
                int type = gen.rand_int(0,4);
                if (type == 0) { // Top
                    int s = gen.rand_int(1,n);
                    ops.push_back({"Top",s,0});
                    int idx = pos[s];
                    cur.erase(cur.begin()+idx);
                    cur.insert(cur.begin(),s);
                    for (int j=0;j<n;j++) pos[cur[j]]=j;
                } else if (type == 1) { // Bottom
                    int s = gen.rand_int(1,n);
                    ops.push_back({"Bottom",s,0});
                    int idx = pos[s];
                    cur.erase(cur.begin()+idx);
                    cur.push_back(s);
                    for (int j=0;j<n;j++) pos[cur[j]]=j;
                } else if (type == 2) { // Insert
                    int s = gen.rand_int(1,n);
                    int idx = pos[s];
                    int t;
                    if (idx == 0) t = gen.rand_int(0,1);
                    else if (idx == n-1) t = gen.rand_int(-1,0);
                    else t = gen.rand_int(-1,1);
                    ops.push_back({"Insert",s,t});
                    if (t == -1) {
                        swap(cur[idx-1], cur[idx]);
                    } else if (t == 1) {
                        swap(cur[idx], cur[idx+1]);
                    }
                    for (int j=0;j<n;j++) pos[cur[j]]=j;
                } else if (type == 3) { // Ask
                    int s = gen.rand_int(1,n);
                    ops.push_back({"Ask",s,0});
                } else { // Query
                    int s = gen.rand_int(1,n);
                    ops.push_back({"Query",s,0});
                }
            }
        }
    } else { // large
        if (kind == "upper_bound") {
            n = 80000; m = 80000;
            init.resize(n);
            for (int i=0;i<n;i++) init[i] = n-i;
            for (int i=0;i<m;i++) {
                int s = (i % n) + 1;
                int type = i % 5;
                if (type == 0) ops.push_back({"Top",s,0});
                else if (type == 1) ops.push_back({"Ask",s,0});
                else if (type == 2) ops.push_back({"Query",s,0});
                else if (type == 3) ops.push_back({"Bottom",s,0});
                else ops.push_back({"Insert",s,0});
            }
        } else { // random
            n = gen.rand_int(64000,80000);
            m = gen.rand_int(64000,80000);
            init.resize(n);
            iota(init.begin(), init.end(), 1);
            for (int i=n-1;i>0;i--) {
                int j = gen.rand_int(0,i);
                swap(init[i], init[j]);
            }
            for (int i=0;i<m;i++) {
                int s = gen.rand_int(1,n);
                int type = gen.rand_int(0,4);
                if (type == 0) ops.push_back({"Top",s,0});
                else if (type == 1) ops.push_back({"Bottom",s,0});
                else if (type == 2) ops.push_back({"Ask",s,0});
                else if (type == 3) ops.push_back({"Query",s,0});
                else ops.push_back({"Insert",s,0});
            }
        }
    }

    // Output
    cout << n << " " << m << "\n";
    for (int i=0;i<n;i++) {
        if (i) cout << " ";
        cout << init[i];
    }
    cout << "\n";
    for (auto &op : ops) {
        cout << op.name;
        if (op.name == "Insert") cout << " " << op.a << " " << op.b;
        else cout << " " << op.a;
        cout << "\n";
    }
    return 0;
}
