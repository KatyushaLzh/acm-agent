﻿# Errors

Unexpected command failures, integration failures, tool/API issues, and environment gotchas specific to this workspace.

Log only redacted summaries and minimal context. Do not paste secret-bearing output, full command transcripts, or private configuration.

---

## [ERR-20260806-003] application_cold_summary_optional_cleanup_field

**Logged**: 2026-08-06T17:57:54+08:00
**Priority**: low
**Status**: resolved
**Area**: tests

### Summary
20 次 application-cold 已成功落盘后，临时汇总脚本把可选的 `cleanup_worker_ids` 当成必需字段，导致最终打印阶段 `KeyError`。

### Error
```text
KeyError: 'cleanup_worker_ids'
```

### Context
- 真实 20 次执行已经结束，`attempts.jsonl`、CSV、summary 和 Markdown 均完整存在。
- application-cold 的成功结果以 `application_cold=true` 和临时目录清理检查为契约，不保证每条派生 row 都携带 `cleanup_worker_ids`。

### Suggested Fix
汇总可选字段时使用 `.get()`，并以报告 JSONL 加独立临时目录/进程扫描复核清理，不要因展示层异常重跑昂贵批次。

### Metadata
- Reproducible: yes
- Related Files: tools/acm_agent/stress_benchmark.py
- See Also: ERR-20260806-001
- Pattern-Key: acm.stress.application-cold-summary-schema

### Resolution
- **Resolved**: 2026-08-06T17:59:00+08:00
- **Notes**: 从已落盘的 20 条 JSONL 重新计算成功率和分位数，并独立确认临时目录与相关进程均为 0；未重复执行批次。

---

## [ERR-20260806-002] token_budget_exception_constructor_recursion

**Logged**: 2026-08-06T17:12:00+08:00
**Priority**: high
**Status**: resolved
**Area**: backend

### Summary
100k provider-token 硬上限首次触发时，子异常通过 `super().__init__(budget, stage)` 进入父类构造路径，无法稳定保留专用 code/details/usage。

### Error
```text
PreparationTokenBudgetExhausted did not construct the dedicated token-limit error payload
```

### Context
- token 上限可能在发请求前或记录响应 usage 后触发，两条路径都必须抛出相同专用异常。
- 该子类需要复用 `RuntimeError` 文本初始化，但自行构造 token limit details 与完整累计 usage，不能调用按 wall-clock deadline 解释参数的父类构造器。

### Suggested Fix
显式调用 `RuntimeError.__init__`，随后设置 `provider_token_limit`、`provider_tokens_used`、stage/context 和 budget snapshot usage；分别测试“达到上限后禁止未来请求”和“响应令累计越界”两条路径。

### Metadata
- Reproducible: yes
- Related Files: tools/acm_agent/stress_budget.py, tests/test_stress_budget.py
- Pattern-Key: acm.ai-stress.token-budget-exception-constructor

### Resolution
- **Resolved**: 2026-08-06T17:12:00+08:00
- **Notes**: 专用异常构造已独立实现；两条 100k 硬上限测试及全仓 429 项测试通过。

---

## [ERR-20260806-001] application_cold_outer_timeout_lost_summary

**Logged**: 2026-08-06T17:10:00+08:00
**Priority**: medium
**Status**: resolved
**Area**: tooling

### Summary
20 次 application-cold 的外层 shell timeout 设为 600 秒，批次尚未完成时失去 stdout 汇总，但被启动的 Python 子进程仍继续执行。

### Error
```text
command timed out after 604021 milliseconds
```

### Context
- 批次单次约 40 秒，20 次实测总墙钟约 13 分钟；600 秒不足以覆盖整批。
- 外层返回后，临时目录从 attempt 15 继续推进到 attempt 19，说明不能把 shell timeout 当成子进程已停止。
- 没有并发启动第二批；等待原子进程自然结束并确认临时目录、helper/compiler 进程归零后，使用 1200 秒外层上限重跑并取得完整统计。

### Suggested Fix
长批次外层 timeout 必须按“单次 max × 次数 + 清理余量”设置，或让 runner 每次 attempt 追加 durable journal；外层 timeout 后先枚举实际子进程和临时目录，禁止立即重复启动或对已自动清理的路径继续递归删除。

### Metadata
- Reproducible: yes
- Related Files: tools/acm_agent/stress_benchmark.py
- Pattern-Key: acm.stress.application-cold-outer-timeout

### Resolution
- **Resolved**: 2026-08-06T17:10:00+08:00
- **Notes**: 重新以 1200 秒外层上限完成 20/20；0 requests、0 tokens，p50 40.31 秒、p95 44.61 秒、max 45.28 秒，且无临时目录或相关进程残留。

---

## [ERR-20260805-003] deepseek_connection_reset_10054

**Logged**: 2026-08-05T15:10:00+08:00
**Priority**: high
**Status**: resolved
**Area**: infra

### Summary
AI 持续对拍连续三次在契约提取阶段遭遇 Windows 10054 连接重置，协议重试耗尽后无法继续。

### Error
```text
network_error: DeepSeek network request failed: WinError 10054
```

### Context
- 三次 `stress_setup` 均在第 2 阶段失败，题面仅约 2.8 KiB，未创建新 bundle 或 run。
- 每次请求已经执行初次调用和两次指数退避重试，因此继续增加无界重试不构成修复。
- 先前同一 API 能返回 JSON；连接重置发生在 Dashboard 重启后的网络上下文中，仍需用户侧最小连接测试确认代理/VPN或提供商瞬时故障。

### Suggested Fix
保持最多两次重试，向 Job 进度报告当前阶段内的连接重试，并在耗尽时明确标记；若最小 AI 测试也失败，则检查本机代理/VPN并从正常用户启动脚本重启服务，不修改 endpoint 或关闭 TLS 校验。

### Metadata
- Reproducible: yes
- Related Files: tools/acm_agent/deepseek.py, tools/acm_agent/stress_ai.py, tools/acm_agent/web.py
- See Also: ERR-20260805-002
- Pattern-Key: acm.deepseek.windows-connection-reset

### Resolution
- **Resolved**: 2026-08-05T16:05:00+08:00
- **Notes**: 分层检查确认 DNS、直连 TCP、Clash 代理、TLS/HTTP 与网页端最小 DeepSeek 调用均正常；10054 属于先前瞬时连接重置，并非持续的本机断网或证书故障。后续长生成失败另由 60 秒读取超时导致，见 ERR-20260805-004。

---

## [ERR-20260805-004] deepseek_stress_long_read_timeout

**Logged**: 2026-08-05T16:05:00+08:00
**Priority**: high
**Status**: resolved
**Area**: backend

### Summary
最小 DeepSeek 测试持续成功，但 thinking 模式的 generator 长请求超过通用 60 秒读取超时，重试耗尽后没有创建 helper 或 stress run。

### Error
```text
DeepSeek response read failed: The read operation timed out (automatic retries exhausted: 2)
```

### Context
- 契约提取已成功，失败稳定发生在第 3 阶段 generator，说明不是 API Key、DNS 或代理完全不可用。
- 普通连接测试只生成极短回复，不能证明长代码生成会在 60 秒内完成。
- 洛谷题解源被白名单校验拒绝时也曾直接终止整条准备流程，未继续固定来源顺序与 AI fallback。

### Suggested Fix
为显式 opt-in 的 stress 准备单独使用较长但有界的读取超时，保留普通 AI 请求的短超时；单个白名单来源失败应作为该层无结果继续下一层，不能放宽 URL 安全校验。

### Metadata
- Reproducible: yes
- Related Files: tools/acm_agent/service.py, tools/acm_agent/stress_ai.py
- See Also: ERR-20260805-002, ERR-20260805-003
- Pattern-Key: acm.deepseek.short-probe-long-generation-timeout

### Resolution
- **Resolved**: 2026-08-05T16:05:00+08:00
- **Notes**: 后续进一步改为用户可配 60–1800 秒、默认 300 秒的全准备绝对 deadline；连接、响应读取、重试和 JSON 恢复不再重置等待窗口，stress 固定 non-thinking，来源抓取与本地门禁也受同一 deadline 约束。

---

## [ERR-20260805-002] deepseek_stress_empty_json

**Logged**: 2026-08-05T14:45:00+08:00
**Priority**: high
**Status**: resolved
**Area**: backend

### Summary
AI 持续对拍在契约提取阶段等待数分钟后因 DeepSeek JSON Output 空正文退出，未创建 helper、bundle 或 run。

### Error
```text
invalid_json_output: DeepSeek JSON Output was empty
```

### Context
- 两次实际 `stress_setup` 审计记录均在相同题目的契约阶段失败。
- 原客户端对空正文使用完全相同的 thinking 请求重试，容易再次耗尽推理/输出预算。
- 后台 Job 没有阶段字段，网页只能长期显示“AI 准备中”。

### Suggested Fix
JSON 空正文最多重试一次时改用明确输出提醒和 non-thinking 请求；后台长任务持久暴露受控阶段进度，并在失败中保留最后阶段。

### Metadata
- Reproducible: yes
- Related Files: tools/acm_agent/deepseek.py, tools/acm_agent/stress_ai.py, tools/acm_agent/web.py, tools/acm_agent/web_static/app.js
- Pattern-Key: acm.deepseek.json-empty-stage-progress

### Resolution
- **Resolved**: 2026-08-05T14:45:00+08:00
- **Notes**: 加入 non-thinking JSON 恢复、阶段化进度和绝对 deadline；contract 另有本地验证缓存，完整 warm bundle 直接做到零 provider 请求，因此官方偶发空 content 不再迫使相同准备重复消费 token。

---

## [ERR-20260804-001] windows_native_subprocess_decoding

**Logged**: 2026-08-04T23:59:45+08:00
**Priority**: medium
**Status**: resolved
**Area**: tests

### Summary
Windows 原生命令输出按 Python UTF-8 文本模式读取时，后台 reader 线程可能抛出解码异常，即使测试主线程仍返回成功。

### Error
```text
UnicodeDecodeError: 'utf-8' codec can't decode byte ...
```

### Context
- Web 测试创建运行时文件时会调用 `whoami` 和 `icacls`。
- 正式仓库完整测试的断言全部通过，但原生命令的本地代码页输出污染了日志。

### Suggested Fix
读取只用于状态和短诊断的 Windows 原生命令输出时设置 `errors="replace"`，并继续以退出码判断 ACL 操作是否成功。

### Metadata
- Reproducible: yes
- Related Files: tools/acm_agent/web.py
- Pattern-Key: windows.native_subprocess_decode

### Resolution
- **Resolved**: 2026-08-04T23:59:45+08:00
- **Notes**: 两个 ACL 辅助命令均使用容错文本解码；22 项 Web/HTTP E2E 复跑无后台线程异常。

---

## [ERR-20260721-005] firecrawl_skill_reference_resolution

**Logged**: 2026-07-21T12:00:00+08:00
**Priority**: low
**Status**: resolved
**Area**: docs

### Summary
The Firecrawl skill referenced a sibling `firecrawl-scrape` skill path that is not installed in this environment.

### Error
```text
Cannot find path 'C:\\Users\\Lenovo\\.agents\\skills\\firecrawl-scrape\\SKILL.md'
```

### Context
- The task only needed to scrape a known URL.
- The main Firecrawl skill and its security guidance were available, so the required scrape flow remained clear.

### Suggested Fix
Resolve referenced sibling-skill paths before reading them, and proceed from the primary skill when the referenced supplemental guide is absent.

### Metadata
- Reproducible: yes
- Related Files: .learnings/ERRORS.md
- Pattern-Key: firecrawl.missing_supplemental_skill_reference

---

## [ERR-20260721-001] powershell_rg_stderr_encoding

**Logged**: 2026-07-21T00:00:00+08:00
**Priority**: low
**Status**: pending
**Area**: infra

### Summary
PowerShell failed to launch `rg.exe` when stderr was redirected because of a standard-error encoding compatibility issue.

### Error
```text
StandardErrorEncoding is only supported when standard error is redirected.
```

### Context
- A read-only search of project and global learning files was attempted from PowerShell.
- Native PowerShell `Select-String` was used as the fallback and completed successfully.

### Suggested Fix
Use PowerShell-native text search for this environment when `rg.exe` is combined with stderr redirection, or run `rg` without the incompatible redirection.

### Metadata
- Reproducible: unknown
- Related Files: .learnings/ERRORS.md
- Pattern-Key: powershell.rg_stderr_encoding

---

## [ERR-20260720-001] local_presentation_text_extraction

**Logged**: 2026-07-20T00:00:00+08:00
**Priority**: low
**Status**: resolved
**Area**: docs

### Summary
The local environment does not expose LibreOffice, Soffice, or Pandoc; direct PPTX XML extraction also needs explicit UTF-8 output for multilingual slides.

### Context
- Attempted to discover local presentation converters while inspecting `camp/*.pptx`.
- `Get-Command` found only Python; the XML extractor then hit the Windows GBK console encoding on Cyrillic text.

### Resolution
- Use ZIP/XML extraction with `sys.stdout.reconfigure(encoding='utf-8')` for read-only content inventory.

### Metadata
- Reproducible: yes
- Related Files: camp
- Pattern-Key: windows.pptx.xml_console_encoding

---

## [ERR-20260720-002] workspace_git_assumption

**Logged**: 2026-07-20T00:00:00+08:00
**Priority**: low
**Status**: resolved
**Area**: config

### Summary
`D:\code\acm` is not a Git working tree, so repository-status checks must be conditional.

### Context
- A read-only status check returned `fatal: not a git repository` while preparing research cache files.

### Resolution
- Verify the repository marker before running Git status; treat this workspace as a plain local directory when absent.

### Metadata
- Reproducible: yes
- Related Files: D:\code\acm
- Pattern-Key: workspace.git.optional

---

## [ERR-20260720-003] firecrawl_json_code_fence

**Logged**: 2026-07-20T00:00:00+08:00
**Priority**: low
**Status**: resolved
**Area**: docs

### Summary
Firecrawl serializes a scraped JSON API body inside a Markdown fenced code block rather than as the direct JSON payload.

### Context
- Parsing the `markdown` field from the Codeforces problemset API scrape directly with `json.loads` failed at the opening code fence.

### Resolution
- Strip the enclosing ` ```json ` and closing fence before decoding the API body.

### Metadata
- Reproducible: yes
- Related Files: .firecrawl\codeforces-problemset.json
- Pattern-Key: firecrawl.scrape.json_code_fence

---

## [ERR-20260720-004] presentations_imported_deck_reference_path

**Logged**: 2026-07-20T00:00:00+08:00
**Priority**: low
**Status**: resolved
**Area**: docs

### Summary
The presentation API index points to an imported-deck reference path that is absent from this installed package layout.

### Context
- `artifact_tool/references/cookbook/imported-deck.md` could not be read while preparing a template-following deck.

### Suggested Fix
- Locate the installed reference before relying on its path; use the template-following scripts as the canonical workflow.

### Metadata
- Reproducible: yes
- Related Files: presentations skill artifact_tool references
- Pattern-Key: presentations.imported_reference_path

---

## [ERR-20260720-005] presentations_artifact_runtime_resolution

**Logged**: 2026-07-20T00:00:00+08:00
**Priority**: medium
**Status**: resolved
**Area**: docs

### Summary
The presentation template inspection script searched for the bundled artifact-tool package under the workspace cache path, where the package is absent.

### Context
- `inspect_template_deck.mjs` failed before inspecting the source PPTX because `D:\code\acm\.cache\codex-runtimes\...\@oai\artifact-tool` has no package manifest.

### Suggested Fix
- Load the Codex workspace dependency paths and configure the script to use the valid bundled runtime.

### Resolution
- Linked the workspace cache path to the configured bundled runtime for the presentation commands, then removed that temporary junction after QA.

### Metadata
- Reproducible: yes
- Related Files: template_following_scripts\inspect_template_deck.mjs
- Pattern-Key: presentations.artifact_runtime_resolution

---

## [ERR-20260720-006] presentations_starter_contact_sheet_option

**Logged**: 2026-07-20T00:00:00+08:00
**Priority**: low
**Status**: resolved
**Area**: docs

### Summary
The template-starter script crashes in its optional contact-sheet path despite successfully writing the starter PPTX and inspection artifact.

### Context
- `prepare_template_starter_deck.mjs` raised `Cannot read properties of undefined (reading 'trim')` in `runContactSheet` when passed `--contact-sheet`.

### Resolution
- Run the documented starter creation without the optional contact-sheet flag, then create the review sheet separately with the bundled montage utility.

### Metadata
- Reproducible: yes
- Related Files: template_following_scripts\prepare_template_starter_deck.mjs
- Pattern-Key: presentations.starter_contact_sheet_option

---

## [ERR-20260720-007] presentations_duplicate_slide_object_ids

**Logged**: 2026-07-20T00:00:00+08:00
**Priority**: low
**Status**: resolved
**Area**: docs

### Summary
Duplicating template slides remaps inherited artifact-tool object IDs, so source-deck IDs cannot be used for edits in the generated starter deck.

### Context
- The imported starter deck reported `Unknown element aid` when the builder resolved a source-slide text ID.

### Resolution
- Bind edits to the IDs from `template-starter.pptx.inspect.ndjson`, not the source-deck inspection.

### Metadata
- Reproducible: yes
- Related Files: tmp\template-starter.pptx.inspect.ndjson
- Pattern-Key: presentations.duplicate_slide_object_ids

---

## [ERR-20260720-008] presentations_template_canvas_overflow_check

**Logged**: 2026-07-20T00:00:00+08:00
**Priority**: low
**Status**: resolved
**Area**: docs

### Summary
Canvas-overflow QA flagged the duplicated title slide; the result must be compared with the source template before treating it as a new clipping defect.

### Context
- `slides_test.py` reported only final slide 1 after all content edits.

### Suggested Fix
- Run the same checker on the unmodified source template and inspect the generated padded render.

### Resolution
- The unmodified source template triggers the identical slide-1 overflow report; the duplicate inherited the template's edge-boundary geometry and the final render has no visible clipping.

### Metadata
- Reproducible: unknown
- Related Files: camp\HEU_ACM_Summer_Camp_CPP_Complex_Branches_and_Loops_EN.pptx
- Pattern-Key: presentations.template_canvas_overflow_check

---

## [ERR-20260720-009] firecrawl_scrape_feedback_command

**Logged**: 2026-07-20T00:00:00+08:00
**Priority**: low
**Status**: resolved
**Area**: docs

### Summary
The installed Firecrawl CLI does not expose the documented `feedback` subcommand for scrape jobs.

### Context
- `firecrawl feedback scrape <id>` returned `unknown command 'feedback'` after two official Codeforces scrapes.

### Resolution
- Kept the cached scrape results and did not retry with an unsupported command; search-feedback remains separately supported.

### Metadata
- Reproducible: yes
- Related Files: .firecrawl
- Pattern-Key: firecrawl.scrape_feedback_command

---

## [ERR-20260721-002] windows_keyboard_diagnostic_provider_access

**Logged**: 2026-07-21T00:00:00+08:00
**Priority**: low
**Status**: pending
**Area**: infra

### Summary
Some read-only Windows keyboard diagnostics returned non-zero because CIM/PnP provider access was unavailable or the optional device query produced no records.

### Error
```text
Get-CimInstance: 拒绝访问
Get-PnpDevice: no keyboard records returned; command exited with code 1
```

### Context
- Process and registry evidence was available through `Get-Process`, `Get-Service`, and `Get-ItemProperty`.
- The failed provider queries were not required for the diagnosis.

### Suggested Fix
Prefer registry/service/process evidence for non-elevated keyboard triage; only use CIM/PnP queries when the session has the required provider permissions.

### Metadata
- Reproducible: unknown
- Related Files: .learnings/ERRORS.md
- Pattern-Key: windows.diagnostic_provider_access

---

## [ERR-20260721-003] firecrawl_search_shell_quoting

**Logged**: 2026-07-21T00:00:00+08:00
**Priority**: low
**Status**: resolved
**Area**: infra

### Summary
An escaped quoted Firecrawl search query was parsed as multiple CLI arguments.

### Error
```text
error: too many arguments for 'search'. Expected 1 argument but got 3.
```

### Context
- The query was retried with PowerShell single-quoted argument syntax and completed successfully.

### Suggested Fix
Use one PowerShell single-quoted argument for Firecrawl queries containing literal quotation marks.

### Metadata
- Reproducible: yes
- Related Files: .learnings/ERRORS.md
- Pattern-Key: firecrawl.search_shell_quoting

---

## [ERR-20260721-004] git_diff_workspace_detection

**Logged**: 2026-07-21T00:00:00+08:00
**Priority**: low
**Status**: resolved
**Area**: infra

### Summary
The workspace-level verification command could not run `git diff` because the current directory is not recognized as a Git worktree by the shell session.

### Error
```text
warning: Not a git repository. Use --no-index to compare two paths outside a working tree
```

### Context
- The command was only intended to verify that diagnostic logging was the sole workspace edit.
- No source or configuration files were modified.

### Suggested Fix
Check the repository root with `git rev-parse --show-toplevel` before running diff verification; use direct file read-back when the workspace is not a worktree.

### Metadata
- Reproducible: unknown
- Related Files: .learnings/ERRORS.md
- Pattern-Key: workspace.git_diff_root_detection

---

## [ERR-20260805-001] acm_runtime_schema_copy_drift

**Logged**: 2026-08-05T19:00:00+08:00
**Priority**: high
**Status**: resolved
**Area**: infra

### Summary
正式仓库已升级 schema v7，但本地启动工作区仍加载只支持 schema v6 的旧运行副本，导致 Dashboard 无法启动。

### Error
```text
error: database schema 7 is newer than supported 6
```

### Context
- 启动脚本以自身目录为根，通过 `python -m tools.acm_agent` 加载本地模块。
- 正式仓库版本为 3.0.0/schema 7，启动工作区仍为 2.1.0/schema 6。
- 数据库本身无需降级；同步运行模块、静态资源和模板后，CLI 数据库打开与真实 HTTP 启动检查均成功。

### Suggested Fix
发布包含数据库迁移的版本后，必须把同一版本的运行文件同步到实际启动工作区，并在交付前从启动目录检查包版本、`SCHEMA_VERSION`、数据库打开和 `/api/bootstrap`；禁止通过回退或手工修改数据库版本掩盖代码漂移。

### Metadata
- Reproducible: yes
- Related Files: start-acm-web.cmd, acm.ps1, tools/acm_agent/storage.py
- Pattern-Key: acm.deploy.runtime-schema-copy-drift

### Resolution
- **Resolved**: 2026-08-05T19:00:00+08:00
- **Notes**: 已同步 15 个运行文件；3.0.0/schema 7、compileall、JavaScript 检查和 loopback HTTP 启停冒烟均通过。

---

## [ERR-20260805-005] stress_generator_repair_still_fails_audit

**Logged**: 2026-08-05T22:43:09+08:00
**Priority**: high
**Status**: resolved
**Area**: backend

### Summary
P2596 generator 在唯一一次定点修复后仍以线性容器更新构造 large，并遗漏 small/random 的特殊合法参数覆盖。

### Error
```text
stress_artifact_audit_failed: generator 在一次针对性修复后仍未通过 AI 静态复核
```

### Context
- 实际 setup 在 41 秒内安全失败，剩余约 259 秒；旧 helper 未修改且正式 run 未创建。
- contract 返回空 `generator_requirements`，并把 profile 嵌套对象转成了 Python 风格字符串。
- 原 repair 把角色任务、旧代码和诊断塞在同一个请求对象中，没有保留原生成前缀，也没有把诊断转为结构化验收清单。

### Suggested Fix
规范化 contract 并补齐确定性的 profile、覆盖和 large 复杂度要求；repair 复用原角色消息作为完整前缀，再追加旧代码、结构化诊断和一次性验收清单。

### Metadata
- Reproducible: yes
- Related Files: tools/acm_agent/stress_ai.py, tools/acm_agent/stress_runtime.py, tests/test_stress_ai.py, tests/test_stress_runtime.py
- See Also: LRN-20260805-009, ERR-20260805-004
- Pattern-Key: acm.ai-stress.generator-repair-context

### Resolution
- **Resolved**: 2026-08-05T22:43:09+08:00
- **Notes**: prompt v2 强制 contract 字符串/非空 requirements，补充 small/large 分离与 large 复杂度不变量，并将 repair 改为稳定原前缀后的结构化追加消息；269 项全量测试通过。

---
