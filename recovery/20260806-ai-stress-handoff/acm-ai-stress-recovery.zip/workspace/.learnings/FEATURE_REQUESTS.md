﻿# Feature Requests

Capabilities requested by the user that are missing, incomplete, or worth improving for this workspace.

If a request is broadly useful across projects, add an abstracted companion entry to the global `FEATURE_REQUESTS.md` and link it with `See Also`.

---

## [FR-20260806-001] Certified resumable AI stress preparation

**Logged**: 2026-08-06T00:00:00+08:00
**Priority**: critical
**Status**: in_progress
**Area**: backend

### Summary
Make AI stress preparation reliable across problem types instead of repeatedly
paying for monolithic P2596 retries.

### Requested Capability
Raise the default preparation window to 600 seconds and add hard provider/local
phase deadlines, independent input validation, resumable role proofs, explicit
cache modes, and isolated statistical acceptance runs.

### User Context
The accepted release requires at least 16/20 complete P2596 cold successes,
cross-problem evidence, lower latency and token usage, and zero unsafe applies.

### Complexity Estimate
complex

### Suggested Implementation
Use a trusted protocol harness, immutable candidate/proof checkpoints,
exact-combination certification, fast-first targeted repair, and a benchmark
runner that never mutates real helpers or runs.

### Metadata
- Frequency: recurring
- Related Features: bounded parallel AI stress preparation
- Pattern-Key: acm.ai-stress.certified-resumable-preparation
- See Also: FR-20260805-007, FR-20260805-005

### Progress
- **2026-08-06**: 已根据首轮 20 次 cold 报告补上 schema 漂移归一化、evidence-only repair、非权威 construction、精确 records 诊断、coverage 集合化、隐藏动态 constraint probes 和 benchmark gold validator 认证。provider-free 门禁已通过；FR 保持 `in_progress`，等待 OpenCode 重跑 P2596 20 次与 Core 8 paid cold 后再按 80%/零误放门槛关闭。
- **2026-08-06 r2**: Canary 揭示 contract probe 极性可写反且 repair diagnostic 会泄露隐藏输入。已加入源码盲的第二分支 probe 认证、正负成对裁决、validator repair 全字段脱敏，并把 contract/artifact/preflight identity 升级到 5/7/5；本地 431 项测试、Core 8 gold 和 20/20 provider-free application-cold 通过。FR 仍等待新的付费 Canary/正式 cold 验收。

---

## [FR-20260805-007] Bounded parallel AI stress preparation and verified reuse

**Logged**: 2026-08-05T23:55:00+08:00
**Priority**: high
**Status**: resolved
**Area**: performance

### Summary
Make the AI stress preparation upper bound user-configurable around a five-minute default, fix parallel helper failure attribution, and eliminate repeated provider work on identical setups.

### Requested Capability
Use one 60–1800 second absolute deadline (default 300), parallelize independent helper preparation and safe preflight work, repair each rejected role at most once with its prior code, and automatically reuse only fully reviewed and preflighted bundles.

### Resolution
Added config v5 and schema v11, monotonic deadline propagation through DeepSeek retries/JSON recovery/crawling/compile/preflight, SQLite setup-slot exclusion, three-way generation and repair concurrency, three-worker helper builds, four isolated small-case sandboxes, contract plus strict bundle caches, warm zero-provider reuse, CLI/Dashboard controls, durable timing/usage metadata, and fail-closed timeout behavior.

### Metadata
- Source: user_request
- Related Files: tools/acm_agent/stress_budget.py, tools/acm_agent/deepseek.py, tools/acm_agent/stress_ai.py, tools/acm_agent/stress.py, tools/acm_agent/stress_runtime.py, tools/acm_agent/storage.py
- Tags: acm, ai-stress, deadline, parallel, cache, sqlite
- Pattern-Key: acm.ai-stress.bounded-parallel-preparation

---

## [FR-20260805-006] Permanent stress finish and segment-correct rate

**Logged**: 2026-08-05T20:45:00+08:00
**Priority**: high
**Status**: resolved
**Area**: workflow

### Summary
Allow users to permanently end a persistent stress run and report cases/s correctly after resume.

### Requested Capability
Add an “结束对拍” Dashboard control that releases the single-active-run lock without deleting helpers or history, and reset the speed calculation baseline each time a run resumes.

### Resolution
Added pause/resume/finish lifecycle handling, safe process-tree shutdown before permanent completion, persisted per-segment count baselines, separate cumulative and segment metrics, API coverage and Dashboard controls.

### Metadata
- Source: user_request
- Related Files: tools/acm_agent/storage.py, tools/acm_agent/stress_runtime.py, tools/acm_agent/web.py, tools/acm_agent/web_static
- Tags: acm, ai-stress, finish, rate, dashboard
- Pattern-Key: acm.persisted-run.segment-rate-and-finish

---

## [FR-20260805-005] Pre-apply certification for AI-generated stress helpers

**Logged**: 2026-08-05T19:20:00+08:00
**Priority**: high
**Status**: resolved
**Area**: validation

### Summary
Prevent compilable but semantically invalid generators and brute programs from replacing the current helper bundle.

### Requested Capability
Independently audit generated artifacts, execute deterministic boundary and random preflight cases under the existing isolation boundary, repair only the failing artifact, and leave existing helpers untouched unless every gate passes.

### Resolution
Implemented a bounded artifact audit and mandatory staging preflight with debug STL assertions, deterministic capability checks, official samples, 16 small random cases, extreme large cases, structured failure coordinates, guarded apply, and persisted validation summaries.

### Metadata
- Source: user_request
- Related Files: tools/acm_agent/stress.py, tools/acm_agent/stress_ai.py, tools/acm_agent/stress_runtime.py
- Tags: acm, ai-stress, generator, preflight, correctness
- Pattern-Key: acm.ai-stress.helper-preapply-certification

---

## [FR-20260805-003] AI-assisted persistent differential stress testing

**Logged**: 2026-08-05T23:30:00+08:00
**Priority**: high
**Status**: resolved
**Area**: validation

### Summary
Add an explicit DeepSeek workflow that prepares generator, brute and reference helpers, then runs layered differential testing until a counterexample, oracle conflict, fault or user stop.

### Requested Capability
Search fixed public editorial sources before generating a reference, safely replace helper files with backup/revert, execute all generated or downloaded code in a fail-closed Windows isolation boundary, and persist progress so Dashboard refresh and service restart do not lose the next seed.

### Resolution
Implemented config v4 and schema v8, bounded DeepSeek tool calls, allowlisted anonymous source crawling, independent artifact generation and repair, guarded helper bundles, a bundled AppContainer/Job Object launcher, sample plus 200-case warmup and 4:1 mixed scheduling, conservative three-way classification, durable stop/resume/failure assets, Dashboard/API/CLI controls, and offline plus explicit native sandbox tests.

### Metadata
- Source: user_request
- Related Files: tools/acm_agent/stress.py, tools/acm_agent/stress_ai.py, tools/acm_agent/stress_sources.py, tools/acm_agent/stress_runtime.py
- Tags: acm, ai, stress-testing, appcontainer, differential-testing
- Pattern-Key: acm.ai-stress.fail-closed-orchestration

---

## [FR-20260804-003] DeepSeek BYOK coaching and personalized recommendation

**Logged**: 2026-08-04T23:59:30+08:00
**Priority**: high
**Status**: resolved
**Area**: workflow

### Summary
Add user-funded DeepSeek assistance without weakening deterministic recommendation eligibility or local source safety.

### Requested Capability
Support explicit AI reranking from recent frozen-tag attempts, persistent streamed coaching, public/manual statement context, and confirmation-gated full-source patch proposals.

### Resolution
Implemented config v2 and schema v6, fixed-endpoint Flash/Pro BYOK, privacy-filtered candidate reranking with deterministic fallback, cached statement parsing, persistent SSE conversations, hint-level escalation, baseline-hash patch apply/revert, Dashboard/CLI/API surfaces, fake-transport regression coverage, and Windows Dashboard credential entry backed by current-user DPAPI persistence across service restarts.

### Metadata
- Source: user_request
- Related Files: tools/acm_agent/deepseek.py, tools/acm_agent/ai_context.py, tools/acm_agent/service.py, tools/acm_agent/web.py
- Tags: acm, deepseek, byok, coaching, recommendations, patch-safety
- Pattern-Key: acm.ai.explicit-deterministic-boundary

---

## [FR-20260804-002] Mastered-without-code Skip workflow

**Logged**: 2026-08-04T20:10:00+08:00
**Priority**: high
**Status**: resolved
**Area**: workflow

### Summary
Let a learner explicitly remove a trivial problem from implementation work after deriving the correct idea without an editorial.

### Requested Capability
Add a reversible Skip action to recommendation cards, persist it independently from AC and attempts, count it toward plan progress, and expose structured API, CLI, review, and Agent workflows.

### Resolution
Implemented schema-v4 dispositions and audit events, global recommendation exclusion, progressive completion without AC replacement leakage, desktop confirmation and undo UI, API/CLI commands, Agent guardrails, and full regression/browser validation.

### Metadata
- Source: user_request
- Related Files: tools/acm_agent/storage.py, tools/acm_agent/service.py, tools/acm_agent/web_static
- Tags: acm, recommendation, learning-state, local-web
- Pattern-Key: acm.workflow.mastered-without-code-skip

---

## [FR-20260804-001] Multi-plan management and visual editing

**Logged**: 2026-08-04T12:00:00+08:00
**Priority**: high
**Status**: resolved
**Area**: workflow

### Summary
Extend the local ACM dashboard from one hard-coded plan to managed, importable, editable plans.

### Requested Capability
Support plan.json v2, multiple enabled plans, JSON import/export, immediate stage/problem/date edits with revision recovery, and balanced catalog/plan recommendations.

### Resolution
Implemented SQLite-backed plan registry and five-version history, v1 migration, transactional editing APIs and CLI, desktop visual editor, strict recommendation source modes, and browser-tested immediate saves without deleting training history.

### Metadata
- Source: user_request
- Related Files: tools/acm_agent/plan.py, tools/acm_agent/service.py, tools/acm_agent/web_static
- Tags: acm, training-plan, local-web, recommendations
- Pattern-Key: acm.workflow.multi-plan-editor

---

## [FR-20260803-001] Local web dashboard for ACM workflow

**Logged**: 2026-08-03T23:59:00+08:00
**Priority**: high
**Status**: resolved
**Area**: workflow

### Summary
Replace the CLI-only daily ACM workflow with a loopback-only local web dashboard while preserving CLI and Agent compatibility.

### Requested Capability
Provide browser-based setup, platform sync, explainable recommendations, session start/verify/close, weekly review, settings, background jobs, and safe local shutdown without adding npm or pip runtime dependencies.

### Resolution
Implemented a Python 3.13 standard-library service and HTTP layer, a native responsive SPA, token/Origin/Host guards, serialized background jobs, double-click launcher, API-first Agent skill behavior, and CLI fallback.

### Metadata
- Source: user_request
- Related Files: tools/acm_agent/service.py, tools/acm_agent/web.py, tools/acm_agent/web_static, start-acm-web.cmd
- Tags: acm, local-web, workflow, automation
- Pattern-Key: acm.workflow.web-primary

---
## [FR-20260805-001] Per-problem AI conversation switching and clearing

**Logged**: 2026-08-05T00:45:00+08:00
**Priority**: high
**Status**: resolved
**Area**: workflow

### Summary
Persist independent AI coaching histories for different active problems and restore the matching history whenever the Dashboard switches problems.

### Requested Capability
Bind the AI workbench to the selected problem, prevent delayed streams and jobs from crossing problem boundaries, and provide a button that clears only the current problem's visible conversation.

### Resolution
Added problem-bound conversation state with epoch and SSE cancellation guards, transactional conversation archive-and-replace, a confirmed Dashboard clear action, HTTP 409 lifecycle conflicts, and regression coverage for two-problem restoration, hint audit preservation, rollback, path validation, and stale conversation rejection.

### Metadata
- Source: user_request
- Related Files: tools/acm_agent/service.py, tools/acm_agent/web.py, tools/acm_agent/web_static, tests/test_ai_conversation_clear.py
- Tags: acm, ai, conversation, local-web, persistence
- Pattern-Key: acm.ai.problem-scoped-conversation

---

## [FR-20260805-002] Confirmed AI Markdown knowledge archive

**Logged**: 2026-08-05T18:00:00+08:00
**Priority**: high
**Status**: resolved
**Area**: workflow

### Summary
Add an optional DeepSeek-generated Markdown summary to the post-session review flow without granting implicit file-write authority.

### Requested Capability
Use the closed attempt, frozen tags, statement, final code, review data and non-cleared conversation to generate an editable preview for Algorithms, Tricks or a custom local Markdown schema, then write only after explicit confirmation.

### Resolution
Implemented schema v7 storage, config v3 summary settings, sanitized built-in templates, deterministic schema inference/rendering, persistent preview-refresh-apply proposals, guarded atomic write/revert, Dashboard and CLI flows, API routes, startup recovery and full regression coverage. Existing personal Markdown files remain read-only until a current proposal is explicitly applied.

### Metadata
- Source: user_request
- Related Files: tools/acm_agent/knowledge.py, tools/acm_agent/knowledge_io.py, tools/acm_agent/service.py, tools/acm_agent/web_static
- Tags: acm, ai, markdown, knowledge-base, local-web
- Pattern-Key: acm.markdown-summary.proposal-saga

---

## [FR-20260805-003] Persistent AI stress evidence and helper reuse

**Logged**: 2026-08-05T23:30:00+08:00
**Priority**: high
**Status**: resolved
**Area**: workflow

### Summary
Make output disagreements immediately inspectable beside the solution and allow terminal stress runs to continue without paying to regenerate helpers.

### Requested Capability
Write fixed per-problem input/current/brute/reference files whenever the current and reference outputs differ; keep stopped controls visually idle; continue from the stored seed with the existing helper bundle; display helper provenance as links only.

### Resolution
Added atomic latest-disagreement aliases backed by the full failure archive, broadened hash-safe resume to stopped and diagnostic terminal states, recompiled the current solution with already-applied helpers before committing resume state, and simplified Dashboard provenance and disabled-button cursors.

### Metadata
- Source: user_request
- Related Files: tools/acm_agent/stress.py, tools/acm_agent/stress_runtime.py, tools/acm_agent/web_static
- Tags: acm, ai-stress, resume, failure-evidence, local-web
- Pattern-Key: acm.ai-stress.resume-and-evidence

---

## [FR-20260805-004] Boundary-aware small and extreme-large stress profiles

**Logged**: 2026-08-05T23:55:00+08:00
**Priority**: high
**Status**: resolved
**Area**: workflow

### Summary
Replace ambiguous medium cases with manually inspectable small cases and near-limit large cases that have explicit legal boundary coverage.

### Requested Capability
Generate an exact lower-bound small case, an exact upper-bound large case, then continue at a 4:1 ratio; run brute only for small, grant large a bounded 32/16 MiB I/O budget, and preserve the schedule across resume.

### Resolution
Added generator profile-v2 capability negotiation, boundary case kinds, absolute persisted scheduling, direct two-oracle large mismatch handling, and matching API/CLI/Dashboard controls. Schema v10 removes the retired counter entirely; old-protocol runs remain read-only audit records and cannot resume.

### Metadata
- Source: user_request
- Related Files: tools/acm_agent/stress.py, tools/acm_agent/stress_runtime.py, tools/acm_agent/storage.py
- Tags: acm, ai-stress, boundary, large-input, resume
- Pattern-Key: acm.ai-stress.boundary-profile-v2

---
