﻿# Learnings

Corrections, insights, knowledge gaps, and best practices specific to this workspace.

**Categories**: correction | insight | knowledge_gap | best_practice

Use this project file for local commands, config, conventions, APIs, schemas, and repo-specific behavior.

Do not log secrets, tokens, private keys, full environment variables, private configuration files, raw transcripts, or identifiable personal information. Prefer short redacted summaries and stable `Pattern-Key` values.

---

## [LRN-20260806-001] best_practice

**Logged**: 2026-08-06T17:10:00+08:00
**Priority**: critical
**Status**: resolved
**Area**: backend

### Summary
AI 输入 validator 的事务安全、正向样例通过与语义零误放是三件不同的事；动态约束必须由隐藏正负 paired probes 独立认证。

### Details
P2596 cold 报告的 `unsafe_apply=0` 只证明隔离写入安全，不能证明 validator 正确。至少两个被统计为成功的修复版 validator 删除或破坏了动态状态检查，另一个会重复/虚报 coverage；纯正向 generator/preflight 没有杀死这些 mutation。类似地，contract/blueprint 的自由文本构造未经机器验证，若被当作不可修改骨架，会让 generator 对同一非法状态序列连续修复仍失败。

### Suggested Action
让独立 contract 分支为每个 `state_precondition`、`dependent_bound`、`graph_predicate` 产生同 token 数且只差 1..2 token 的正负输入；在 probes 成为 oracle 前，再由看不到任何 helper 源码的独立分支逐条重放并纠正极性。probes 不得进入 validator 生成、修复或 audit prompt，运行时 repair diagnostic 也必须删除输入、哈希、ID、seed 和 stderr；可信 harness 成对执行两侧。benchmark 另用模型不可见的 gold corpus 复核生成 validator。自由文本 construction 只作候选策略，权威项限于 dimensions、records、operation families 和 coverage obligations；机器证明具体状态记录非法时允许替换参数或顺序。

### Metadata
- Source: benchmark_failure_analysis
- Related Files: tools/acm_agent/stress_ai.py, tools/acm_agent/stress.py, tools/acm_agent/stress_runtime.py, tools/acm_agent/stress_benchmark.py
- Tags: acm, stress, validator, mutation, hidden-probe, generator, fail-closed
- See Also: LRN-20260805-011, LRN-20260805-006, FR-20260806-001
- Pattern-Key: acm.ai-stress.semantic-validator-certification
- Recurrence-Count: 2
- First-Seen: 2026-08-06
- Last-Seen: 2026-08-06

### Resolution
- **Resolved**: 2026-08-06T17:10:00+08:00
- **Notes**: r2 Canary 发现 contract 将一组动态 probe 的正负极性写反，且运行时 diagnostic 泄露 probe 给 validator repair。已新增独立 probe 极性认证、成对真值表裁决和角色级诊断脱敏；431 项全仓测试、Core 8 gold gate 和新一轮 20/20 provider-free application-cold 均通过，付费 cold 发布统计待 OpenCode 复验。

---

## [LRN-20260805-010] correction

**Logged**: 2026-08-05T20:45:00+08:00
**Priority**: high
**Status**: resolved
**Area**: frontend

### Summary
可恢复后台任务必须区分暂停与永久结束，分段速率不能用累计计数除以重置后的计时。

### Details
持续对拍原本只有可恢复的 stop，用户无法永久完成仍占用唯一运行锁的 run。resume 会保留累计 `total_count` 并重置 `started_at`，前端却计算 `total_count / 本轮耗时`，导致每次继续后的 cases/s 虚高。

### Suggested Action
持久任务控制统一提供 pause/resume/finish 三种语义；finish 先终止子进程树，再进入不可恢复终态。累计计数继续用于审计，同时持久化 `rate_base_total`，显示本轮增量并以 `(total-rate_base_total)/本轮耗时` 计算速率。

### Metadata
- Source: user_feedback
- Related Files: tools/acm_agent/storage.py, tools/acm_agent/stress_runtime.py, tools/acm_agent/web_static/app.js
- Tags: acm, stress, lifecycle, resume, rate
- See Also: LRN-20260805-009
- Pattern-Key: acm.persisted-run.segment-rate-and-finish
- Recurrence-Count: 1
- First-Seen: 2026-08-05
- Last-Seen: 2026-08-05

### Resolution
- **Resolved**: 2026-08-05T20:45:00+08:00
- **Notes**: 新增永久 finish 状态转换与按钮，继续时持久化本轮计数基线，Dashboard 分别展示累计和本轮速度。

---

## [LRN-20260805-009] correction

**Logged**: 2026-08-05T19:20:00+08:00
**Priority**: high
**Status**: resolved
**Area**: backend

### Summary
生成 helper 能编译并声明 capability 不代表它会生成合法输入；必须在覆盖旧文件前执行独立审查与交互预验。

### Details
P2596 generator 用长度不同的并行数组保存操作参数，输出阶段统一按操作下标读取，产生越界值和非法 `Insert`；同时它把生成过程中修改后的书架状态当作初始排列输出，并在 large 中逐操作重建位置数组。现有编译门禁无法发现这些运行期与语义错误，且错误只会在 helper 已写入并启动持续对拍后暴露。

### Suggested Action
AI helper 必须经过 `独立短审查 -> release/debug 构建 -> capability/确定性 -> 官方样例 -> lower-bound -> 多个 small random -> upper-bound/large random -> hash-guarded apply`。预验只运行 generator 和 oracle，不发送或执行用户主解；失败只修复被定位的 artifact，且旧 helper 与 run 状态保持不变。

### Metadata
- Source: user_feedback
- Related Files: tools/acm_agent/stress.py, tools/acm_agent/stress_ai.py, tools/acm_agent/stress_runtime.py
- Tags: acm, stress, generator, preflight, debug-stl, fail-closed
- See Also: LRN-20260805-008, LRN-20260805-004
- Pattern-Key: acm.ai-stress.helper-preapply-certification
- Recurrence-Count: 1
- First-Seen: 2026-08-05
- Last-Seen: 2026-08-05

### Resolution
- **Resolved**: 2026-08-05T19:20:00+08:00
- **Notes**: 新增共享 30 秒 AI 审查、固定 16 个 small 的调试预验、large 性能门禁与真正的 stage/preflight/apply 边界。

---

## [LRN-20260805-008] correction

**Logged**: 2026-08-05T23:55:00+08:00
**Priority**: high
**Status**: resolved
**Area**: backend

### Summary
可恢复的随机对拍必须把调度协议版本和绝对调度位置同时持久化。

### Details
只保存 next seed 无法保证恢复后不重复 lower/upper boundary，也无法保持 4:1 profile 周期。新 generator 协议还不能直接套到旧 helper 上，否则旧代码会误解 profile 或忽略 case kind。profile-v2 因此需要 capability handshake、持久化 profile_version，以及由已完成 total_count 派生的 schedule_offset。旧协议不应继续保留执行兼容，只能只读审计并要求重新准备。

### Suggested Action
为任何可暂停的生成式测试调度同时保存 `protocol version + completed count + next seed`，在提交 run 前隔离探测 helper capability；协议退役后应在编译或状态修改前明确拒绝恢复，避免旧语义继续渗入界面、API 和存储。

### Metadata
- Source: user_feedback
- Related Files: tools/acm_agent/stress.py, tools/acm_agent/stress_runtime.py, tools/acm_agent/storage.py
- Tags: acm, stress, resume, protocol-version, boundary
- See Also: LRN-20260805-004
- Pattern-Key: acm.ai-stress.boundary-profile-v2
- Recurrence-Count: 2
- First-Seen: 2026-08-05
- Last-Seen: 2026-08-05

### Resolution
- **Resolved**: 2026-08-05T23:55:00+08:00
- **Notes**: profile-v2 使用 capability、schedule_offset 和 large_count；schema-v10 删除退役计数，旧协议运行仅供查看且不能继续。

---

## [LRN-20260805-007] correction

**Logged**: 2026-08-05T16:40:00+08:00
**Priority**: high
**Status**: resolved
**Area**: backend

### Summary
来源可追溯且能抓到完整代码不等于 reference 可以直接信任；洛谷反抄袭式删改必须经过有成本边界的静态准入。

### Details
洛谷公开题解可能故意留下编译缺失、过小数组、遗漏分支或错误输出等细微缺陷。持续对拍在采用完整洛谷源码前，应先执行通用源码安全检查和 `g++ -fsyntax-only`，再结合题面、约束与对拍契约进行独立语义静态审查，覆盖数组容量与索引上界、操作分支完整性、输入输出协议、排名下标和可疑删改。未通过的候选应继续尝试同来源层的下一候选，不能把被拒绝的代码作为补全文本静默重写。

逐候选开启 thinking、允许请求/JSON 重试并给出过大的输出预算，会使一次 reference 准备串行消耗数分钟和大量 token。候选发现与精确题号过滤应由本地白名单抓取器确定性完成；洛谷语义审查使用共享总预算、非 thinking 单次短输出、压缩题面/契约、源码长度上限和零重试。只在剩余预算内检查下一候选，超限时安全回退到后续 reference 准备路径。

### Suggested Action
将 reference 信任链固定为 `确定性选源 -> 来源与安全检查 -> 限时静态编译 -> 限时题面约束语义审查 -> 官方样例 -> 三方小规模预热`；审查阶段应有小于 30 秒的共享预算、关闭 thinking/重试并限制上下文和输出。静态审查通过只表示允许进入后续验证，不得直接标记为 validated reference，并持久化结构化审查结论供审计。

### Metadata
- Source: user_feedback
- Related Files: tools/acm_agent/stress_sources.py, tools/acm_agent/stress_ai.py, tools/acm_agent/stress_runtime.py
- Tags: acm, stress, luogu, reference, static-audit, anti-copy
- See Also: LRN-20260805-006, LRN-20260805-004
- Pattern-Key: acm.ai-stress.luogu-static-reference-audit
- Recurrence-Count: 2
- First-Seen: 2026-08-05
- Last-Seen: 2026-08-05

---

## [LRN-20260805-006] correction

**Logged**: 2026-08-05T16:20:00+08:00
**Priority**: high
**Status**: resolved
**Area**: backend

### Summary
持续对拍的 reference 信任级别必须忠实反映代码来源；明确存在公开完整题解时不能静默降级成 AI 重写。

### Details
P2596 已有公开洛谷专栏完整 C++，但旧抓取器只访问需要鉴权的 `/problem/solution/`，失败后直接回退为 `ai_generated`。可靠流程应先按精确题号查询公开文章索引，抓取完整来源代码并执行安全检查；模型选择空值、说明片段或不安全候选时，仍应选择同层第一个安全完整源码。`oracle_conflict` 的审计目录虽然完整，但高频调试还需要把输入和三方输出直接导出到题目源码目录，并用 timestamp/seed 防止覆盖旧证据。

### Suggested Action
来源式 reference 优先级高于 AI reconstruction，并持久化 URL/title/hash；只有没有安全完整来源或来源代码无法通过准备流程时才允许 AI 补全。冲突同时保留隐藏审计资产和题目目录中的可直接打开副本。

### Metadata
- Source: user_feedback
- Related Files: tools/acm_agent/stress_sources.py, tools/acm_agent/stress_ai.py, tools/acm_agent/stress.py, tools/acm_agent/stress_runtime.py
- Tags: acm, stress, reference, provenance, conflict-artifacts
- See Also: LRN-20260805-004, ERR-20260805-004
- Pattern-Key: acm.ai-stress.source-reference-provenance
- Recurrence-Count: 1
- First-Seen: 2026-08-05
- Last-Seen: 2026-08-05

---

## [LRN-20260805-006] best_practice

**Logged**: 2026-08-05T23:55:00+08:00
**Priority**: high
**Status**: resolved
**Area**: backend

### Summary
生成式准备的时间上限必须是贯穿所有重试与本地门禁的绝对 deadline，缓存命中必须复用验证证明而不是只复用源码。

### Details
把 300 秒配置成单次 socket read timeout 会让网络重试、JSON 恢复和串行角色生成成倍放大总耗时；future 按角色顺序 `.result()` 还会掩盖先完成的失败角色。另一方面，只缓存模型输出无法证明 helper 仍安全：题面、compare、large、模型、contract、样例、编译器、sandbox、策略、helper 与 staged executable 任一变化都可能使旧证明失效。复杂 generator 还需要先生成可本地验证的 blueprint，将 thinking 限定在规划和困难修复，并用输出绑定的 manifest 验证 seed、覆盖与复杂度；修复次数应按角色风险设置并与静态审查、本地 preflight 共享计数。

### Suggested Action
长链路 AI 工作流默认采用 `global monotonic deadline -> reserve future gates -> bounded parallel branches -> locally validated blueprint -> role-aware repair budget -> output-bound manifest -> proof-carrying local cache -> fail-closed apply`；阶段预算只能作为提示，外部请求上限必须由共享剩余额减去强制门禁保留额得到。跨进程去重必须在首次外部调用前由数据库原子占槽，不能依赖进程内锁。

### Metadata
- Source: implementation_review
- Related Files: tools/acm_agent/stress_budget.py, tools/acm_agent/deepseek.py, tools/acm_agent/stress_ai.py, tools/acm_agent/stress_runtime.py, tools/acm_agent/storage.py
- Tags: deadline, parallel, deepseek, proof-cache, fail-closed
- See Also: FR-20260805-007, ERR-20260805-002, ERR-20260805-004, C:\Users\Lenovo\.codex\.learnings\LEARNINGS.md#LRN-20260805-001
- Pattern-Key: acm.ai-stress.bounded-parallel-preparation
- Recurrence-Count: 2
- First-Seen: 2026-08-05
- Last-Seen: 2026-08-05

---

## [LRN-20260805-005] best_practice

**Logged**: 2026-08-05T14:45:00+08:00
**Priority**: high
**Status**: resolved
**Area**: backend

### Summary
DeepSeek 结构化长任务需要把协议恢复和用户可见阶段进度同时设计，thinking tool call 的推理内容只应在单次工具循环内临时回传。

### Details
JSON Output 官方允许偶发空正文；完全相同的 thinking 重试可能重复失败，恢复请求应显式要求完整 JSON 并关闭 thinking。另一方面，thinking 模式执行 tool call 后，后续 tool-result 请求必须带回本轮 `reasoning_content`，否则来源搜索会收到协议错误；该字段只在内存中参与本轮 API 往返，不能展示、写日志或落库。长链路还应按确定性边界上报阶段，使前端能够显示当前步骤并把错误归因到最后阶段。

### Suggested Action
实现 DeepSeek JSON/tool-call 工作流时，测试空正文降级、`finish_reason=length`、thinking 工具回传与不落盘约束；对超过一个外部调用的后台任务提供结构化 `stage/label/step/total`。

### Metadata
- Source: error
- Related Files: tools/acm_agent/deepseek.py, tools/acm_agent/stress_ai.py, tools/acm_agent/stress_runtime.py, tools/acm_agent/web.py
- Tags: deepseek, json-output, thinking, tool-call, progress
- See Also: ERR-20260805-002
- Pattern-Key: acm.deepseek.structured-long-job-recovery
- Recurrence-Count: 1
- First-Seen: 2026-08-05
- Last-Seen: 2026-08-05

---

## [LRN-20260805-004] implementation

**Logged**: 2026-08-05T23:30:00+08:00
**Priority**: high
**Status**: resolved
**Area**: validation

### Summary
持续对拍必须同时隔离代码执行、oracle 信任和跨进程运行归属。

### Details
只做源码正则检查不足以安全运行下载或模型生成的 C++；Windows 上需要无网络 capability 的 AppContainer 承担权限边界，再由 Job Object 限制进程树、内存、CPU/墙钟和输出。MinGW 程序还必须全静态链接，否则容器内缺失 `libwinpthread` 会表现为启动失败或超时。另一方面，三方输出不一致不能都归责用户，只有 brute 与 reference 一致时才有确认反例。持久 run 还要记录 owner PID；否则另一个 CLI 只读状态时会把仍在 Dashboard 运行的任务误判为重启残留。

### Suggested Action
新增长时间本地执行能力时采用 `explicit opt-in -> independent generation -> source validation -> fail-closed sandbox -> conservative oracle classification -> owner-aware durable state`，并用真实隔离 smoke test验证动态库、取消和资源限制，而不只依赖 fake transport。

### Metadata
- Source: implementation_review
- Related Files: tools/acm_agent/stress.py, tools/acm_agent/stress_runtime.py, tools/acm_agent/storage.py
- Tags: acm, sandbox, appcontainer, oracle, persistence
- Pattern-Key: acm.ai-stress.fail-closed-orchestration
- Recurrence-Count: 1
- First-Seen: 2026-08-05
- Last-Seen: 2026-08-05

---

## [LRN-20260805-004] correction

**Logged**: 2026-08-05T11:49:32+08:00
**Priority**: high
**Status**: resolved
**Area**: workflow

### Summary
正式 ACM Agent GitHub 仓库位于 `D:\code\acm-agent`，不能用训练工作区 `D:\code\acm` 的 Git 元数据判断发布状态。

### Details
`D:\code\acm` 是用户的 ACM 训练与功能开发工作区，根部 `.git` 可能为空；实际公开仓库及其远端、分支、CI 和发布卫生应在 `D:\code\acm-agent` 检查。两处源码可能暂时同步，但 Git 状态含义不同。

### Suggested Action
以后评估、发布或管理 `acm-agent` GitHub 项目时，先以 `D:\code\acm-agent` 为仓库根目录，并在该目录核对 remote、默认分支、CI 和未提交改动；只有训练数据与本地工作流操作才默认使用 `D:\code\acm`。

### Metadata
- Source: user_feedback
- Related Files: D:\code\acm-agent, D:\code\acm
- Tags: acm-agent, workspace, git, repository-path
- Pattern-Key: acm.repository.public-root
- Recurrence-Count: 1
- First-Seen: 2026-08-05
- Last-Seen: 2026-08-05

### Resolution
- **Resolved**: 2026-08-05T11:49:32+08:00
- **Notes**: 当前评估已切换为以 `D:\code\acm-agent` 的远端与工作树为准。

---

## [LRN-20260804-009] best_practice

**Logged**: 2026-08-04T22:30:00+08:00
**Priority**: medium
**Status**: resolved
**Area**: frontend

### Summary
异步 DOM 事件应在 `await` 前保存元素引用，流式富文本应在消息终止后一次性渲染。

### Details
浏览器的 `event.currentTarget` 只保证在事件分发期间有效，异步回调在 `await` 后再次读取可能得到 `null`，使 busy 按钮无法恢复。SSE 回答中的 LaTeX 也不能在每个 delta 后直接改写 DOM，否则不完整分隔符和已生成节点会与后续文本追加冲突。正确做法是预先保存按钮引用、让 busy helper 幂等，并在流式阶段只追加 `textContent`，在 done、EOF 或中断时再对 assistant 消息执行一次本地可信配置的数学渲染。

### Suggested Action
新增异步事件时禁止跨 `await` 使用 `event.currentTarget`；新增流式 Markdown/LaTeX 时保留原始文本为持久化事实，只在稳定消息边界进行展示层转换。

### Metadata
- Source: user_feedback
- Related Files: tools/acm_agent/web_static/app.js, tools/acm_agent/web_static/index.html
- Tags: javascript, dom-events, sse, katex, busy-state
- Pattern-Key: frontend.async-event-stable-target
- Recurrence-Count: 1
- First-Seen: 2026-08-04
- Last-Seen: 2026-08-04

### Resolution
- **Resolved**: 2026-08-04T22:30:00+08:00
- **Notes**: 已捕获稳定按钮引用、加固幂等 busy 状态，并使用同源 KaTeX 在 assistant 消息终止后渲染公式。

---

## [LRN-20260804-010] correction

**Logged**: 2026-08-04T23:59:55+08:00
**Priority**: high
**Status**: resolved
**Area**: backend

### Summary
网页 BYOK 需要跨服务重启保留凭据时，应使用操作系统用户作用域保护，而不是要求重复输入或写入明文配置。

### Details
初版只允许 `DEEPSEEK_API_KEY` 环境变量，随后用户明确要求在 Dashboard 直接输入并且重启后无需重新输入。Windows 实现应使用当前登录用户作用域的 DPAPI 密文，API 只返回 detected/source/persisted 状态；浏览器输入框在请求后清空，密钥不进入浏览器存储、JSON 配置、SQLite、日志或后台 job。非 Windows 环境无法提供同等标准库保护时必须拒绝持久化，不能静默写明文。

### Suggested Action
新增需要重启持久化的本地 API 凭据时，先选用操作系统凭据保护，设计独立的同步写入/清除端点，并用“磁盘无明文、响应无回显、进程重建可恢复”三项测试锁定边界。

### Metadata
- Source: user_feedback
- Related Files: tools/acm_agent/credentials.py, tools/acm_agent/service.py, tools/acm_agent/web.py, tools/acm_agent/web_static/app.js
- Tags: acm, byok, dpapi, credentials, persistence
- Pattern-Key: acm.ai.credential-persistence
- Recurrence-Count: 1
- First-Seen: 2026-08-04
- Last-Seen: 2026-08-04

### Resolution
- **Resolved**: 2026-08-04T23:59:55+08:00
- **Notes**: Dashboard 已支持 DPAPI 加密保存、自动恢复、替换和清除，并通过真实 Windows E2E。

---

## [LRN-20260804-009] best_practice

**Logged**: 2026-08-04T23:59:30+08:00
**Priority**: high
**Status**: resolved
**Area**: backend

### Summary
外部模型只能影响受验证的派生结果，不能拥有候选资格、密钥、路径或直接写文件的权限。

### Details
推荐资格由确定性引擎决定，模型只返回候选题号的顺序和解释；对话中的题面与源码是不可信数据；代码修复使用完整候选源码，由服务端生成 diff，并通过基线哈希、受管路径、备份和显式确认保护本地修改。文件与 SQLite 双写还需要持久化 `applying/reverting` 中间态、哈希对账和失败补偿，不能把单次原子文件替换误认为跨资源事务。DeepSeek 的 reasoning 内容、密钥和敏感本地字段均不应进入持久化或响应。

### Suggested Action
新增 AI 能力时继续采用 `deterministic gate -> minimal outbound payload -> schema validation -> safe fallback`，把所有文件系统变更留在本地服务端，并要求可审计的 proposal/confirm 生命周期。

### Metadata
- Source: implementation_review
- Related Files: tools/acm_agent/deepseek.py, tools/acm_agent/service.py, tools/acm_agent/ai_context.py, tools/acm_agent/storage.py
- Tags: acm, ai, privacy, validation, patch-safety
- Pattern-Key: acm.ai.explicit-deterministic-boundary
- Recurrence-Count: 1
- First-Seen: 2026-08-04
- Last-Seen: 2026-08-04

### Resolution
- **Resolved**: 2026-08-04T23:59:30+08:00
- **Notes**: 第二阶段使用固定 DeepSeek endpoint、模型白名单、出站最小化、候选池校验和确认式补丁流程。

---

## [LRN-20260804-008] best_practice

**Logged**: 2026-08-04T23:59:00+08:00
**Priority**: high
**Status**: resolved
**Area**: backend

### Summary
题目标签必须由统一的有效标签解析器接线，并在 attempt 关闭时冻结历史快照。

### Details
题单扁平化保留了 `task.tags`，但服务层曾用阶段 topic 与平台标签覆盖它，导致人工标签和清洗结果无法稳定进入推荐。同时，历史 attempt 若每次分析都动态读取当前标签，后续增删标签会让过去的薄弱项和周复盘发生漂移。

### Suggested Action
平台原始标签保持无损；推荐、薄弱项和周复盘统一读取 `(raw ∪ plan tags) - metadata - suppress + add` 的有效标签。服务层不得重建或覆盖 `task.tags`；关闭 attempt 时在同一事务中写入有效标签快照，历史分析优先读快照，缺失时才显式标记 legacy fallback。

### Metadata
- Source: implementation_review
- Related Files: tools/acm_agent/tag_policy.py, tools/acm_agent/service.py, tools/acm_agent/storage.py, tools/acm_agent/recommend.py
- Tags: acm, tags, recommendation, snapshot, data-model
- Pattern-Key: acm.tags.effective-source-wiring
- Recurrence-Count: 1
- First-Seen: 2026-08-04
- Last-Seen: 2026-08-04

### Resolution
- **Resolved**: 2026-08-04T23:59:00+08:00
- **Notes**: 第一阶段引入统一有效标签解析、全局 add/suppress 与 close 快照，并用双修订预览/应用流程保护人工清洗。

---

## [LRN-20260804-007] correction

**Logged**: 2026-08-04T23:55:00+08:00
**Priority**: high
**Status**: resolved
**Area**: backend

### Summary
推荐难度基准应优先使用用户配置的目标 CF rating，而不是当前 CF rating。

### Details
当前 rating 描述已有能力，目标 rating 描述训练要对齐的能力区间。设置页已经收集并持久化目标 rating，但推荐服务此前只把当前 rating 传入评分器，导致目标配置不影响恢复、主练和上探槽位。

### Suggested Action
推荐基准按 `target rating -> current rating -> 最近 30 道不同 CF AC 的中位数 -> 1600` 回退；服务层必须显式把配置目标传入纯推荐函数，并用测试锁定优先级和槽位目标。

### Metadata
- Source: user_feedback
- Related Files: tools/acm_agent/recommend.py, tools/acm_agent/service.py, tests/test_plan_recommend.py, tests/test_service.py
- Tags: acm, recommendation, rating, configuration
- Pattern-Key: acm.recommendation.target-rating-baseline
- Recurrence-Count: 1
- First-Seen: 2026-08-04
- Last-Seen: 2026-08-04

### Resolution
- **Resolved**: 2026-08-04T23:55:00+08:00
- **Notes**: 已将目标 rating 设为最高优先级，并通过单元、服务层和完整回归测试。

---

## [LRN-20260804-005] best_practice

**Logged**: 2026-08-04T20:10:00+08:00
**Priority**: high
**Status**: resolved
**Area**: backend

### Summary
训练完成状态必须与判题通过状态分离；“已有正确思路但无需实现”不能写成 AC。

### Details
全局 Skip 可以退出新题推荐并推动 progressive 题单进度，但平台 AC、手工 AC、复做资格和结构化 AC replacement 仍需只读取 accepted 集合。状态合并采用 `accepted > skipped > attempted > local_only > not_started > unknown`，从而允许后续真实 AC 覆盖显示而保留审计历史。

### Suggested Action
后续新增训练处置状态时，分别维护 verdict、attempt、disposition 与 plan-completion 集合；只在明确规则处合并，不扩张 accepted 的含义。

### Metadata
- Source: user_feedback
- Related Files: tools/acm_agent/storage.py, tools/acm_agent/recommend.py, tools/acm_agent/plan_manager.py
- Tags: acm, state-model, acceptance, recommendation
- Pattern-Key: acm.state.separate-completion-from-acceptance
- Recurrence-Count: 2
- First-Seen: 2026-08-04
- Last-Seen: 2026-08-04

---

## [LRN-20260804-006] best_practice

**Logged**: 2026-08-04T23:30:00+08:00
**Priority**: high
**Status**: resolved
**Area**: backend

### Summary
题单定义与题目运行态必须分层；判题结果和 Skip 由状态库派生，不写回 plan JSON。

### Details
题单任务需要同时展示 judge result 与 effective Skip，但二者来自不同事实源。Codeforces 可用提交历史给出非 AC verdict；洛谷匿名同步只可靠提供公开 AC，因此缺少 WA/TLE/RE 不能解释为未尝试或失败，本地 close 记录才可补充非 AC。

### Suggested Action
题单详情在 `plan` 之外返回以 `task_key` 索引的 `task_statuses`；导入、编辑、托管副本和导出只处理计划字段。聚合时 AC 永久优先，Skip 独立生效，平台能力不足时保留 `unknown` 或已知 catalog 的 `not_started`。

### Metadata
- Source: user_feedback
- Related Files: tools/acm_agent/storage.py, tools/acm_agent/plan_manager.py, tools/acm_agent/service.py, tools/acm_agent/web_static/app.js
- Tags: acm, plan-schema, runtime-state, luogu, skip
- Pattern-Key: acm.plan.runtime-status-separation
- Recurrence-Count: 1
- First-Seen: 2026-08-04
- Last-Seen: 2026-08-04
- See Also: LRN-20260804-005, LRN-20260804-004

### Resolution
- **Resolved**: 2026-08-04T23:30:00+08:00
- **Notes**: 已实现独立 task_statuses 聚合、只读网页状态列和导入导出边界测试。

---

## [LRN-20260804-004] best_practice

**Logged**: 2026-08-04T19:30:00+08:00
**Priority**: high
**Status**: resolved
**Area**: backend

### Summary
洛谷题库的 `keyword=<pid>` 当前不能作为精确题号查询；标签抓取必须读取公开题面并按 `pid` 唯一匹配。

### Details
实时响应会保留 `filter.keyword`，但题目列表仍可能包含几十道不相关题。逐题读取 `/problem/<pid>?_contentOnly=1` 后，`lentille-context` 同时可能包含推荐题，因此仍需要求目标 `pid` 恰好出现一次。标签字典不可用时不能把整数 tag id 写成字符串标签。

### Suggested Action
题单标签同步使用题面页、exact-pid 结构守卫和逐题部分失败；未知 tag id fail closed，成功题目的建议继续保留。

### Metadata
- Source: live_api_check
- Related Files: tools/acm_agent/platforms.py, tests/test_platforms.py
- Tags: luogu, tags, schema-guard, partial-failure
- Pattern-Key: acm.luogu.problem-tag-exact-page
- Recurrence-Count: 1
- First-Seen: 2026-08-04
- Last-Seen: 2026-08-04

### Resolution
- **Resolved**: 2026-08-04T19:30:00+08:00
- **Notes**: 已实现 `LuoguClient.problem`、唯一题号校验、未知标签 ID 拒绝和夹具/实时 smoke test。

---

## [LRN-20260804-003] best_practice

**Logged**: 2026-08-04T19:25:00+08:00
**Priority**: medium
**Status**: resolved
**Area**: frontend

### Summary
严格 `style-src 'self'` 下，动态进度条不能依赖 HTML 内联 `style` 属性。

### Details
桌面端 Playwright 验收发现题单进度条的 `style="width:..."` 被 CSP 拦截，功能测试仍通过但控制台报错且视觉宽度失效。放宽 CSP 会削弱本地令牌页面的防护，没有必要。

### Suggested Action
动态比例优先使用原生 `<progress value>` 和外部 CSS 伪元素；每次网页改动检查 console error/warning，而不只做 DOM 或语法测试。

### Metadata
- Source: browser_qa
- Related Files: tools/acm_agent/web_static/app.js, tools/acm_agent/web_static/styles.css, tools/acm_agent/web.py
- Tags: csp, frontend, progress, playwright
- Pattern-Key: acm.web.csp-no-inline-style
- Recurrence-Count: 1
- First-Seen: 2026-08-04
- Last-Seen: 2026-08-04

### Resolution
- **Resolved**: 2026-08-04T19:25:00+08:00
- **Notes**: 题单进度条改用原生 progress；桌面端复测控制台零错误。

---

## [LRN-20260804-002] correction

**Logged**: 2026-08-04T18:00:00+08:00
**Priority**: medium
**Status**: resolved
**Area**: frontend

### Summary
题单管理页应以浏览和选择训练内容为主，默认只读；编辑能力按题单信息和单个阶段显式开启，避免把完整数据模型同时暴露为表单。

### Details
常驻显示题目层级、题目上下移动和跨阶段移动会让阶段卡片明显过载；单题日期和必做状态也不应重复阶段级排期。日常列表只显示可跳转的题号/名称与标签，日期统一放在阶段；即时保存后的编辑状态应绑定稳定 `stage_key`，而不是易变的阶段下标。

### Suggested Action
后续扩展题单页面时优先增加只读摘要或折叠的高级设置；只有高频操作进入阶段编辑区，并保持一次只编辑一个阶段。

### Metadata
- Source: user_feedback
- Related Files: tools/acm_agent/plan.py, tools/acm_agent/storage.py, tools/acm_agent/web_static/app.js, tools/acm_agent/web_static/styles.css
- Tags: acm, training-plan, frontend, progressive-disclosure
- Pattern-Key: acm.plan-editor.readonly-by-default
- Recurrence-Count: 2
- First-Seen: 2026-08-04
- Last-Seen: 2026-08-04

### Resolution
- **Resolved**: 2026-08-04T18:00:00+08:00
- **Notes**: 题单与阶段已默认只读，单阶段显式编辑；任务 schema 移除 required/due_date/unlock_at，页面只保留可跳转的题号/名称与标签。

---

## [LRN-20260804-001] security

**Logged**: 2026-08-04T00:20:00+08:00
**Priority**: high
**Status**: resolved
**Area**: security

### Summary
回环服务的随机令牌仍需保护其落盘文件；仅限制监听地址不能抵御同机其他用户读取或篡改继承了宽松 ACL 的令牌文件。

### Details
`web-runtime.json` 包含本地 API bearer token。Windows 的 `os.chmod(0600)` 不会收紧 NTFS ACL，并且环境变量中的 `USERNAME` 可能与实际进程令牌身份不同（例如沙箱用户），因此按用户名授权也可能让服务自身失去读取权限。

### Suggested Action
Windows 下用 `whoami /user` 获取当前进程 SID，以 `icacls /inheritance:r` 移除继承，仅授予该 SID 与 LocalSystem；任何步骤失败时删除令牌文件并拒绝启动。POSIX 下继续使用 `0600`。

### Metadata
- Source: forward_test
- Related Files: tools/acm_agent/web.py, tests/test_web.py
- Tags: local-web, bearer-token, windows, acl, fail-closed
- Pattern-Key: acm.web.runtime-token-acl
- Recurrence-Count: 1
- First-Seen: 2026-08-04
- Last-Seen: 2026-08-04

### Resolution
- **Resolved**: 2026-08-04T00:20:00+08:00
- **Notes**: 运行时文件现按实际进程 SID 收紧 ACL；实时 `icacls` 检查仅显示该 SID 与 LocalSystem。

---

## [LRN-20260803-003] best_practice

**Logged**: 2026-08-03T23:18:00+08:00
**Priority**: medium
**Status**: resolved
**Area**: platform-api

### Summary
Codeforces 官方全题库包含少量数字型或非标准历史 `index`，推荐候选不能假设每条记录都满足常规字母题号。

### Details
实时 `problemset.problems` 快照出现了可拼成 `CF92101` 的历史记录，而本地规范题号要求 `CF<contest><letter-index>`。同步层可原样保存官方记录；推荐层应做结构过滤，避免单条历史异常使整个 `next` 失败。

### Suggested Action
平台快照保持无损，进入工作区文件命名、计划或推荐器前用 `parse_problem_ref` 校验；未知题号跳过推荐并由测试覆盖。

### Metadata
- Source: live_smoke_test
- Related Files: tools/acm_agent/cli.py, tests/test_cli.py
- Tags: codeforces, catalog, schema-guard, recommendation
- Pattern-Key: acm.codeforces.nonstandard-index-filter
- Recurrence-Count: 1
- First-Seen: 2026-08-03
- Last-Seen: 2026-08-03

### Resolution
- **Resolved**: 2026-08-03T23:18:00+08:00
- **Notes**: 非标准题号保留在 SQLite 平台快照中，但不会进入常规推荐候选或 accepted key 归一化。

---

## [LRN-20260803-002] best_practice

**Logged**: 2026-08-03T23:10:00+08:00
**Priority**: high
**Status**: resolved
**Area**: platform-api

### Summary
洛谷公开练习页的 `lentille-context.data.passed` 需要兼容对象列表，不能只按题号字符串列表解析。

### Details
当前公开页面会返回形如 `{"pid":"P3372","name":"...","difficulty":4}` 的对象；历史夹具也可能是字符串列表或题号为 key 的映射。同步器应只提取受结构守卫保护的 `pid`，未知结构必须失败关闭，并保留最后成功 AC 快照。

### Suggested Action
夹具使用对象列表作为主合同，同时保留字符串/映射兼容分支；任何非空但无法提取 `P...` 的响应都抛出结构错误，禁止写入空 AC 集。

### Metadata
- Source: live_api_check
- Related Files: tools/acm_agent/platforms.py, tests/fixtures/platforms/luogu_practice.html
- Tags: luogu, sync, fixture, schema-guard
- Pattern-Key: acm.luogu.passed-object-list
- Recurrence-Count: 1
- First-Seen: 2026-08-03
- Last-Seen: 2026-08-03

### Resolution
- **Resolved**: 2026-08-03T23:10:00+08:00
- **Notes**: 解析器已支持对象、字符串和映射三种已知形态，并以对象夹具覆盖当前页面结构。

---

## [LRN-20260724-003] best_practice

**Logged**: 2026-07-24T17:00:00+08:00
**Priority**: medium
**Status**: resolved
**Area**: tests

### Summary
二维矩形覆盖中，两个严格坐标不等式相对查询点各有两种成立方式，前缀和判定必须检查四种组合。

### Details
若端点满足 `r1 < r2`、`c1 < c2`，查询格 `(i,j)` 只要求位于闭矩形内。行严格性可由 `r1 < i` 或 `i < r2` 保证，列严格性可由 `c1 < j` 或 `j < c2` 保证，因此共有四种区域组合。只检查“左上严格/右下闭合”和“左上闭合/右下严格”会漏掉矩形上右边界与下左边界上的非端点格子。

### Suggested Action
把严格行、列条件独立拆分后取笛卡尔积，并用最小反例 `2 2 / 1 2 / 2 1` 检查四条边是否全部标记；之后进行小网格穷举对拍。

### Metadata
- Source: error
- Related Files: 2026/7/24/G.cpp
- Tags: xcpc, prefix-sum, rectangle, boundary, wrong-answer
- Pattern-Key: xcpc.rectangle.strict-boundary-product
- Recurrence-Count: 1
- First-Seen: 2026-07-24
- Last-Seen: 2026-07-24

### Resolution
- **Resolved**: 2026-07-24T17:00:00+08:00
- **Notes**: 高频值判定补全四种查询区域组合，并通过全部 2x2 穷举和 1000 组随机暴力对拍。

---

## [LRN-20260722-001] correction

**Logged**: 2026-07-22T20:30:00+08:00
**Priority**: medium
**Status**: resolved
**Area**: docs

### Summary
XCPC 单题总结应按真正可复用的核心机制分类，不能因出现 DP 或容斥就默认归为 algorithm。

### Details
归档 GCD Graph 时，先错误拆出 Debugging 条目，随后又把整题归入 algorithm。用户进一步指出，本题核心是“用邻近质数把大段最短路二值化，只暴力短尾”的非显然观察；容斥和 DP 只是该观察后的实现，因此应整体归入 trick。

### Suggested Action
单题总结默认只生成一个主条目：若价值在通用算法框架、状态模型或数据结构，归入 algorithm；若价值在性质观察、降维、特殊中转或把大问题压成小尾部，归入 trick。实现中的调试错误通常写入 Pitfalls，不单独建 Debugging 条目。对用户提供的题目链接必须写入 Source。

### Metadata
- Source: user_feedback
- Related Files: algorithms.md, tricks.md
- Tags: xcpc-summarize, classification, source-link
- Pattern-Key: xcpc.summary.classification
- Recurrence-Count: 2
- First-Seen: 2026-07-22
- Last-Seen: 2026-07-22

### Resolution
- **Resolved**: 2026-07-22T20:30:00+08:00
- **Notes**: 已从 algorithms.md 删除 GCD Graph，并在 tricks.md 以“用邻近质数压缩 GCD 最短路”重新归档；题目链接、证明、实现和边界均保留。

---

## [LRN-20260722-002] correction

**Logged**: 2026-07-22T20:45:00+08:00
**Priority**: high
**Status**: resolved
**Area**: docs

### Summary
XCPC Markdown 索引必须直接兼容 Typora，不能把内部去重或 TOC 标记写入用户文档。

### Details
旧版 `xcpc-summarize` 输出 `<!-- xcpc-toc:start/end -->` 和 `<!-- xcpc-id: ... -->`，并生成普通锚点列表。用户在本地 Typora 中看到了这些内部字段，且目录未按 Typora 语法渲染。

### Suggested Action
索引统一输出 `# TOC` 后接 `[TOC]`；禁止生成 `xcpc-*` HTML 注释；依靠规范化 H2 标题和别名去重。对旧文件提供 hash-locked `migrate -> apply -> check` 迁移流程，并检查无元数据残留和重复迁移零差异。

### Metadata
- Source: user_feedback
- Related Files: algorithms.md, tricks.md, C:/Users/Lenovo/.codex/skills/xcpc-summarize/SKILL.md, C:/Users/Lenovo/.codex/skills/xcpc-summarize/scripts/xcpc_notes.py
- Tags: xcpc-summarize, typora, toc, markdown
- Pattern-Key: xcpc.typora.output_contract
- Recurrence-Count: 1
- First-Seen: 2026-07-22
- Last-Seen: 2026-07-22

### Resolution
- **Resolved**: 2026-07-22T20:45:00+08:00
- **Notes**: 技能已改用 `[TOC]`，新增 legacy migration，现有两个索引已迁移且通过幂等性检查。

---

## [LRN-20260725-001] best_practice

**Logged**: 2026-07-25T18:24:00+08:00
**Priority**: high
**Status**: pending
**Area**: tests

### Summary
二维中点构造不能把两个一维合法操作序列逐项拼接；必须递归维护完整二维前驱点。

### Details
在 Middle Point 的构造中，横纵坐标分别可达只说明对应的一维数值出现过，不保证笛卡尔积点已经加入集合。对 `A=B=8, X=3, Y=5`，独立序列逐项拼接后第二步会使用 `(0,4)` 和 `(4,8)`，但第一步只新建了 `(4,4)`，因此两个端点均不存在。

### Suggested Action
先求同时容纳两坐标的最小层数 `k`，再从目标二维点反推：每层选择一个初始矩形角点，并递归构造唯一的上一层二维前驱。验证构造输出时，维护实际点集，逐行检查两个端点已存在、中点为格点且最终目标被加入。

### Metadata
- Source: error
- Related Files: 2026/7/25/template.cpp
- Tags: xcpc, constructive, midpoint, dependency, wrong-answer
- Pattern-Key: xcpc.constructive.coordinate-zip
- Recurrence-Count: 1
- First-Seen: 2026-07-25
- Last-Seen: 2026-07-25

---

## [LRN-20260727-001] best_practice

**Logged**: 2026-07-27T14:31:00+08:00
**Priority**: medium
**Status**: resolved
**Area**: tests

### Summary
XCPC 训练题单的题量、平台比例和替换题冲突必须从机器可读计划计算，不能依赖文案或手工计数。

### Details
30 天数据结构计划的文案目标曾写为洛谷约 40%、Codeforces 约 60%，但任务集合的真实比例不同。如果校验器或网页读取持久化目标，就会把目标值误报成真实值。后续用户再次确认：平台占比只应从 `stages[].tasks` 计算，替换候选不计入分母，计划文件无需保存目标或缓存比例。

### Suggested Action
以机器可读题目列表为唯一数据源，由 API、校验器和网页实时输出实际计数与百分比；禁止在题单 schema、模板或托管副本中写入 `platform_target` / `platform_ratio`。

### Metadata
- Source: conversation
- Related Files: training/data-structures-30d/data/plan.json, training/data-structures-30d/tools/verify.ps1
- Tags: xcpc, training-plan, validation, metrics
- Pattern-Key: xcpc.training.plan-metrics-from-data
- Recurrence-Count: 2
- First-Seen: 2026-07-27
- Last-Seen: 2026-08-04

### Resolution
- **Resolved**: 2026-07-27T14:31:00+08:00
- **Notes**: 校验器、API 和网页现只报告主任务真实比例；旧目标字段兼容读取后丢弃，规范化文件中不再保存比例。

---

## [LRN-20260727-002] correction

**Logged**: 2026-07-27T15:00:00+08:00
**Priority**: high
**Status**: resolved
**Area**: workflow

### Summary
用户只要求列出训练题单时，应交付纯题单，不要擅自扩展成训练管理器、状态文件、模板或自动化工具。

### Details
“执行这份计划”在本次上下文中指把题目安排落实为可直接阅读的题单，而不是搭建训练工作区。额外生成脚本、进度状态、对拍模板和每日代码目录扩大了交付范围，也增加了用户不需要的维护成本。

### Suggested Action
遇到“列题单”“给题目号”“只要计划”等请求时，默认输出或保存一份自包含的 Markdown；只有用户明确要求追踪、提醒、生成目录或脚本时才添加自动化能力。

### Metadata
- Source: user_feedback
- Related Files: training/data-structures-30d/README.md
- Tags: xcpc, training-plan, scope, automation
- Pattern-Key: xcpc.training.list-only-scope
- Recurrence-Count: 1
- First-Seen: 2026-07-27
- Last-Seen: 2026-07-27

### Resolution
- **Resolved**: 2026-07-27T15:00:00+08:00
- **Notes**: 已移除训练管理器、状态、模板、对拍及每日工作目录，只保留纯 Markdown 题单。

---

## [LRN-20260803-001] correction

**Logged**: 2026-08-03T11:45:00+08:00
**Priority**: low
**Status**: resolved
**Area**: docs

### Summary
XCPC 算法索引应保持用户指定的抽象层级，不夹带具体题目推导。

### Details
笛卡尔树条目最初附带了具体题目与多个展开应用；用户要求收紧为建树过程和“区间极值取点分治可在树上 DP”的通用结论。

### Suggested Action
归档算法知识时默认保留模型、不变量、实现形状、复杂度和用户指定的泛化应用；没有明确要求时不加入题目实例。

### Metadata
- Source: user_feedback
- Related Files: algorithms.md
- Tags: xcpc-summarize, scope, abstraction
- Pattern-Key: xcpc.summary.scope
- Recurrence-Count: 1
- First-Seen: 2026-08-03
- Last-Seen: 2026-08-03

### Resolution
- **Resolved**: 2026-08-03T11:45:00+08:00
- **Notes**: 已移除具体题目来源和展开应用，保留通用树上 DP 结论。

---
## [LRN-20260805-001] best_practice

### Summary
按题持久化的流式 AI 工作台必须同时约束服务端会话生命周期和前端异步响应归属。

### Details
仅缓存一个全局 `conversation_id` 会在切换题号后把新问题发往旧题会话；仅清空 DOM 则会在刷新后恢复旧消息。前端应同时保存题目规范键、conversation 所属题目、切换 epoch 和当前 SSE AbortController，并在 conversation、题面、补丁等异步结果落地前复核题目与 epoch。清除历史应归档旧 conversation 并为同一 active attempt 原子创建空 conversation，不能删除旧消息，否则 `close` 会低报已经使用过的最高提示等级，run、token 与补丁审计也会丢失。

### Suggested Action
新增可切换的持久 AI 面板时使用 `resource key + server id + epoch + cancellation` 状态模型；把“用户可见上下文重置”和“审计事实删除”设计成两个不同操作，并对流式进行中的重置返回冲突。

### Metadata
- Source: implementation_review
- Related Files: tools/acm_agent/service.py, tools/acm_agent/web.py, tools/acm_agent/web_static/app.js
- Tags: acm, ai, conversation, sse, async-race, audit
- Pattern-Key: acm.ai.problem-scoped-conversation
- Recurrence-Count: 1
- First-Seen: 2026-08-05
- Last-Seen: 2026-08-05

---

## [LRN-20260805-002] best_practice

**Logged**: 2026-08-05T18:00:00+08:00
**Priority**: high
**Status**: resolved
**Area**: workflow

### Summary
AI 知识归档应把语义生成和文件写入拆成可审计、可恢复的 proposal saga。

### Details
模型只生成结构化 schema 与条目，服务端负责确定性渲染、重复检测和 diff。Preview 固化目标基线、schema 哈希、候选字节和 proposal revision；Refresh 不调用模型，只重建候选与 diff；Apply 再校验路径、基线和 revision，通过同目录原子替换写入，并以备份、写后哈希、状态恢复和 hash-guarded revert 处理数据库或进程中断。普通讲解、close 和生成预览都不构成写入授权。

### Suggested Action
凡是 AI 修改用户维护的本机文档，都采用 `structured output -> deterministic render -> persisted preview -> explicit apply`，并同时使用路径注册、基线哈希、修订号、进程锁、备份和启动恢复约束跨文件系统与数据库事务。

### Metadata
- Source: implementation_review
- Related Files: tools/acm_agent/knowledge.py, tools/acm_agent/knowledge_io.py, tools/acm_agent/service.py
- Tags: acm, markdown, ai, atomic-write, revision, recovery
- Pattern-Key: acm.markdown-summary.proposal-saga
- Recurrence-Count: 1
- First-Seen: 2026-08-05
- Last-Seen: 2026-08-05

---

## [LRN-20260805-003] correction

**Logged**: 2026-08-05T20:00:00+08:00
**Priority**: high
**Status**: resolved
**Area**: frontend

### Summary
知识总结界面应由已保存目标决定 schema，并把重复合并与文件 diff 留在服务端策略层。

### Details
Algorithms/Tricks 是固定文件与固定 schema 的组合，若又在 schema 下拉中列为 preset，会让用户重复表达同一选择。预览区展示 Unified diff 和“合并/新建”选择也暴露了不必要的内部写入机制。更直接的模型是：目标选择决定已保存 schema；页面只显示可编辑 Markdown 和安全渲染；服务端仅以规范化 `Source` 题号作为题目身份，唯一精确匹配时把该旧卡与本次上下文一起交给模型语义合并，标题或模糊相似则新增。

### Suggested Action
为结构化知识库设计 UI 时使用 `target -> stored schema` 单一来源；candidate diff 只用于内部审计与 hash-guarded apply，不进入公开 proposal；实体去重优先使用稳定业务键，不把模糊标题相似度升级为默认覆盖或用户必选步骤。

### Metadata
- Source: user_feedback
- Related Files: tools/acm_agent/service.py, tools/acm_agent/knowledge.py, tools/acm_agent/web_static
- Tags: acm, markdown, schema, duplicate, safe-preview, ui
- See Also: LRN-20260805-002
- Pattern-Key: acm.markdown-summary.target-derived-ui
- Recurrence-Count: 1
- First-Seen: 2026-08-05
- Last-Seen: 2026-08-05

### Resolution
- **Resolved**: 2026-08-05T20:00:00+08:00
- **Notes**: 已自动注册现有 Algorithms/Tricks 目标，删除重复 preset/策略控件与公开 diff，固定 Source 精确匹配 AI 合并，并将训练卡操作栏底部对齐。

---

## [LRN-20260805-011] best_practice

**Logged**: 2026-08-05T22:43:09+08:00
**Priority**: high
**Status**: resolved
**Area**: backend

### Summary
一次性 AI 代码修复必须保留原任务前缀，并把旧代码与结构化验收条件作为独立追加消息。

### Details
只有“附上旧代码和报错”并不足以让 non-thinking 模型可靠修复复杂 generator。若 contract 允许空 requirements、嵌套 profile 被不稳定字符串化，或 repair 改写原角色请求，模型既失去清晰约束，也无法复用公共前缀缓存。对于 small/large 混合生成器，还必须显式区分：small 可在严格上限内朴素模拟以覆盖边界，large 每条记录只能做 O(log n) 或更低工作，并应使用恒等或天然合法参数避免维护昂贵动态状态。

### Suggested Action
生成式修复采用 `normalized contract -> stable role request -> appended old code + structured diagnostic + acceptance checklist -> independent re-audit`；提示版本变化必须进入本地 cache identity，精确失效旧证明。

### Metadata
- Source: error
- Related Files: tools/acm_agent/stress_ai.py, tools/acm_agent/stress_runtime.py
- Tags: acm, stress, generator, repair, prompt-cache, contract
- See Also: LRN-20260805-009, LRN-20260805-006, ERR-20260805-005
- Pattern-Key: acm.ai-stress.generator-repair-context
- Recurrence-Count: 1
- First-Seen: 2026-08-05
- Last-Seen: 2026-08-05

### Resolution
- **Resolved**: 2026-08-05T22:43:09+08:00
- **Notes**: 已实现 contract 归一化、基础 generator requirements、分层 repair 消息和 prompt-v2 缓存失效，并新增针对性测试。

---
