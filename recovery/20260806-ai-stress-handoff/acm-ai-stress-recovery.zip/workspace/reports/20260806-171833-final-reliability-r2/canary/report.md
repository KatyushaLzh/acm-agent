# AI Stress Benchmark Report

## Outcome

| Metric | Value |
|---|---:|
| Attempts | 1 |
| Successes | 0 |
| Success rate | 0.0% |
| First-round success rate | 0.0% |
| Unsafe applies | 0 |
| Successful time p50 / p95 | n/a / n/a s |
| Successful tokens p50 / p95 | n/a / n/a |
| Provider requests | 6.000 |
| Retries | 0.000 |

## Failure stages

| Stage | Attempts |
|---|---:|
| prepare_helpers | 1 |

## Repair roles

| Role | Attempts |
|---|---:|
| validator | 1 |

## Stage duration percentiles

| Stage | p50 | p95 | max |
|---|---:|---:|---:|
| check_isolation | 2.776 | 2.776 | 2.776 |
| extract_contract | 9.352 | 9.352 | 9.352 |
| extract_contract/provider_request | 9.282 | 9.282 | 9.282 |
| generate_blueprint/provider_request | 4.351 | 4.351 | 4.351 |
| generate_brute | 0.000 | 0.000 | 0.000 |
| generate_brute/provider_request | 2.806 | 2.806 | 2.806 |
| generate_generator | 4.353 | 4.353 | 4.353 |
| generate_generator/provider_request | 10.254 | 10.254 | 10.254 |
| generate_validator | 0.000 | 0.000 | 0.000 |
| generate_validator/provider_request | 14.241 | 14.241 | 14.241 |
| prepare_reference | 48.816 | 48.816 | 48.816 |
| queued | 0.035 | 0.035 | 0.035 |

## Token category percentiles

| Category | p50 | p95 | max |
|---|---:|---:|---:|
| completion_tokens | 6203.000 | 6203.000 | 6203.000 |
| prompt_cache_hit_tokens | 1408.000 | 1408.000 | 1408.000 |
| prompt_cache_miss_tokens | 14766.000 | 14766.000 | 14766.000 |
| prompt_tokens | 16174.000 | 16174.000 | 16174.000 |
| total_tokens | 22377.000 | 22377.000 | 22377.000 |
