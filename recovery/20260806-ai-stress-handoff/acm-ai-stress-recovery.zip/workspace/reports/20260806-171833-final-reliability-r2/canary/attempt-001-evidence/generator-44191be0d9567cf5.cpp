#include <algorithm>
#include <cstdint>
#include <ostream>
#include <random>
#include <string>
#include <vector>

namespace {

struct Fenwick {
    int n;
    std::vector<int> bit;
    explicit Fenwick(int n_) : n(n_), bit(n_ + 1, 0) {}
    void add(int idx, int delta) {
        for (; idx <= n; idx += idx & -idx) bit[idx] += delta;
    }
    int sum(int idx) const {
        int res = 0;
        for (; idx > 0; idx -= idx & -idx) res += bit[idx];
        return res;
    }
    int kth(int k) const {
        int idx = 0;
        int bitmask = 1;
        while ((bitmask << 1) <= n) bitmask <<= 1;
        for (; bitmask; bitmask >>= 1) {
            int next = idx + bitmask;
            if (next <= n && bit[next] < k) {
                idx = next;
                k -= bit[next];
            }
        }
        return idx + 1;
    }
};

struct SmallState {
    std::vector<int> seq;
    explicit SmallState(const std::vector<int>& init) : seq(init) {}
    int find_pos(int val) const {
        for (int i = 0; i < (int)seq.size(); ++i) {
            if (seq[i] == val) return i;
        }
        return -1;
    }
    void top(int val) {
        int p = find_pos(val);
        seq.erase(seq.begin() + p);
        seq.insert(seq.begin(), val);
    }
    void bottom(int val) {
        int p = find_pos(val);
        seq.erase(seq.begin() + p);
        seq.push_back(val);
    }
    void insert(int val, int t) {
        int p = find_pos(val);
        int q = p + t;
        seq.erase(seq.begin() + p);
        seq.insert(seq.begin() + q, val);
    }
    int ask(int val) const { return find_pos(val) + 1; }
    int query(int k) const { return seq[k - 1]; }
};

struct LargeState {
    int n;
    std::vector<int> pos;
    Fenwick bit;
    LargeState(const std::vector<int>& init) : n((int)init.size()), pos(n + 1), bit(n) {
        for (int i = 0; i < n; ++i) {
            pos[init[i]] = i + 1;
            bit.add(i + 1, 1);
        }
    }
    void top(int val) {
        int p = pos[val];
        bit.add(p, -1);
        bit.add(1, 1);
        pos[val] = 1;
    }
    void bottom(int val) {
        int p = pos[val];
        bit.add(p, -1);
        bit.add(n, 1);
        pos[val] = n;
    }
    void insert(int val, int t) {
        int p = pos[val];
        int rank = bit.sum(p);
        int q = rank + t;
        bit.add(p, -1);
        int newp = bit.kth(q);
        bit.add(newp, 1);
        pos[val] = newp;
    }
    int ask(int val) const { return bit.sum(pos[val]); }
    int query(int k) const { return bit.kth(k); }
};

void emit_small_lower_bound(std::ostream& out) {
    out << "1 0\n";
    out << "1\n";
}

void emit_small_random(unsigned long long seed, std::ostream& out) {
    std::mt19937_64 rng(seed);
    int n = 5;
    int m = 8;
    std::vector<int> init = {1, 2, 3, 4, 5};
    out << n << " " << m << "\n";
    for (int i = 0; i < n; ++i) {
        if (i) out << " ";
        out << init[i];
    }
    out << "\n";

    SmallState st(init);
    std::vector<std::string> ops;
    ops.reserve(m);

    auto add_top = [&](int s) {
        st.top(s);
        ops.push_back("Top " + std::to_string(s));
    };
    auto add_bottom = [&](int s) {
        st.bottom(s);
        ops.push_back("Bottom " + std::to_string(s));
    };
    auto add_insert = [&](int s, int t) {
        st.insert(s, t);
        ops.push_back("Insert " + std::to_string(s) + " " + std::to_string(t));
    };
    auto add_ask = [&](int s) {
        ops.push_back("Ask " + std::to_string(s));
    };
    auto add_query = [&](int k) {
        ops.push_back("Query " + std::to_string(k));
    };

    add_top(3);
    add_bottom(1);
    add_insert(2, 1);
    add_insert(4, -1);
    add_insert(5, 0);
    add_ask(2);
    add_query(3);
    add_ask(1);

    int r = (int)(rng() % 3);
    if (r == 0) {
        add_ask(1 + (int)(rng() % n));
    } else if (r == 1) {
        add_query(1 + (int)(rng() % n));
    } else {
        add_ask(1 + (int)(rng() % n));
    }

    for (const auto& op : ops) {
        out << op << "\n";
    }
}

void emit_large_upper_bound(std::ostream& out) {
    int n = 80000;
    int m = 80000;
    out << n << " " << m << "\n";
    for (int i = 1; i <= n; ++i) {
        if (i > 1) out << " ";
        out << i;
    }
    out << "\n";
    for (int i = 0; i < 40000; ++i) {
        out << "Ask 1\n";
    }
    for (int i = 0; i < 40000; ++i) {
        out << "Query 1\n";
    }
}

void emit_large_random(unsigned long long seed, std::ostream& out) {
    std::mt19937_64 rng(seed);
    int n = 80000;
    int m = 80000;
    std::vector<int> init(n);
    for (int i = 0; i < n; ++i) init[i] = i + 1;
    out << n << " " << m << "\n";
    for (int i = 0; i < n; ++i) {
        if (i) out << " ";
        out << init[i];
    }
    out << "\n";

    LargeState st(init);
    for (int i = 0; i < m; ++i) {
        unsigned long long r = rng() % 2;
        if (r == 0) {
            int s = 1 + (int)(rng() % n);
            out << "Ask " << s << "\n";
        } else {
            int k = 1 + (int)(rng() % n);
            out << "Query " << k << "\n";
        }
    }
}

}  // namespace

void acm_generate_case(unsigned long long seed, const std::string& profile,
                       const std::string& case_kind, std::ostream& out) {
    if (profile == "small" && case_kind == "lower_bound") {
        emit_small_lower_bound(out);
    } else if (profile == "small" && case_kind == "random") {
        emit_small_random(seed, out);
    } else if (profile == "large" && case_kind == "upper_bound") {
        emit_large_upper_bound(out);
    } else if (profile == "large" && case_kind == "random") {
        emit_large_random(seed, out);
    }
}
