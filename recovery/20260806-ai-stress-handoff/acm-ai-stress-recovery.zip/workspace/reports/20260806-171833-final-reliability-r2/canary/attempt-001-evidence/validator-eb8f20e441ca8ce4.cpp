#include <bits/stdc++.h>
using namespace std;

static string esc_json(const string& s) {
    string o;
    for (char c : s) {
        switch (c) {
            case '"': o += "\\\""; break;
            case '\\': o += "\\\\"; break;
            case '\b': o += "\\b"; break;
            case '\f': o += "\\f"; break;
            case '\n': o += "\\n"; break;
            case '\r': o += "\\r"; break;
            case '\t': o += "\\t"; break;
            default:
                if ((unsigned char)c < 0x20) {
                    char buf[8];
                    snprintf(buf, sizeof(buf), "\\u%04x", (unsigned char)c);
                    o += buf;
                } else {
                    o += c;
                }
        }
    }
    return o;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    auto fail = [&](const string& msg) {
        cerr << msg << "\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
        return 0;
    };

    int n, m;
    if (!(cin >> n >> m)) {
        return fail("ERR_READ_HEADER");
    }
    if (n < 1 || n > 80000) return fail("ERR_N_RANGE");
    if (m < 0 || m > 80000) return fail("ERR_M_RANGE");

    vector<int> perm(n);
    vector<bool> seen(n + 1, false);
    for (int i = 0; i < n; ++i) {
        if (!(cin >> perm[i])) return fail("ERR_READ_PERM");
        if (perm[i] < 1 || perm[i] > n) return fail("ERR_PERM_VALUE");
        if (seen[perm[i]]) return fail("ERR_PERM_DUP");
        seen[perm[i]] = true;
    }

    list<int> lst;
    for (int x : perm) lst.push_back(x);

    unordered_map<int, list<int>::iterator> pos;
    {
        auto it = lst.begin();
        for (int i = 0; i < n; ++i, ++it) {
            pos[perm[i]] = it;
        }
    }

    int records = 0;
    vector<string> tags;
    bool has_top = false, has_bottom = false, has_insert = false, has_ask = false, has_query = false;
    bool has_c4_min = false, has_c4_max = false, has_c5_min = false, has_c5_max = false;
    bool has_c6_min = false, has_c6_max = false;

    auto add_tag = [&](const string& t) {
        if (find(tags.begin(), tags.end(), t) == tags.end()) tags.push_back(t);
    };

    for (int i = 0; i < m; ++i) {
        string op;
        if (!(cin >> op)) return fail("ERR_READ_OP");
        ++records;

        if (op == "Top") {
            int s;
            if (!(cin >> s)) return fail("ERR_READ_ARG");
            if (s < 1 || s > n) return fail("ERR_S_RANGE");
            if (pos.find(s) == pos.end()) return fail("ERR_S_MISSING");
            auto it = pos[s];
            lst.splice(lst.begin(), lst, it);
            has_top = true;
            if (s == 1) has_c4_min = true;
            if (s == n) has_c4_max = true;
        } else if (op == "Bottom") {
            int s;
            if (!(cin >> s)) return fail("ERR_READ_ARG");
            if (s < 1 || s > n) return fail("ERR_S_RANGE");
            if (pos.find(s) == pos.end()) return fail("ERR_S_MISSING");
            auto it = pos[s];
            lst.splice(lst.end(), lst, it);
            has_bottom = true;
            if (s == 1) has_c4_min = true;
            if (s == n) has_c4_max = true;
        } else if (op == "Insert") {
            int s, t;
            if (!(cin >> s >> t)) return fail("ERR_READ_ARG");
            if (s < 1 || s > n) return fail("ERR_S_RANGE");
            if (t < -1 || t > 1) return fail("ERR_T_RANGE");
            if (pos.find(s) == pos.end()) return fail("ERR_S_MISSING");
            auto it = pos[s];
            if (t == -1) {
                if (it == lst.begin()) return fail("ERR_INSERT_TOP");
                auto prev_it = prev(it);
                lst.splice(prev_it, lst, it);
            } else if (t == 1) {
                auto nxt = next(it);
                if (nxt == lst.end()) return fail("ERR_INSERT_BOTTOM");
                auto target = next(nxt);
                lst.splice(target, lst, it);
            } else {
                // t == 0: no movement, just validate s exists (already done)
            }
            has_insert = true;
            if (s == 1) has_c4_min = true;
            if (s == n) has_c4_max = true;
            if (t == -1) has_c6_min = true;
            if (t == 1) has_c6_max = true;
            if (t == 0) { has_c6_min = true; has_c6_max = true; }
        } else if (op == "Ask") {
            int s;
            if (!(cin >> s)) return fail("ERR_READ_ARG");
            if (s < 1 || s > n) return fail("ERR_S_RANGE");
            if (pos.find(s) == pos.end()) return fail("ERR_S_MISSING");
            has_ask = true;
            if (s == 1) has_c4_min = true;
            if (s == n) has_c4_max = true;
        } else if (op == "Query") {
            int k;
            if (!(cin >> k)) return fail("ERR_READ_ARG");
            if (k < 1 || k > n) return fail("ERR_K_RANGE");
            has_query = true;
            if (k == 1) has_c5_min = true;
            if (k == n) has_c5_max = true;
        } else {
            return fail("ERR_UNKNOWN_OP");
        }
    }

    string extra;
    if (cin >> extra) return fail("ERR_TRAILING");

    if (has_top) add_tag("auto_operation_top");
    if (has_bottom) add_tag("auto_operation_bottom");
    if (has_insert) add_tag("auto_operation_insert");
    if (has_ask) add_tag("auto_operation_ask");
    if (has_query) add_tag("auto_operation_query");
    if (has_c4_min) add_tag("auto_c4_minimum");
    if (has_c4_max) add_tag("auto_c4_maximum");
    if (has_c5_min) add_tag("auto_c5_minimum");
    if (has_c5_max) add_tag("auto_c5_maximum");
    if (has_c6_min) add_tag("auto_c6_minimum");
    if (has_c6_max) add_tag("auto_c6_maximum");

    int dim_n = n;
    int dim_m = m;

    cout << "{\"valid\":true,\"dimensions\":{\"n\":" << dim_n << ",\"m\":" << dim_m << "},\"coverage_tags\":[";
    for (size_t i = 0; i < tags.size(); ++i) {
        if (i) cout << ",";
        cout << "\"" << esc_json(tags[i]) << "\"";
    }
    cout << "],\"records\":" << records << "}\n";

    return 0;
}
