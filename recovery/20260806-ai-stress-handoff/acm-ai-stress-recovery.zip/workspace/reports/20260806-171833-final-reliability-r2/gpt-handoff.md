# GPT 交接报告 — r2 P2596 Canary 失败（未进入正式批次）

## 1. 测试阶段

阶段 2（P2596 canary，1 次付费 setup）。canary 失败，按方案立即停止，**未执行**阶段 3–8 中任何步骤（无正式付费测试）。

## 2. 源码 SHA 清单

- `source-manifest-before.json` 与 `source-manifest-after.json`（76 个文件）**完全一致**。
- 相比 r1 批次（20260806-151111）有 7 个文件变更（改进）：`tools\acm_agent\stress.py`、`stress_ai.py`、`stress_benchmark.py`、`stress_runtime.py`、`tests\test_stress.py`、`tests\test_stress_ai.py`、`tests\test_stress_runtime.py`。
- 目录：`D:\code\acm\.acm\reports\stress-reliability\20260806-171833-final-reliability-r2\`

## 3. Canary 结果

| 指标 | 结果 | 门槛 | 达标 |
|---|---|---|---|
| ok | **false** | true | **否** |
| unsafe_apply | false | false | 是 |
| applied_bundle_count | 0（未 apply） | 1 | 否 |
| run.status | 无（setup 失败） | completed | 否 |
| 16 small + 4 large = 20 | 无 | 16/4/20 | 否 |
| warm cache | null（未到 warm 阶段） | 0/0 | 否 |
| cleanup_worker_ids | [] | 无 | 是 |
| 残留进程 | 无测试残留 | 无 | 是 |
| protected workspace | 未变化 | 不变 | 是 |
| 模型泄露 | 无 | 无 | 是 |

## 4. 失败明细

- problem_id=P2596，platform=luogu，attempt_index=1，cache_mode=cold，workspace/database 全新。
- failure_stage：`prepare_helpers`
- error.code：`stress_input_validation_failed`
- error.message：validator 未通过 audit 前独立门禁，修复 1 次后仍被拒。
- 机器诊断（local_confirmation.reproduced=true）：
  - 生成输入 `3 2\n1 2 3\nTop 3\nInsert 3 -1\n`（sha256 `f3db73b3…`）
  - validator stderr：`ERR_INSERT_TOP` —— **该输入确实非法**：`Top 3` 已将书 3 移到顶部，随后 `Insert 3 -1` 要求书 3 再向上移，非法（delta=-1 时书必须在顶部之下）。独立 validator 拒绝正确；失败方是模型生成的 generator 输入与 validator 之间的语义不一致，且修复后仍产生非法 case。
- profile=contract_probe，case_kind=vp3:valid（r2 新增的契约探测阶段），seed=7204423154482994183。
- stage_seconds：extract_contract=9.35、generate_blueprint/provider_request=4.35、generate_generator/provider_request=10.25、generate_validator/provider_request=14.24、prepare_reference=48.82、queued=0.03、check_isolation=2.78。
- tokens 分类：prompt=16174 / completion=6203 / prompt_cache_hit=1408 / prompt_cache_miss=14766 / total=22377。
- provider_requests：http=6。
- repair_roles：{validator: 1}。
- wall_seconds：65.33（≤ 门槛内，但整体失败）。

## 5. 证据目录（绝对路径）

`D:\code\acm\.acm\reports\stress-reliability\20260806-171833-final-reliability-r2\canary\attempt-001-evidence\`
（含 `evidence.json`、`batch-plan.json`、`attempts.raw.jsonl`、4 份报告产物在 `canary\` 下）

## 6. 初始候选与修复候选路径

- 初始：`attempt-001-evidence\validator-8678893eb76b2bbf.cpp`
- 修复：`attempt-001-evidence\validator-eb8f20e441ca8ce4.cpp`
- 其他候选：`generator-44191be0d9567cf5.cpp`、`brute-0deb28abdcec9f86.cpp`、`reference-ccf8d08de663b737.cpp`

## 7. 候选间最小 diff

validator 初始/修复对 SequenceMatcher ratio=0.9917（差异约 0.8%）——修复几乎未改变判定逻辑，属近似克隆式"修复"。

## 8. 可复现性

- source：fixture SHA-256 锁定（primary.cpp sha256 `bc5f170b…847916`，与 r1 相同），可精确复现。
- contract：模型生成，不可逐位复现。
- profile/case_kind/seed：contract_probe / vp3:valid / 7204423154482994183（诊断内已记录，机器门禁 local_confirmation 可复现拒绝）。
- cold setup seed = attempt_index×1_000_003+17 = 1000020；warm 未达到。

## 9. 泄露与沙箱检查

- 全证据文件扫描 primary.cpp、用户主解 `2026\8\5\P2596.cpp`、gold oracle 标记（gold_p2596/def gold_/class GoldProblem）：**无命中**。
- protected workspace：未变化（批次内指纹检查通过，前后清单一致）。
- 残留进程：无 run-*/solution/generator/validator/brute/reference/stress；仅 3 个测试前已存在、与测试无关的 `target` 进程（PID 28184、36516、37872）。
- r2 新增 `gold_validator_certification` 字段在 attempt 结果中为 null（未到达认证阶段）。

## 10. 建议分类

**model_random_failure**（主分类）。

依据：独立 validator 对生成输入的拒绝经 local_confirmation 复现且判定正确（ERR_INSERT_TOP，输入本身非法）；模型生成的 generator 输入与 validator 语义不一致，修复候选与初始几乎相同（0.8% 差异），1 次修复未解决。本地门禁、预算、无泄露、无 unsafe apply 均行为正确；失败集中在模型输出质量。未提供题目特化修复，未编辑任何代码。
