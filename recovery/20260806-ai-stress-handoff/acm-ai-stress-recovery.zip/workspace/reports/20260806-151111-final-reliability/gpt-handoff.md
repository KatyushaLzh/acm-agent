# GPT 交接报告 — P2596 正式 Cold 20 批次未达标

## 1. 测试阶段

阶段 3（P2596 正式 cold 20 次）。阶段 1、2 已通过；阶段 3 门槛失败后按方案停止，**未执行**阶段 4/5/6/7/8 中任何付费或后续步骤（阶段 6、7、8 未运行）。

## 2. 源码 SHA 清单

- `source-manifest-before.json` 与 `source-manifest-after.json`（76 个文件：tools\acm_agent\*.py、tests\test_stress*.py、tests\fixtures\stress_live\core8\**）**完全一致**，本批次有效。
- 目录：`D:\code\acm\.acm\reports\stress-reliability\20260806-151111-final-reliability\`

## 3. 批次结果

| 指标 | 结果 | 门槛 | 达标 |
|---|---|---|---|
| P2596 成功 | **14/20** | ≥16/20 | **否** |
| unsafe apply | 0 | 0 | 是 |
| 成功 wall p50 / p95 | 109.5 s / 167.4 s | ≤240 / ≤480 | 是 |
| 成功 tokens p50 / p95 | 31039 / 61632 | ≤45000 / ≤80000 | 是 |
| 单 setup 最大 tokens | 64107（失败 attempt 14） | ≤100000 | 是 |
| warm cache | 1 次验证（attempt 1）：0 requests / 0 tokens | 0 / 0 | 是 |

停止条件核查（全部 20 次完成，batch API 为整体调用）：
- unsafe_apply=true：无。
- 第 5 次失败后 16/20 不可达：第 5 次失败为 attempt 17（当时 14 成功、剩 3 次，理论上限 17）；第 6 次失败为 attempt 18（理论上限 16，仍等于门槛）；最终 14/20 未达标。该条件在批内未严格触发。
- 连续 3 次相同 failure_stage+error.code：最多连续 2 次（attempt 9、10 均为 extract_contract/invalid_stress_contract），未触发。
- 连续 3 次 provider 网络故障：无。
- protected workspace 变化：无（批次内检查通过 + 清单一致）。
- 模型收到 primary.cpp / gold oracle / 用户主解：**证据扫描未发现**（见第 9 节）。
- 100000 token 硬上限 fail-closed：全部 attempts ≤100000。

## 4. 失败明细（problem_id=P2596，platform=luogu，cache_mode=cold）

| attempt | failure_stage | error.code | wall_s | total_tokens | provider http | repair_roles | tokens 分类（prompt/comp/cache_hit/cache_miss/reasoning） |
|---|---|---|---|---|---|---|---|
| 2 | prepare_helpers | stress_generated_input_invalid | 117.4 | 36646 | 8 | generator:2 | 24752/11894/5504/19248/4096 |
| 9 | extract_contract | invalid_stress_contract | 16.5 | 6445 | 2 | {} | 3861/2584/2816/1045/- |
| 10 | extract_contract | invalid_stress_contract | 16.2 | 6221 | 2 | {} | 3785/2436/2688/1097/- |
| 14 | preflight_helpers | stress_input_validation_failed | 119.1 | 64107 | 11 | validator:1 | 48944/15163/11904/37040/- |
| 17 | prepare_helpers | stress_generated_input_invalid | 116.8 | 44025 | 9 | generator:2 | 30075/13950/9856/20219/4096 |
| 18 | extract_contract | invalid_stress_contract | 18.4 | 7038 | 2 | {} | 4126/2912/2688/1438/- |

错误摘要：
- attempt 2 / 17：generator 两次修复后仍被独立 validator 拒绝（attempt 2 stderr `E29 8`，seed 450140920998916557；attempt 17 stderr `ERR_LEGAL 4`，seed 3602785663924035039），local_confirmation.reproduced=true。
- attempt 9：contract `syntax.sections[2].fields[0]` 含未知字段 `source`。
- attempt 10：contract `syntax.sections[2].fields[0].type` 类型不支持。
- attempt 14：validator 观察输出 dimensions/tags/records 非法（seed 2552777760621827706），1 次修复未通过 preflight。
- attempt 18：contract evidence 无法正确绑定当前操作（details 含 statement 引文）。

stage_seconds 完整值：见各 evidence JSON（`attempt-0NN-evidence/evidence.json` 内 `budget_snapshot.stage_timings`）。

## 5. 证据目录（绝对路径）

- 正式批次：`D:\code\acm\.acm\reports\stress-reliability\20260806-151111-final-reliability\formal20\`
  - `attempts.raw.jsonl`（20 行）、`attempts.jsonl`、`attempts.csv`、`summary.json`、`report.md`、`batch-plan.json`
  - 失败证据：`attempt-002-evidence`、`attempt-009-evidence`、`attempt-010-evidence`、`attempt-014-evidence`、`attempt-017-evidence`、`attempt-018-evidence`（各含 `evidence.json` 及候选源文件）
- Canary：`...\20260806-151111-final-reliability\canary\`（ok=true，未计入统计）
- 被中止批次（执行器自身日志文件名与受保护路径扫描冲突，见 incident-001，已排除）：`...\formal20` 之外残留目录 `...\p2596-formal20\`（1 条付费 attempt，不计入）。

## 6. 初始候选与修复候选路径

- attempt 2：`attempt-002-evidence\generator-6560680ea57e7c96.cpp`（初始）、`generator-d26508e4171394fa.cpp`（修复 1）
- attempt 14：`attempt-014-evidence\validator-bbcd0e9aaa72f420.cpp`（初始）、`validator-de494bd422f41daf.cpp`（修复 1）
- attempt 17：`attempt-017-evidence\generator-39bd3de75364dce9.cpp`、`generator-c068c9c8ff8ff03f.cpp`（修复 1）、`generator-a5dd1f0f9fa7f451.cpp`（修复 2）
- attempt 9 / 10 / 18：无候选（contract 提取阶段即失败）

## 7. 候选间最小 diff（SequenceMatcher 最高相似度）

- attempt 2：generator 对 ratio 0.118（两次候选几乎无关，非微调修复）
- attempt 14：validator 对 ratio 0.894（最小差异约 10.6%）
- attempt 17：generator 对 ratio 0.858（最小差异约 14.2%）

## 8. 可复现性

- source：fixture 由 SHA-256 锁定（primary.cpp sha256 `bc5f170b902149596f59440520ddb964a143aaeaf4d58a721e15f94e84847916`），可精确复现。
- contract：模型生成，**不可逐位复现**（非确定性采样）。
- profile/case_kind：全部失败均为 small / random。
- seed：cold setup seed = attempt_index×1_000_003+17；warm seed = +29。case 种子见错误 details。

## 9. 泄露与沙箱检查

- 全 20 个 evidence 目录扫描 primary.cpp 前 200 字符、用户主解 `2026\8\5\P2596.cpp`、gold oracle 标记（`gold_p2596`、`def gold_`、`class GoldProblem`）：**无命中**。
- protected workspace：未变化。
- 残留进程：无 `run-*`/solution/generator/validator/brute/reference/stress 进程；仅存 3 个测试前即存在、与测试无关的 `target` 进程（PID 28184、36516、37872）。

## 10. 建议分类

**model_random_failure**（主分类）。

依据：所有失败均为模型产物被本地门禁正确拒绝（invalid_stress_contract ×3、generator 两次修复后输入仍非法 ×2、validator 观察非法 ×1），且 local_confirmation 均 reproduced=true；本地门禁、预算 fail-closed、warm cache、无泄露、无 unsafe apply、时间/token 分位数全部达标，说明管线行为正确，失败集中在模型输出质量。未提供题目特化修复，未编辑任何代码。
