# Incident 001 — Aborted P2596 formal20 batch (harness artifact, not implementation)

- Time: 2026-08-06 15:16:20 — 15:18:10
- Phase: 3 (P2596 formal cold 20), first batch directory `p2596-formal20`
- Symptom: after paid attempt 1 (ok=true, wall=107.5s, tokens=29933, warm cache 0/0),
  `run_live_ai_cold_batch` raised
  `ApplicationColdGateError("protected workspace changed during live cold benchmark")`.
- Root cause (executor harness artifact): the monitor log file was named
  `p2596-formal20-execution-log.txt`. `_live_protected_paths` scans the whole
  protected workspace for files whose names match each problem-id prefix
  (`p2596.` / `p2596_` / `p2596-`), so the log file was part of the batch's
  baseline fingerprint. The monitor appended heartbeats/rows to it while the
  batch ran, changing the fingerprint after attempt 1.
- The implementation gate behaved exactly as designed (fail-closed on protected
  workspace change). No source, helper, fixture, database, or real user state
  was modified. No residual processes were left (`run-*`/solution/generator/
  validator/brute/reference/stress none present after abort).
- Staging/backup files under `.acm\stress-staging` and `.acm\ai-backups\stress`
  verified stable (mtimes 2026-08-05; not touched by this batch).
- Paid cost of the aborted attempt: 1 extra setup (29,933 tokens). This attempt
  is NOT counted in the formal 41. Evidence preserved at
  `p2596-formal20/attempt-001-evidence/`; the directory is excluded from
  aggregation, like all legacy reports.
- Correction applied: all later monitor logs use names that do not match any
  core8 problem-id prefix (e.g. `formal20-monitor-log.txt`), and the formal
  batch was restarted in a fresh directory `formal20`.
