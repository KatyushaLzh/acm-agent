#include <bits/stdc++.h>
using namespace std;

static unsigned long long rng_state;
static unsigned long long rng_next() {
    rng_state ^= rng_state << 7;
    rng_state ^= rng_state >> 9;
    return rng_state;
}

void acm_generate_case(unsigned long long seed, const string& profile, const string& case_kind, ostream& out) {
    if (profile == "small" && case_kind == "lower_bound") {
        out << "1 0\n1\n";
        return;
    }
    if (profile == "large" && case_kind == "upper_bound") {
        out << "80000 80000\n";
        for (int i = 1; i <= 80000; ++i) {
            if (i > 1) out << ' ';
            out << i;
        }
        out << '\n';
        for (int i = 0; i < 80000; ++i) {
            out << "Query 1\n";
        }
        return;
    }
    if (profile == "small" && case_kind == "random") {
        rng_state = seed;
        int n = 5, m = 8;
        out << n << ' ' << m << '\n';
        out << "1 2 3 4 5\n";
        vector<int> cur = {1,2,3,4,5};
        auto find_pos = [&](int x) {
            for (int i = 0; i < (int)cur.size(); ++i) if (cur[i] == x) return i;
            return -1;
        };
        auto erase_at = [&](int pos) {
            cur.erase(cur.begin() + pos);
        };
        auto insert_at = [&](int pos, int val) {
            cur.insert(cur.begin() + pos, val);
        };
        auto do_top = [&](int s) {
            int p = find_pos(s);
            erase_at(p);
            insert_at(0, s);
        };
        auto do_bottom = [&](int s) {
            int p = find_pos(s);
            erase_at(p);
            insert_at((int)cur.size(), s);
        };
        auto do_insert = [&](int s, int t) {
            int p = find_pos(s);
            int np = p + t;
            erase_at(p);
            insert_at(np, s);
        };
        auto do_ask = [&](int s) {
            return find_pos(s) + 1;
        };
        auto do_query = [&](int k) {
            return cur[k-1];
        };
        vector<string> ops;
        ops.push_back("Top 3"); do_top(3);
        ops.push_back("Bottom 1"); do_bottom(1);
        ops.push_back("Insert 2 1"); do_insert(2, 1);
        ops.push_back("Insert 4 -1"); do_insert(4, -1);
        ops.push_back("Insert 5 0"); do_insert(5, 0);
        ops.push_back("Ask 2"); do_ask(2);
        ops.push_back("Query 3"); do_query(3);
        ops.push_back("Top 5"); do_top(5);
        // seed must affect at least one semantic field: use it for the last Top's argument
        // but keep the skeleton legal: choose among {1,2,3,4,5} via RNG
        unsigned long long r = rng_next();
        int s = (int)(r % 5) + 1;
        ops[7] = "Top " + to_string(s);
        // re-validate the last op against the state before it (state after first 7 ops)
        // we must recompute state up to op 6, then apply op 7 with chosen s
        // simpler: rebuild state from scratch and validate
        cur = {1,2,3,4,5};
        for (int i = 0; i < 7; ++i) {
            stringstream ss(ops[i]);
            string cmd; ss >> cmd;
            if (cmd == "Top") { int x; ss >> x; do_top(x); }
            else if (cmd == "Bottom") { int x; ss >> x; do_bottom(x); }
            else if (cmd == "Insert") { int x,y; ss >> x >> y; do_insert(x,y); }
            else if (cmd == "Ask") { int x; ss >> x; do_ask(x); }
            else if (cmd == "Query") { int x; ss >> x; do_query(x); }
        }
        // now apply op 7 with chosen s
        {
            stringstream ss(ops[7]);
            string cmd; ss >> cmd;
            int x; ss >> x;
            do_top(x);
        }
        for (auto& op : ops) out << op << '\n';
        return;
    }
    if (profile == "large" && case_kind == "random") {
        rng_state = seed;
        int n = 80000, m = 80000;
        out << n << ' ' << m << '\n';
        for (int i = 1; i <= n; ++i) {
            if (i > 1) out << ' ';
            out << i;
        }
        out << '\n';
        // skeleton: 40000 Top 1 and 40000 Query 1 interleaved
        // seed changes the Query argument (read-only, always legal)
        for (int i = 0; i < 40000; ++i) {
            out << "Top 1\n";
            unsigned long long r = rng_next();
            int k = (int)(r % n) + 1;
            out << "Query " << k << '\n';
        }
        return;
    }
    // fallback: should not happen
    out << "1 0\n1\n";
}
