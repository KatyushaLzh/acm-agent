#include <bits/stdc++.h>
using namespace std;

static string json_escape(const string& s) {
    string out;
    for (char c : s) {
        if (c == '"' || c == '\\') { out += '\\'; out += c; }
        else if (c == '\n') out += "\\n";
        else if (c == '\r') out += "\\r";
        else if (c == '\t') out += "\\t";
        else if (static_cast<unsigned char>(c) < 0x20) {
            char buf[8];
            snprintf(buf, sizeof(buf), "\\u%04x", c);
            out += buf;
        } else out += c;
    }
    return out;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    long long n, m;
    if (!(cin >> n >> m)) {
        cerr << "ERR_HEADER 0\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
        return 0;
    }
    if (n < 1 || n > 80000 || m < 0 || m > 80000) {
        cerr << "ERR_CONSTRAINT 0\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
        return 0;
    }

    vector<int> perm(n);
    vector<bool> seen(n + 1, false);
    for (int i = 0; i < n; ++i) {
        if (!(cin >> perm[i])) {
            cerr << "ERR_TOKEN 0\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
            return 0;
        }
        if (perm[i] < 1 || perm[i] > n || seen[perm[i]]) {
            cerr << "ERR_PERM 0\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
            return 0;
        }
        seen[perm[i]] = true;
    }

    list<int> seq;
    unordered_map<int, list<int>::iterator> pos;
    for (int i = 0; i < n; ++i) {
        seq.push_back(perm[i]);
        auto it = seq.end();
        --it;
        pos[perm[i]] = it;
    }

    vector<string> tags;
    bool has_top = false, has_bottom = false, has_insert = false, has_ask = false, has_query = false;
    bool has_c1_min = false, has_c1_max = false, has_c2_min = false, has_c2_max = false;
    bool has_c4_min = false, has_c4_max = false, has_c5_min = false, has_c5_max = false, has_c6_min = false, has_c6_max = false;

    if (n == 1) has_c1_min = true;
    if (n == 80000) has_c1_max = true;
    if (m == 0) has_c2_min = true;
    if (m == 80000) has_c2_max = true;

    long long records = 0;
    for (long long idx = 0; idx < m; ++idx) {
        string op;
        if (!(cin >> op)) {
            cerr << "ERR_TOKEN " << idx << "\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
            return 0;
        }
        if (op == "Top") {
            long long s;
            if (!(cin >> s)) {
                cerr << "ERR_TOKEN " << idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (s < 1 || s > n) {
                cerr << "ERR_RANGE " << idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (s == 1) has_c4_min = true;
            if (s == n) has_c4_max = true;
            auto it = pos[s];
            seq.splice(seq.begin(), seq, it);
            has_top = true;
        } else if (op == "Bottom") {
            long long s;
            if (!(cin >> s)) {
                cerr << "ERR_TOKEN " << idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (s < 1 || s > n) {
                cerr << "ERR_RANGE " << idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (s == 1) has_c4_min = true;
            if (s == n) has_c4_max = true;
            auto it = pos[s];
            seq.splice(seq.end(), seq, it);
            has_bottom = true;
        } else if (op == "Insert") {
            long long s, t;
            if (!(cin >> s >> t)) {
                cerr << "ERR_TOKEN " << idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (s < 1 || s > n || t < -1 || t > 1) {
                cerr << "ERR_RANGE " << idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (s == 1) has_c4_min = true;
            if (s == n) has_c4_max = true;
            if (t == -1) has_c6_min = true;
            if (t == 1) has_c6_max = true;
            auto it = pos[s];
            if (t == 0) {
                // no move
            } else if (t == -1) {
                if (it == seq.begin()) {
                    cerr << "ERR_ILLEGAL " << idx << "\n";
                    cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                    return 0;
                }
                auto target = prev(it);
                seq.splice(target, seq, it);
            } else { // t == 1
                auto nxt = next(it);
                if (nxt == seq.end()) {
                    cerr << "ERR_ILLEGAL " << idx << "\n";
                    cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                    return 0;
                }
                auto target = next(nxt);
                seq.splice(target, seq, it);
            }
            has_insert = true;
        } else if (op == "Ask") {
            long long s;
            if (!(cin >> s)) {
                cerr << "ERR_TOKEN " << idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (s < 1 || s > n) {
                cerr << "ERR_RANGE " << idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (s == 1) has_c4_min = true;
            if (s == n) has_c4_max = true;
            has_ask = true;
        } else if (op == "Query") {
            long long k;
            if (!(cin >> k)) {
                cerr << "ERR_TOKEN " << idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (k < 1 || k > n) {
                cerr << "ERR_RANGE " << idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (k == 1) has_c5_min = true;
            if (k == n) has_c5_max = true;
            has_query = true;
        } else {
            cerr << "ERR_OP " << idx << "\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
            return 0;
        }
        ++records;
    }

    string extra;
    if (!(cin >> extra)) {
        // ok, EOF
    } else {
        cerr << "ERR_TRAILING " << m << "\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
        return 0;
    }

    if (has_top) tags.push_back("auto_operation_top");
    if (has_bottom) tags.push_back("auto_operation_bottom");
    if (has_insert) tags.push_back("auto_operation_insert");
    if (has_ask) tags.push_back("auto_operation_ask");
    if (has_query) tags.push_back("auto_operation_query");
    if (has_c1_min) tags.push_back("auto_c1_minimum");
    if (has_c1_max) tags.push_back("auto_c1_maximum");
    if (has_c2_min) tags.push_back("auto_c2_minimum");
    if (has_c2_max) tags.push_back("auto_c2_maximum");
    if (has_c4_min) tags.push_back("auto_c4_minimum");
    if (has_c4_max) tags.push_back("auto_c4_maximum");
    if (has_c5_min) tags.push_back("auto_c5_minimum");
    if (has_c5_max) tags.push_back("auto_c5_maximum");
    if (has_c6_min) tags.push_back("auto_c6_minimum");
    if (has_c6_max) tags.push_back("auto_c6_maximum");

    cout << "{\"valid\":true,\"dimensions\":{\"n\":" << n << ",\"m\":" << m << "},\"coverage_tags\":[";
    for (size_t i = 0; i < tags.size(); ++i) {
        if (i) cout << ",";
        cout << "\"" << json_escape(tags[i]) << "\"";
    }
    cout << "],\"records\":" << records << "}\n";
    return 0;
}
