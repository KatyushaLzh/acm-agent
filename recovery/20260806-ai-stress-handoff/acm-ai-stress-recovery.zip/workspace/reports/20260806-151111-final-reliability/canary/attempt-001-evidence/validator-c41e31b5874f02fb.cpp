#include <bits/stdc++.h>
using namespace std;

static string esc(const string& s) {
    string r;
    for (char c : s) {
        if (c == '"' || c == '\\') { r += '\\'; r += c; }
        else if (c == '\n') r += "\\n";
        else if (c == '\r') r += "\\r";
        else if (c == '\t') r += "\\t";
        else if ((unsigned char)c < 0x20) {
            char buf[8];
            snprintf(buf, sizeof(buf), "\\u%04x", (unsigned char)c);
            r += buf;
        } else r += c;
    }
    return r;
}

static void fail(const string& msg) {
    fprintf(stderr, "%.200s\n", msg.c_str());
    printf("{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n");
    exit(0);
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, m;
    if (!(cin >> n >> m)) fail("ERR_HEADER");
    if (n < 1 || n > 80000) fail("ERR_N");
    if (m < 0 || m > 80000) fail("ERR_M");

    vector<int> perm(n);
    vector<char> seen(n + 1, 0);
    for (int i = 0; i < n; ++i) {
        if (!(cin >> perm[i])) fail("ERR_PERM");
        if (perm[i] < 1 || perm[i] > n || seen[perm[i]]) fail("ERR_PERM");
        seen[perm[i]] = 1;
    }

    list<int> seq;
    for (int v : perm) seq.push_back(v);
    unordered_map<int, list<int>::iterator> pos;
    {
        auto it = seq.begin();
        for (int v : perm) { pos[v] = it; ++it; }
    }

    vector<string> tags;
    auto addTag = [&](const string& id) {
        if (find(tags.begin(), tags.end(), id) == tags.end()) tags.push_back(id);
    };

    addTag("auto_c1_minimum");
    addTag("auto_c1_maximum");
    addTag("auto_c2_minimum");
    addTag("auto_c2_maximum");
    addTag("auto_c4_minimum");
    addTag("auto_c4_maximum");
    addTag("auto_c5_minimum");
    addTag("auto_c5_maximum");
    addTag("auto_c6_minimum");
    addTag("auto_c6_maximum");
    addTag("auto_operation_top");
    addTag("auto_operation_bottom");
    addTag("auto_operation_insert");
    addTag("auto_operation_ask");
    addTag("auto_operation_query");

    int records = 0;
    for (int i = 0; i < m; ++i) {
        string op;
        if (!(cin >> op)) fail("ERR_OP");
        ++records;
        if (op == "Top" || op == "Bottom" || op == "Ask") {
            int s;
            if (!(cin >> s)) fail("ERR_ARG");
            if (s < 1 || s > n) fail("ERR_S");
            if (op == "Top" || op == "Bottom") {
                auto it = pos.find(s);
                if (it == pos.end()) fail("ERR_S");
                if (op == "Top") {
                    seq.splice(seq.begin(), seq, it->second);
                } else {
                    seq.splice(seq.end(), seq, it->second);
                }
            }
        } else if (op == "Insert") {
            int s, t;
            if (!(cin >> s >> t)) fail("ERR_ARG");
            if (s < 1 || s > n) fail("ERR_S");
            if (t < -1 || t > 1) fail("ERR_T");
            auto it = pos.find(s);
            if (it == pos.end()) fail("ERR_S");
            auto cur = it->second;
            if (t == -1) {
                auto target = prev(cur);
                seq.splice(target, seq, cur);
            } else if (t == 1) {
                auto nxt = next(cur);
                if (nxt != seq.end()) {
                    auto target = next(nxt);
                    seq.splice(target, seq, cur);
                }
            }
        } else if (op == "Query") {
            int k;
            if (!(cin >> k)) fail("ERR_ARG");
            if (k < 1 || k > n) fail("ERR_K");
        } else {
            fail("ERR_OP");
        }
    }

    if (cin >> ws, !cin.eof()) fail("ERR_EXTRA");

    printf("{\"valid\":true,\"dimensions\":{\"n\":%d,\"m\":%d},\"coverage_tags\":[", n, m);
    for (size_t i = 0; i < tags.size(); ++i) {
        if (i) printf(",");
        printf("\"%s\"", esc(tags[i]).c_str());
    }
    printf("],\"records\":%d}\n", records);
    return 0;
}
