#include <algorithm>
#include <cstdint>
#include <ostream>
#include <random>
#include <string>
#include <vector>

namespace {

struct SmallState {
    std::vector<int> seq;
    explicit SmallState(const std::vector<int>& init) : seq(init) {}

    int find_pos(int book) const {
        for (std::size_t i = 0; i < seq.size(); ++i) {
            if (seq[i] == book) return static_cast<int>(i);
        }
        return -1;
    }

    void top(int book) {
        int pos = find_pos(book);
        seq.erase(seq.begin() + pos);
        seq.insert(seq.begin(), book);
    }

    void bottom(int book) {
        int pos = find_pos(book);
        seq.erase(seq.begin() + pos);
        seq.push_back(book);
    }

    void insert(int book, int t) {
        int pos = find_pos(book);
        seq.erase(seq.begin() + pos);
        int new_pos = pos + t;
        if (new_pos < 0) new_pos = 0;
        if (new_pos > static_cast<int>(seq.size())) new_pos = static_cast<int>(seq.size());
        seq.insert(seq.begin() + new_pos, book);
    }

    int ask(int book) const {
        return find_pos(book) + 1;
    }

    int query(int pos) const {
        return seq[pos - 1];
    }
};

void emit_small_lower_bound(std::ostream& out) {
    out << "1 0\n";
    out << "1\n";
}

void emit_small_random(std::ostream& out, unsigned long long seed) {
    std::mt19937_64 rng(seed);

    int n = 5;
    int m = 8;
    std::vector<int> init = {1, 2, 3, 4, 5};

    out << n << ' ' << m << '\n';
    for (int i = 0; i < n; ++i) {
        if (i) out << ' ';
        out << init[i];
    }
    out << '\n';

    SmallState st(init);

    // Fixed legal skeleton from the blueprint.
    struct Op {
        std::string name;
        int a;
        int b;
    };
    std::vector<Op> ops;
    ops.push_back({"Top", 3, 0});
    ops.push_back({"Bottom", 1, 0});
    ops.push_back({"Insert", 2, 1});
    ops.push_back({"Insert", 4, -1});
    ops.push_back({"Insert", 5, 0});
    ops.push_back({"Ask", 3, 0});
    ops.push_back({"Query", 2, 0});
    ops.push_back({"Top", 5, 0});

    // Apply the skeleton to validate legality.
    for (const Op& op : ops) {
        if (op.name == "Top") st.top(op.a);
        else if (op.name == "Bottom") st.bottom(op.a);
        else if (op.name == "Insert") st.insert(op.a, op.b);
        else if (op.name == "Ask") { int r = st.ask(op.a); (void)r; }
        else if (op.name == "Query") { int r = st.query(op.a); (void)r; }
    }

    // Now seed must change at least one safe read-only field.
    // Safe families: Ask, Query. Change the argument of the Ask operation.
    // Rebuild the state from init to re-validate with the changed argument.
    SmallState st2(init);
    int ask_arg = static_cast<int>(rng() % n) + 1; // 1..n
    ops[5].a = ask_arg;

    for (const Op& op : ops) {
        if (op.name == "Top") st2.top(op.a);
        else if (op.name == "Bottom") st2.bottom(op.a);
        else if (op.name == "Insert") st2.insert(op.a, op.b);
        else if (op.name == "Ask") { int r = st2.ask(op.a); (void)r; }
        else if (op.name == "Query") { int r = st2.query(op.a); (void)r; }
    }

    for (const Op& op : ops) {
        out << op.name;
        if (op.name == "Insert") {
            out << ' ' << op.a << ' ' << op.b;
        } else {
            out << ' ' << op.a;
        }
        out << '\n';
    }
}

void emit_large_upper_bound(std::ostream& out) {
    int n = 80000;
    int m = 80000;
    out << n << ' ' << m << '\n';
    for (int i = 1; i <= n; ++i) {
        if (i > 1) out << ' ';
        out << i;
    }
    out << '\n';
    for (int i = 0; i < m; ++i) {
        out << "Ask 1\n";
    }
}

void emit_large_random(std::ostream& out, unsigned long long seed) {
    std::mt19937_64 rng(seed);

    int n = 80000;
    int m = 80000;
    out << n << ' ' << m << '\n';
    for (int i = 1; i <= n; ++i) {
        if (i > 1) out << ' ';
        out << i;
    }
    out << '\n';

    int ask_count = 40000;
    int query_count = 40000;

    for (int i = 0; i < ask_count; ++i) {
        out << "Ask 1\n";
    }
    for (int i = 0; i < query_count; ++i) {
        // Seed changes the query position (safe read-only field).
        int pos = static_cast<int>(rng() % n) + 1;
        out << "Query " << pos << '\n';
    }
}

} // namespace

void acm_generate_case(unsigned long long seed,
                       const std::string& profile,
                       const std::string& case_kind,
                       std::ostream& out) {
    if (profile == "small" && case_kind == "lower_bound") {
        emit_small_lower_bound(out);
    } else if (profile == "small" && case_kind == "random") {
        emit_small_random(out, seed);
    } else if (profile == "large" && case_kind == "upper_bound") {
        emit_large_upper_bound(out);
    } else if (profile == "large" && case_kind == "random") {
        emit_large_random(out, seed);
    }
}
