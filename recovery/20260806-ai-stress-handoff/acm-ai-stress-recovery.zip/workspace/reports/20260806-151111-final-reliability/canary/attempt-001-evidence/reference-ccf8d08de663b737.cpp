#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<ctime>
using namespace std;
int n,m,s,t,x,tot,root,temp,minn,maxn,no[300001],size[300001],priority[300001],position[300001],value[300001],child[300001][2];
char dir[10];
inline void rotate(int &now,bool opt)
{
    int t=child[now][opt];
    child[now][opt]=child[t][opt^1];
    child[t][opt^1]=now;
    size[t]=size[now];
    size[now]=size[child[now][0]]+size[child[now][1]]+1;
    now=t;
    return;
}
void insert(int &now,int x,int y)
{
    if(!now)
    {
        now=++tot;
        value[now]=x;
        priority[now]=rand();
        no[now]=y;
        size[now]=1;
        return;
    }
    ++size[now];
    if(x<value[now])
    {
        insert(child[now][0],x,y);
        if(priority[child[now][0]]>priority[now])
            rotate(now,0);
    }
    else
    {
        insert(child[now][1],x,y); 
        if(priority[child[now][1]]>priority[now])
            rotate(now,1);
    }
    return;
}
void erase(int &now,int x)
{
    if(value[now]==x)
    {
        if(!child[now][0]||!child[now][1])
        {
            now=child[now][0]+child[now][1];
            return;
        }
        else if(priority[child[now][0]]>priority[child[now][1]])
            rotate(now,0);
        else rotate(now,1);
        erase(now,x);
        return;
    }
    --size[now];
    if(x<value[now])
        erase(child[now][0],x);
    else erase(child[now][1],x);
    return;
}
void change(int x,int dir)
{
    int now=root,res,loc;
    if(dir==1)
        while(now)
        {
            if(x<value[now])
            {
                res=now;
                now=child[now][0]; 
            }
            else if(x==value[now])
            {
                loc=now;
                now=child[now][1];
            }
            else now=child[now][1];
        }
    else while(now)
        {
            if(x>value[now])
            {
                res=now;
                now=child[now][1]; 
            }
            else if(x==value[now])
            {
                loc=now;
                now=child[now][0];
            }
            else now=child[now][0];
        }
    swap(position[no[res]],position[no[loc]]);
    swap(no[res],no[loc]);
    return;
}
int rank_of(int x)
{
    int res=0,now=root;
    while(now)
    {
        if(value[now]==x)
        {
            res+=size[child[now][0]]+1;
            break;
        }
        else if(value[now]<x)
        {
            res+=size[child[now][0]]+1;
            now=child[now][1];
        }
        else now=child[now][0];
    }
    return res;
}
int at(int x)
{
    int sum=0,now=root;
    while(now)
    {
        if(x==sum+size[child[now][0]]+1)
            return no[now];
        else if(x>sum+size[child[now][0]]+1)
        {
            sum+=size[child[now][0]]+1;
            now=child[now][1];
        }
        else now=child[now][0];
    }
    return -1;
}
int main()
{
    srand(unsigned(time(0)));
    scanf("%d%d",&n,&m);
    minn=1;
    maxn=n;
    for(int i=1;i<=n;++i)
    {
        scanf("%d",&x);
        insert(root,position[x]=i,x);
    }
    while(m--)
    {
        scanf("%s%d",dir,&s);
        switch(dir[0])
        {
            case 'T':
                erase(root,position[s]);
                insert(root,position[s]=--minn,s);
                break;
            case 'B':
                erase(root,position[s]);
                insert(root,position[s]=++maxn,s);
                break;
            case 'I':
                scanf("%d",&t);
                if(!t)
                    continue;
                change(position[s],t);
                break;
            case 'A':
                printf("%d\n",rank_of(position[s])-1);
                break;
            default:
                printf("%d\n",at(s));
        }
    }
    return 0;
}
