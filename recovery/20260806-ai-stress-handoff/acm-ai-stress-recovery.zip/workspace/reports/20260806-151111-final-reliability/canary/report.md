# AI Stress Benchmark Report

## Outcome

| Metric | Value |
|---|---:|
| Attempts | 1 |
| Successes | 1 |
| Success rate | 100.0% |
| First-round success rate | 100.0% |
| Unsafe applies | 0 |
| Successful time p50 / p95 | 124.074 / 124.074 s |
| Successful tokens p50 / p95 | 31403.000 / 31403.000 |
| Provider requests | 9.000 |
| Retries | 0.000 |

## Failure stages

| Stage | Attempts |
|---|---:|
| none | 0 |

## Repair roles

| Role | Attempts |
|---|---:|
| none | 0 |

## Stage duration percentiles

| Stage | p50 | p95 | max |
|---|---:|---:|---:|
| apply_helpers | 0.835 | 0.835 | 0.835 |
| audit_brute_attempt_1 | 1.406 | 1.406 | 1.406 |
| audit_generator_attempt_1 | 1.258 | 1.258 | 1.258 |
| audit_helpers | 3.375 | 3.375 | 3.375 |
| audit_validator_attempt_1 | 3.360 | 3.360 | 3.360 |
| check_isolation | 3.324 | 3.324 | 3.324 |
| create_stress_run | 31.653 | 31.653 | 31.653 |
| extract_contract | 8.355 | 8.355 | 8.355 |
| extract_contract/provider_request | 8.274 | 8.274 | 8.274 |
| generate_blueprint/provider_request | 3.758 | 3.758 | 3.758 |
| generate_brute | 0.000 | 0.000 | 0.000 |
| generate_brute/provider_request | 3.078 | 3.078 | 3.078 |
| generate_generator | 3.762 | 3.762 | 3.762 |
| generate_generator/provider_request | 8.858 | 8.858 | 8.858 |
| generate_validator | 0.000 | 0.000 | 0.000 |
| generate_validator/provider_request | 7.417 | 7.417 | 7.417 |
| preflight_helpers | 27.096 | 27.096 | 27.096 |
| prepare_reference | 45.623 | 45.623 | 45.623 |
| queued | 0.047 | 0.047 | 0.047 |

## Token category percentiles

| Category | p50 | p95 | max |
|---|---:|---:|---:|
| completion_tokens | 5236.000 | 5236.000 | 5236.000 |
| prompt_cache_hit_tokens | 8448.000 | 8448.000 | 8448.000 |
| prompt_cache_miss_tokens | 17719.000 | 17719.000 | 17719.000 |
| prompt_tokens | 26167.000 | 26167.000 | 26167.000 |
| total_tokens | 31403.000 | 31403.000 | 31403.000 |
