#include <algorithm>
#include <cstdint>
#include <iostream>
#include <numeric>
#include <random>
#include <string>
#include <vector>

void acm_generate_case(unsigned long long seed, const std::string& profile,
                       const std::string& case_kind, std::ostream& out) {
    if (profile == "small" && case_kind == "lower_bound") {
        out << "1 0\n";
        out << "1\n";
        return;
    }

    if (profile == "small" && case_kind == "random") {
        std::mt19937_64 rng(seed);
        int n = 5;
        int m = 8;
        out << n << " " << m << "\n";
        out << "1 2 3 4 5\n";

        std::vector<int> state = {1, 2, 3, 4, 5};

        auto find_pos = [&](int val) -> int {
            for (int i = 0; i < (int)state.size(); ++i) {
                if (state[i] == val) return i;
            }
            return -1;
        };

        auto erase_at = [&](int pos) {
            state.erase(state.begin() + pos);
        };

        auto insert_at = [&](int pos, int val) {
            state.insert(state.begin() + pos, val);
        };

        // Fixed legal skeleton from the blueprint.
        // Top 3
        {
            int s = 3;
            int pos = find_pos(s);
            erase_at(pos);
            insert_at(0, s);
            out << "Top " << s << "\n";
        }
        // Bottom 1
        {
            int s = 1;
            int pos = find_pos(s);
            erase_at(pos);
            insert_at((int)state.size(), s);
            out << "Bottom " << s << "\n";
        }
        // Insert 2 -1
        {
            int s = 2;
            int t = -1;
            int pos = find_pos(s);
            erase_at(pos);
            int new_pos = pos + t;
            if (new_pos < 0) new_pos = 0;
            if (new_pos > (int)state.size()) new_pos = (int)state.size();
            insert_at(new_pos, s);
            out << "Insert " << s << " " << t << "\n";
        }
        // Insert 4 1
        {
            int s = 4;
            int t = 1;
            int pos = find_pos(s);
            erase_at(pos);
            int new_pos = pos + t;
            if (new_pos < 0) new_pos = 0;
            if (new_pos > (int)state.size()) new_pos = (int)state.size();
            insert_at(new_pos, s);
            out << "Insert " << s << " " << t << "\n";
        }
        // Insert 5 0
        {
            int s = 5;
            int t = 0;
            int pos = find_pos(s);
            erase_at(pos);
            insert_at(pos, s);
            out << "Insert " << s << " " << t << "\n";
        }
        // Ask 3
        {
            int s = 3;
            int pos = find_pos(s);
            out << "Ask " << s << "\n";
            (void)pos;
        }
        // Query 2 (seed-dependent)
        {
            int k = 2 + (int)(rng() % 4);  // k in 2..5, all legal
            out << "Query " << k << "\n";
        }
        // Top 5
        {
            int s = 5;
            int pos = find_pos(s);
            erase_at(pos);
            insert_at(0, s);
            out << "Top " << s << "\n";
        }
        return;
    }

    if (profile == "large" && case_kind == "upper_bound") {
        int n = 80000;
        int m = 80000;
        out << n << " " << m << "\n";
        for (int i = 1; i <= n; ++i) {
            if (i > 1) out << " ";
            out << i;
        }
        out << "\n";
        for (int i = 1; i <= m; ++i) {
            int k = i;  // k cycles 1..n
            out << "Query " << k << "\n";
        }
        return;
    }

    if (profile == "large" && case_kind == "random") {
        std::mt19937_64 rng(seed);
        int n = 80000;
        int m = 80000;
        out << n << " " << m << "\n";
        for (int i = 1; i <= n; ++i) {
            if (i > 1) out << " ";
            out << i;
        }
        out << "\n";

        // Fixed skeleton: 40000 Top operations on distinct books, then 40000 Query operations.
        // Top operations use books 1..40000 in order (each moved to top once, always legal).
        // Query operations use seed-dependent positions.
        int top_count = 40000;
        int query_count = 40000;

        for (int i = 1; i <= top_count; ++i) {
            out << "Top " << i << "\n";
        }

        for (int i = 0; i < query_count; ++i) {
            int k = 1 + (int)(rng() % n);  // k in 1..n, always legal
            out << "Query " << k << "\n";
        }
        return;
    }
}
