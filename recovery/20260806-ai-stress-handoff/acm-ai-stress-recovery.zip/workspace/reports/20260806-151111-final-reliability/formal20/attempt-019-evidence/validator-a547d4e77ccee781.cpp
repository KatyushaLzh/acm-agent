#include <bits/stdc++.h>
using namespace std;

struct JsonWriter {
    string s;
    void begin_obj() { s += '{'; }
    void end_obj() { s += '}'; }
    void begin_arr() { s += '['; }
    void end_arr() { s += ']'; }
    void key(const string& k) { s += '"' + k + "\":"; }
    void val(bool b) { s += b ? "true" : "false"; }
    void val(long long v) { s += to_string(v); }
    void val_str(const string& v) {
        s += '"';
        for (char c : v) {
            if (c == '"' || c == '\\') { s += '\\'; s += c; }
            else if (c == '\n') s += "\\n";
            else if (c == '\r') s += "\\r";
            else if (c == '\t') s += "\\t";
            else if ((unsigned char)c < 0x20) {
                char buf[8];
                snprintf(buf, sizeof(buf), "\\u%04x", (unsigned char)c);
                s += buf;
            } else s += c;
        }
        s += '"';
    }
    void comma() { s += ','; }
};

struct Fail {
    string code;
    int idx;
    long long a, b;
};

static string fail_msg(const Fail& f) {
    return f.code + " " + to_string(f.idx) + " " + to_string(f.a) + " " + to_string(f.b);
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    long long n, m;
    if (!(cin >> n >> m)) {
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
        return 0;
    }

    if (n < 1 || n > 80000 || m < 0 || m > 80000) {
        cerr << "header_range 0 " << n << " " << m << "\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
        return 0;
    }

    vector<int> perm(n);
    vector<char> seen(n + 1, 0);
    for (int i = 0; i < n; ++i) {
        if (!(cin >> perm[i])) {
            cerr << "perm_eof " << i << " 0 0\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
            return 0;
        }
        if (perm[i] < 1 || perm[i] > n || seen[perm[i]]) {
            cerr << "perm_bad " << i << " " << perm[i] << " 0\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
            return 0;
        }
        seen[perm[i]] = 1;
    }

    list<int> seq;
    vector<list<int>::iterator> pos(n + 1);
    for (int i = 0; i < n; ++i) {
        pos[perm[i]] = seq.insert(seq.end(), perm[i]);
    }

    vector<string> tags;
    bool has_top = false, has_bottom = false, has_insert = false, has_ask = false, has_query = false;
    bool has_c4_min = false, has_c4_max = false, has_c5_min = false, has_c5_max = false, has_c6_min = false, has_c6_max = false;

    long long records = 0;
    for (long long op_idx = 0; op_idx < m; ++op_idx) {
        string op;
        if (!(cin >> op)) {
            cerr << "op_eof " << op_idx << " 0 0\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
            return 0;
        }
        ++records;

        if (op == "Top") {
            long long s;
            if (!(cin >> s)) {
                cerr << "arg_eof " << op_idx << " 0 0\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (s < 1 || s > n) {
                cerr << "arg_range " << op_idx << " " << s << " 0\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (s == 1) has_c4_min = true;
            if (s == n) has_c4_max = true;
            has_top = true;
            auto it = pos[s];
            seq.splice(seq.begin(), seq, it);
        } else if (op == "Bottom") {
            long long s;
            if (!(cin >> s)) {
                cerr << "arg_eof " << op_idx << " 0 0\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (s < 1 || s > n) {
                cerr << "arg_range " << op_idx << " " << s << " 0\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (s == 1) has_c4_min = true;
            if (s == n) has_c4_max = true;
            has_bottom = true;
            auto it = pos[s];
            seq.splice(seq.end(), seq, it);
        } else if (op == "Insert") {
            long long s, t;
            if (!(cin >> s >> t)) {
                cerr << "arg_eof " << op_idx << " 0 0\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (s < 1 || s > n || t < -1 || t > 1) {
                cerr << "arg_range " << op_idx << " " << s << " " << t << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (s == 1) has_c4_min = true;
            if (s == n) has_c4_max = true;
            if (t == -1) has_c5_min = true;
            if (t == 1) has_c5_max = true;
            has_insert = true;
            auto it = pos[s];
            if (t == -1) {
                if (it == seq.begin()) {
                    cerr << "insert_prev " << op_idx << " " << s << " " << t << "\n";
                    cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                    return 0;
                }
                auto target = prev(it);
                seq.splice(target, seq, it);
            } else if (t == 1) {
                auto nxt = next(it);
                if (nxt == seq.end()) {
                    cerr << "insert_next " << op_idx << " " << s << " " << t << "\n";
                    cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                    return 0;
                }
                auto target = next(nxt);
                seq.splice(target, seq, it);
            }
        } else if (op == "Ask") {
            long long s;
            if (!(cin >> s)) {
                cerr << "arg_eof " << op_idx << " 0 0\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (s < 1 || s > n) {
                cerr << "arg_range " << op_idx << " " << s << " 0\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (s == 1) has_c4_min = true;
            if (s == n) has_c4_max = true;
            has_ask = true;
        } else if (op == "Query") {
            long long k;
            if (!(cin >> k)) {
                cerr << "arg_eof " << op_idx << " 0 0\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (k < 1 || k > n) {
                cerr << "arg_range " << op_idx << " " << k << " 0\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (k == 1) has_c6_min = true;
            if (k == n) has_c6_max = true;
            has_query = true;
        } else {
            cerr << "bad_op " << op_idx << " 0 0\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
            return 0;
        }
    }

    string extra;
    if (cin >> extra) {
        cerr << "trailing 0 0 0\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
        return 0;
    }

    if (has_top) tags.push_back("auto_operation_top");
    if (has_bottom) tags.push_back("auto_operation_bottom");
    if (has_insert) tags.push_back("auto_operation_insert");
    if (has_ask) tags.push_back("auto_operation_ask");
    if (has_query) tags.push_back("auto_operation_query");
    if (n == 1 && m == 0) tags.push_back("auto_c1_minimum");
    if (n == 80000 && m == 80000) tags.push_back("auto_c1_maximum");
    if (m == 0) tags.push_back("auto_c2_minimum");
    if (m == 80000) tags.push_back("auto_c2_maximum");
    if (has_c4_min) tags.push_back("auto_c4_minimum");
    if (has_c4_max) tags.push_back("auto_c4_maximum");
    if (has_c5_min) tags.push_back("auto_c5_minimum");
    if (has_c5_max) tags.push_back("auto_c5_maximum");
    if (has_c6_min) tags.push_back("auto_c6_minimum");
    if (has_c6_max) tags.push_back("auto_c6_maximum");

    sort(tags.begin(), tags.end());
    tags.erase(unique(tags.begin(), tags.end()), tags.end());

    JsonWriter jw;
    jw.begin_obj();
    jw.key("valid"); jw.val(true); jw.comma();
    jw.key("dimensions"); jw.begin_obj(); jw.key("n"); jw.val(n); jw.comma(); jw.key("m"); jw.val(m); jw.end_obj(); jw.comma();
    jw.key("coverage_tags"); jw.begin_arr();
    for (size_t i = 0; i < tags.size(); ++i) {
        if (i) jw.comma();
        jw.val_str(tags[i]);
    }
    jw.end_arr(); jw.comma();
    jw.key("records"); jw.val(records);
    jw.end_obj();
    cout << jw.s << "\n";
    return 0;
}
