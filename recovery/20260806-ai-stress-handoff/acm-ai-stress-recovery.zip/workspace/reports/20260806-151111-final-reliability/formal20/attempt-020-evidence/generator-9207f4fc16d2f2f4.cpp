#include <algorithm>
#include <cstdint>
#include <ostream>
#include <random>
#include <string>
#include <vector>

void acm_generate_case(unsigned long long seed, const std::string& profile,
                       const std::string& case_kind, std::ostream& out) {
    if (profile == "small" && case_kind == "lower_bound") {
        out << "1 0\n1\n";
        return;
    }
    if (profile == "large" && case_kind == "upper_bound") {
        const int n = 80000;
        const int m = 80000;
        out << n << ' ' << m << '\n';
        for (int i = 1; i <= n; ++i) {
            if (i > 1) out << ' ';
            out << i;
        }
        out << '\n';
        for (int i = 1; i <= 40000; ++i) {
            out << "Top " << i << '\n';
        }
        for (int i = 1; i <= 40000; ++i) {
            out << "Query " << i << '\n';
        }
        return;
    }

    if (profile == "small" && case_kind == "random") {
        std::mt19937_64 rng(seed);
        const int n = 5;
        const int m = 8;
        out << n << ' ' << m << '\n';
        out << "1 2 3 4 5\n";

        std::vector<int> seq = {1, 2, 3, 4, 5};

        auto find_pos = [&](int x) -> int {
            for (int i = 0; i < (int)seq.size(); ++i) {
                if (seq[i] == x) return i;
            }
            return -1;
        };

        auto do_top = [&](int s) {
            int p = find_pos(s);
            seq.erase(seq.begin() + p);
            seq.insert(seq.begin(), s);
        };
        auto do_bottom = [&](int s) {
            int p = find_pos(s);
            seq.erase(seq.begin() + p);
            seq.push_back(s);
        };
        auto do_insert = [&](int s, int t) {
            int p = find_pos(s);
            int np = p + t;
            seq.erase(seq.begin() + p);
            seq.insert(seq.begin() + np, s);
        };

        // Fixed legal skeleton from the blueprint.
        do_top(3);
        out << "Top 3\n";
        do_bottom(1);
        out << "Bottom 1\n";
        do_insert(2, -1);
        out << "Insert 2 -1\n";
        do_insert(4, 1);
        out << "Insert 4 1\n";
        do_insert(5, 0);
        out << "Insert 5 0\n";

        // Ask 2: seed changes the query position (read-only, always legal).
        int ask_pos = 1 + (int)(rng() % n);
        out << "Ask " << ask_pos << '\n';

        // Query 3: seed changes the query position (read-only, always legal).
        int query_pos = 1 + (int)(rng() % n);
        out << "Query " << query_pos << '\n';

        // Top 5: fixed, unconditionally legal.
        out << "Top 5\n";
        return;
    }

    if (profile == "large" && case_kind == "random") {
        std::mt19937_64 rng(seed);
        const int n = 80000;
        const int m = 80000;
        out << n << ' ' << m << '\n';
        for (int i = 1; i <= n; ++i) {
            if (i > 1) out << ' ';
            out << i;
        }
        out << '\n';

        // First 40000: Top on distinct books 1..40000 (fixed skeleton).
        for (int i = 1; i <= 40000; ++i) {
            out << "Top " << i << '\n';
        }

        // Next 40000: Query. Seed changes the query positions.
        // To keep it simple and legal, use positions derived from the PRNG.
        for (int i = 0; i < 40000; ++i) {
            int q = 1 + (int)(rng() % n);
            out << "Query " << q << '\n';
        }
        return;
    }

    // Unreachable in the harness protocol; emit a minimal valid case.
    out << "1 0\n1\n";
}
