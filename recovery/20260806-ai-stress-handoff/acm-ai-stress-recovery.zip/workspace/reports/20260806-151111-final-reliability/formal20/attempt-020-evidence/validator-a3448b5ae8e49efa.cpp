#include <bits/stdc++.h>
using namespace std;

static string esc(long long x) { return to_string(x); }

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    string line;
    if (!getline(cin, line)) {
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
        return 0;
    }
    stringstream ss(line);
    long long n, m;
    if (!(ss >> n >> m)) {
        cerr << "ERR_HEADER 0\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
        return 0;
    }
    if (n < 1 || n > 80000 || m < 0 || m > 80000) {
        cerr << "ERR_CONSTRAINT 0\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
        return 0;
    }

    vector<long long> perm;
    perm.reserve((size_t)n);
    for (long long i = 0; i < n; ++i) {
        long long x;
        if (!(cin >> x)) {
            cerr << "ERR_PERM " << i << "\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
            return 0;
        }
        if (x < 1 || x > n) {
            cerr << "ERR_PERM_RANGE " << i << "\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
            return 0;
        }
        perm.push_back(x);
    }
    vector<char> seen((size_t)n + 1, 0);
    for (long long i = 0; i < n; ++i) {
        if (seen[(size_t)perm[(size_t)i]]) {
            cerr << "ERR_PERM_DUP " << i << "\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
            return 0;
        }
        seen[(size_t)perm[(size_t)i]] = 1;
    }

    list<long long> books;
    unordered_map<long long, list<long long>::iterator> pos;
    for (long long x : perm) {
        books.push_back(x);
        pos[x] = prev(books.end());
    }

    vector<string> tags;
    long long records = 0;
    bool ok = true;
    long long fail_idx = -1;
    string fail_code;

    for (long long i = 0; i < m; ++i) {
        string op;
        if (!(cin >> op)) {
            ok = false; fail_idx = i; fail_code = "ERR_OP";
            break;
        }
        if (op == "Top") {
            long long s;
            if (!(cin >> s)) { ok = false; fail_idx = i; fail_code = "ERR_ARG"; break; }
            if (s < 1 || s > n) { ok = false; fail_idx = i; fail_code = "ERR_RANGE"; break; }
            auto it = pos.find(s);
            if (it == pos.end()) { ok = false; fail_idx = i; fail_code = "ERR_MISSING"; break; }
            auto itv = it->second;
            books.splice(books.begin(), books, itv);
            pos[s] = books.begin();
            tags.push_back("auto_operation_top");
            ++records;
        } else if (op == "Bottom") {
            long long s;
            if (!(cin >> s)) { ok = false; fail_idx = i; fail_code = "ERR_ARG"; break; }
            if (s < 1 || s > n) { ok = false; fail_idx = i; fail_code = "ERR_RANGE"; break; }
            auto it = pos.find(s);
            if (it == pos.end()) { ok = false; fail_idx = i; fail_code = "ERR_MISSING"; break; }
            auto itv = it->second;
            books.splice(books.end(), books, itv);
            pos[s] = prev(books.end());
            tags.push_back("auto_operation_bottom");
            ++records;
        } else if (op == "Insert") {
            long long s, t;
            if (!(cin >> s >> t)) { ok = false; fail_idx = i; fail_code = "ERR_ARG"; break; }
            if (s < 1 || s > n || t < -1 || t > 1) { ok = false; fail_idx = i; fail_code = "ERR_RANGE"; break; }
            auto it = pos.find(s);
            if (it == pos.end()) { ok = false; fail_idx = i; fail_code = "ERR_MISSING"; break; }
            auto itv = it->second;
            if (t == -1) {
                if (itv == books.begin()) { ok = false; fail_idx = i; fail_code = "ERR_ILLEGAL"; break; }
                auto target = prev(itv);
                books.splice(target, books, itv);
                pos[s] = target;
            } else if (t == 1) {
                auto nxt = next(itv);
                if (nxt == books.end()) { ok = false; fail_idx = i; fail_code = "ERR_ILLEGAL"; break; }
                auto target = next(nxt);
                books.splice(target, books, itv);
                pos[s] = target;
            } else {
                // t == 0, no move
            }
            tags.push_back("auto_operation_insert");
            ++records;
        } else if (op == "Ask") {
            long long s;
            if (!(cin >> s)) { ok = false; fail_idx = i; fail_code = "ERR_ARG"; break; }
            if (s < 1 || s > n) { ok = false; fail_idx = i; fail_code = "ERR_RANGE"; break; }
            if (pos.find(s) == pos.end()) { ok = false; fail_idx = i; fail_code = "ERR_MISSING"; break; }
            tags.push_back("auto_operation_ask");
            ++records;
        } else if (op == "Query") {
            long long k;
            if (!(cin >> k)) { ok = false; fail_idx = i; fail_code = "ERR_ARG"; break; }
            if (k < 1 || k > n) { ok = false; fail_idx = i; fail_code = "ERR_RANGE"; break; }
            tags.push_back("auto_operation_query");
            ++records;
        } else {
            ok = false; fail_idx = i; fail_code = "ERR_OP";
            break;
        }
    }

    if (ok) {
        string extra;
        if (cin >> extra) {
            ok = false; fail_idx = m; fail_code = "ERR_EXTRA";
        }
    }

    if (!ok) {
        cerr << fail_code << " " << fail_idx << "\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
        return 0;
    }

    // compute dimensions
    long long dim_n = n;
    long long dim_m = m;
    long long dim_ops = m;

    // coverage tags
    vector<string> cov;
    if (n == 1 && m == 0) cov.push_back("auto_c1_minimum");
    if (n == 80000) cov.push_back("auto_c1_maximum");
    if (m == 0) cov.push_back("auto_c2_minimum");
    if (m == 80000) cov.push_back("auto_c2_maximum");
    if (n == 1) cov.push_back("auto_c4_minimum");
    if (n == 80000) cov.push_back("auto_c4_maximum");
    if (n == 1) cov.push_back("auto_c5_minimum");
    if (n == 80000) cov.push_back("auto_c5_maximum");
    if (m == 0) cov.push_back("auto_c6_minimum");
    if (m == 80000) cov.push_back("auto_c6_maximum");

    // operation coverage
    bool has_top=false, has_bottom=false, has_insert=false, has_ask=false, has_query=false;
    // we already have tags list; but we need to know which ops appeared
    // re-scan? we can track during parsing, but simpler: we have tags vector with operation names
    for (auto &tg : tags) {
        if (tg == "auto_operation_top") has_top = true;
        if (tg == "auto_operation_bottom") has_bottom = true;
        if (tg == "auto_operation_insert") has_insert = true;
        if (tg == "auto_operation_ask") has_ask = true;
        if (tg == "auto_operation_query") has_query = true;
    }
    if (has_top) cov.push_back("auto_operation_top");
    if (has_bottom) cov.push_back("auto_operation_bottom");
    if (has_insert) cov.push_back("auto_operation_insert");
    if (has_ask) cov.push_back("auto_operation_ask");
    if (has_query) cov.push_back("auto_operation_query");

    // deduplicate coverage tags
    sort(cov.begin(), cov.end());
    cov.erase(unique(cov.begin(), cov.end()), cov.end());

    // build JSON
    string dims = "{\"n\":" + esc(dim_n) + ",\"m\":" + esc(dim_m) + ",\"ops\":" + esc(dim_ops) + "}";
    string covs = "[";
    for (size_t i = 0; i < cov.size(); ++i) {
        if (i) covs += ",";
        covs += "\"" + cov[i] + "\"";
    }
    covs += "]";

    cout << "{\"valid\":true,\"dimensions\":" << dims << ",\"coverage_tags\":" << covs << ",\"records\":" << records << "}";
    return 0;
}
