#include <bits/stdc++.h>
using namespace std;

static string esc(long long x){ return to_string(x); }

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    string tok;
    if(!(cin>>tok)){
        cout<<"{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
        return 0;
    }
    long long n,m;
    try { size_t p1=0; n=stoll(tok,&p1); if(p1!=tok.size()) throw 1; }
    catch(...){ cerr<<"E1 0\n"; cout<<"{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n"; return 0; }
    if(!(cin>>tok)){
        cerr<<"E2 0\n"; cout<<"{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n"; return 0;
    }
    try { size_t p2=0; m=stoll(tok,&p2); if(p2!=tok.size()) throw 1; }
    catch(...){ cerr<<"E3 0\n"; cout<<"{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n"; return 0; }
    if(n<1||n>80000||m<0||m>80000){
        cerr<<"E4 0\n"; cout<<"{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n"; return 0;
    }
    vector<int> perm;
    perm.reserve((size_t)n);
    vector<char> seen((size_t)n+1,0);
    for(long long i=0;i<n;i++){
        if(!(cin>>tok)){
            cerr<<"E5 "<<i<<"\n"; cout<<"{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n"; return 0;
        }
        long long x;
        try { size_t pp=0; x=stoll(tok,&pp); if(pp!=tok.size()) throw 1; }
        catch(...){ cerr<<"E6 "<<i<<"\n"; cout<<"{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n"; return 0; }
        if(x<1||x>n||seen[(size_t)x]){
            cerr<<"E7 "<<i<<"\n"; cout<<"{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n"; return 0;
        }
        seen[(size_t)x]=1;
        perm.push_back((int)x);
    }
    list<int> seq(perm.begin(), perm.end());
    unordered_map<int, list<int>::iterator> pos;
    pos.reserve((size_t)n*2);
    {
        auto it=seq.begin();
        for(int v: perm){ pos[v]=it; ++it; }
    }
    vector<string> tags;
    tags.reserve((size_t)m);
    bool hasTop=false, hasBottom=false, hasInsert=false, hasAsk=false, hasQuery=false;
    long long records=1 + n + m;
    for(long long i=0;i<m;i++){
        if(!(cin>>tok)){
            cerr<<"E8 "<<i<<"\n"; cout<<"{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n"; return 0;
        }
        if(tok=="Top"){
            hasTop=true;
            if(!(cin>>tok)){
                cerr<<"E9 "<<i<<"\n"; cout<<"{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n"; return 0;
            }
            long long s;
            try { size_t pp=0; s=stoll(tok,&pp); if(pp!=tok.size()) throw 1; }
            catch(...){ cerr<<"E10 "<<i<<"\n"; cout<<"{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n"; return 0; }
            if(s<1||s>n||!pos.count((int)s)){
                cerr<<"E11 "<<i<<"\n"; cout<<"{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n"; return 0;
            }
            auto it=pos[(int)s];
            seq.splice(seq.begin(), seq, it);
        } else if(tok=="Bottom"){
            hasBottom=true;
            if(!(cin>>tok)){
                cerr<<"E12 "<<i<<"\n"; cout<<"{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n"; return 0;
            }
            long long s;
            try { size_t pp=0; s=stoll(tok,&pp); if(pp!=tok.size()) throw 1; }
            catch(...){ cerr<<"E13 "<<i<<"\n"; cout<<"{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n"; return 0; }
            if(s<1||s>n||!pos.count((int)s)){
                cerr<<"E14 "<<i<<"\n"; cout<<"{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n"; return 0;
            }
            auto it=pos[(int)s];
            seq.splice(seq.end(), seq, it);
        } else if(tok=="Insert"){
            hasInsert=true;
            if(!(cin>>tok)){
                cerr<<"E15 "<<i<<"\n"; cout<<"{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n"; return 0;
            }
            long long s;
            try { size_t pp=0; s=stoll(tok,&pp); if(pp!=tok.size()) throw 1; }
            catch(...){ cerr<<"E16 "<<i<<"\n"; cout<<"{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n"; return 0; }
            if(!(cin>>tok)){
                cerr<<"E17 "<<i<<"\n"; cout<<"{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n"; return 0;
            }
            long long t;
            try { size_t pp=0; t=stoll(tok,&pp); if(pp!=tok.size()) throw 1; }
            catch(...){ cerr<<"E18 "<<i<<"\n"; cout<<"{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n"; return 0; }
            if(s<1||s>n||t<-1||t>1||!pos.count((int)s)){
                cerr<<"E19 "<<i<<"\n"; cout<<"{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n"; return 0;
            }
            auto it=pos[(int)s];
            if(t==-1){
                if(it==seq.begin()){
                    cerr<<"E20 "<<i<<"\n"; cout<<"{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n"; return 0;
                }
                auto target=prev(it);
                seq.splice(target, seq, it);
            } else if(t==1){
                auto nxt=next(it);
                if(nxt==seq.end()){
                    cerr<<"E21 "<<i<<"\n"; cout<<"{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n"; return 0;
                }
                auto target=next(nxt);
                seq.splice(target, seq, it);
            }
        } else if(tok=="Ask"){
            hasAsk=true;
            if(!(cin>>tok)){
                cerr<<"E22 "<<i<<"\n"; cout<<"{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n"; return 0;
            }
            long long s;
            try { size_t pp=0; s=stoll(tok,&pp); if(pp!=tok.size()) throw 1; }
            catch(...){ cerr<<"E23 "<<i<<"\n"; cout<<"{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n"; return 0; }
            if(s<1||s>n||!pos.count((int)s)){
                cerr<<"E24 "<<i<<"\n"; cout<<"{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n"; return 0;
            }
        } else if(tok=="Query"){
            hasQuery=true;
            if(!(cin>>tok)){
                cerr<<"E25 "<<i<<"\n"; cout<<"{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n"; return 0;
            }
            long long k;
            try { size_t pp=0; k=stoll(tok,&pp); if(pp!=tok.size()) throw 1; }
            catch(...){ cerr<<"E26 "<<i<<"\n"; cout<<"{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n"; return 0; }
            if(k<1||k>n){
                cerr<<"E27 "<<i<<"\n"; cout<<"{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n"; return 0;
            }
        } else {
            cerr<<"E28 "<<i<<"\n"; cout<<"{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n"; return 0;
        }
    }
    if(cin>>tok){
        cerr<<"E29 "<<m<<"\n"; cout<<"{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n"; return 0;
    }
    vector<string> cov;
    if(n==1&&m==0) cov.push_back("auto_c1_minimum");
    if(n==80000) cov.push_back("auto_c1_maximum");
    if(m==0) cov.push_back("auto_c2_minimum");
    if(m==80000) cov.push_back("auto_c2_maximum");
    if(hasTop) cov.push_back("auto_operation_top");
    if(hasBottom) cov.push_back("auto_operation_bottom");
    if(hasInsert) cov.push_back("auto_operation_insert");
    if(hasAsk) cov.push_back("auto_operation_ask");
    if(hasQuery) cov.push_back("auto_operation_query");
    if(n==1&&m==0) cov.push_back("auto_c4_minimum");
    if(n==80000&&m==80000) cov.push_back("auto_c4_maximum");
    if(n==1&&m==0) cov.push_back("auto_c5_minimum");
    if(n==80000&&m==80000) cov.push_back("auto_c5_maximum");
    if(n==1&&m==0) cov.push_back("auto_c6_minimum");
    if(n==80000&&m==80000) cov.push_back("auto_c6_maximum");
    cout<<"{\"valid\":true,\"dimensions\":{\"n\":"<<n<<",\"m\":"<<m<<"},\"coverage_tags\":[";
    for(size_t i=0;i<cov.size();i++){
        if(i) cout<<",";
        cout<<"\""<<cov[i]<<"\"";
    }
    cout<<"],\"records\":"<<records<<"}\n";
    return 0;
}
