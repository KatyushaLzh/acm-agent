#include <bits/stdc++.h>
using namespace std;

static vector<int> parse_perm(const string& s) {
    vector<int> v;
    string cur;
    for (char c : s) {
        if (c == ' ' || c == '\n' || c == '\r') {
            if (!cur.empty()) { v.push_back(stoi(cur)); cur.clear(); }
        } else cur.push_back(c);
    }
    if (!cur.empty()) v.push_back(stoi(cur));
    return v;
}

static string trim(const string& s) {
    size_t a = s.find_first_not_of(" \t\r\n");
    if (a == string::npos) return "";
    size_t b = s.find_last_not_of(" \t\r\n");
    return s.substr(a, b - a + 1);
}

static vector<string> split_ws(const string& s) {
    vector<string> r;
    string cur;
    for (char c : s) {
        if (isspace((unsigned char)c)) {
            if (!cur.empty()) { r.push_back(cur); cur.clear(); }
        } else cur.push_back(c);
    }
    if (!cur.empty()) r.push_back(cur);
    return r;
}

static string join(const vector<string>& v, const string& sep) {
    string r;
    for (size_t i = 0; i < v.size(); ++i) {
        if (i) r += sep;
        r += v[i];
    }
    return r;
}

static string make_perm_string(const vector<int>& p) {
    string r;
    for (size_t i = 0; i < p.size(); ++i) {
        if (i) r += ' ';
        r += to_string(p[i]);
    }
    return r;
}

static string make_op_string(const string& op, const vector<int>& args) {
    string r = op;
    for (int a : args) r += " " + to_string(a);
    return r;
}

static vector<int> apply_op(const vector<int>& cur, const string& op, const vector<int>& args, bool& ok) {
    ok = true;
    vector<int> v = cur;
    int n = (int)v.size();
    if (op == "Top") {
        int s = args[0];
        auto it = find(v.begin(), v.end(), s);
        if (it == v.end()) { ok = false; return v; }
        v.erase(it);
        v.insert(v.begin(), s);
    } else if (op == "Bottom") {
        int s = args[0];
        auto it = find(v.begin(), v.end(), s);
        if (it == v.end()) { ok = false; return v; }
        v.erase(it);
        v.push_back(s);
    } else if (op == "Insert") {
        int s = args[0], t = args[1];
        auto it = find(v.begin(), v.end(), s);
        if (it == v.end()) { ok = false; return v; }
        int pos = (int)(it - v.begin());
        int newpos = pos + t;
        if (newpos < 0 || newpos >= n) { ok = false; return v; }
        v.erase(it);
        v.insert(v.begin() + newpos, s);
    } else if (op == "Ask") {
        int s = args[0];
        auto it = find(v.begin(), v.end(), s);
        if (it == v.end()) { ok = false; return v; }
    } else if (op == "Query") {
        int k = args[0];
        if (k < 1 || k > n) { ok = false; return v; }
    } else {
        ok = false;
    }
    return v;
}

static void gen_small_random(unsigned long long seed, ostream& out) {
    mt19937_64 rng(seed);
    int n = 5, m = 8;
    vector<int> perm = {1,2,3,4,5};
    vector<string> ops;
    vector<int> state = perm;

    auto add_op = [&](const string& op, const vector<int>& args) {
        bool ok;
        vector<int> ns = apply_op(state, op, args, ok);
        if (!ok) return false;
        ops.push_back(make_op_string(op, args));
        state = ns;
        return true;
    };

    // fixed skeleton
    add_op("Top", {3});
    add_op("Bottom", {1});
    add_op("Insert", {2, -1});
    add_op("Insert", {4, 1});
    add_op("Insert", {5, 0});

    // seed-dependent safe ops
    int ask1 = (int)(rng() % n) + 1;
    int ask2 = (int)(rng() % n) + 1;
    int qk = (int)(rng() % n) + 1;
    add_op("Ask", {ask1});
    add_op("Ask", {ask2});
    add_op("Query", {qk});
    add_op("Top", {5});

    out << n << " " << m << "\n";
    out << make_perm_string(perm) << "\n";
    for (auto& s : ops) out << s << "\n";
}

static void gen_large_random(unsigned long long seed, ostream& out) {
    mt19937_64 rng(seed);
    int n = 80000, m = 80000;
    out << n << " " << m << "\n";
    for (int i = 1; i <= n; ++i) {
        if (i > 1) out << ' ';
        out << i;
    }
    out << "\n";
    for (int i = 0; i < m; ++i) {
        if (rng() & 1) {
            int k = (int)(rng() % n) + 1;
            out << "Query " << k << "\n";
        } else {
            int s = (int)(rng() % n) + 1;
            out << "Ask " << s << "\n";
        }
    }
}

void acm_generate_case(unsigned long long seed, const string& profile, const string& case_kind, ostream& out) {
    if (profile == "small" && case_kind == "lower_bound") {
        out << "1 0\n1\n";
    } else if (profile == "small" && case_kind == "random") {
        gen_small_random(seed, out);
    } else if (profile == "large" && case_kind == "upper_bound") {
        int n = 80000, m = 80000;
        out << n << " " << m << "\n";
        for (int i = 1; i <= n; ++i) {
            if (i > 1) out << ' ';
            out << i;
        }
        out << "\n";
        for (int i = 0; i < m; ++i) out << "Query 1\n";
    } else if (profile == "large" && case_kind == "random") {
        gen_large_random(seed, out);
    } else {
        // fallback: minimal valid
        out << "1 0\n1\n";
    }
}
