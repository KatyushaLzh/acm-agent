#include <algorithm>
#include <cstdint>
#include <iostream>
#include <random>
#include <string>
#include <vector>

void acm_generate_case(unsigned long long seed, const std::string& profile,
                       const std::string& case_kind, std::ostream& out) {
    if (profile == "small" && case_kind == "lower_bound") {
        out << "1 0\n";
        out << "1\n";
        return;
    }

    if (profile == "small" && case_kind == "random") {
        std::mt19937_64 rng(seed);
        int n = 5;
        int m = 8;
        out << n << " " << m << "\n";
        out << "1 2 3 4 5\n";

        std::vector<int> state = {1, 2, 3, 4, 5};

        auto find_pos = [&](int val) -> int {
            for (int i = 0; i < (int)state.size(); ++i) {
                if (state[i] == val) return i;
            }
            return -1;
        };

        auto erase_at = [&](int pos) {
            state.erase(state.begin() + pos);
        };

        auto insert_at = [&](int pos, int val) {
            state.insert(state.begin() + pos, val);
        };

        // Fixed legal skeleton: Top 3, Bottom 1, Insert 2 -1, Insert 4 1,
        // Insert 5 0, then seed-dependent Ask/Query, then Top 5.
        // Top 3
        {
            int s = 3;
            int p = find_pos(s);
            erase_at(p);
            insert_at(0, s);
            out << "Top " << s << "\n";
        }
        // Bottom 1
        {
            int s = 1;
            int p = find_pos(s);
            erase_at(p);
            insert_at((int)state.size(), s);
            out << "Bottom " << s << "\n";
        }
        // Insert 2 -1
        {
            int s = 2;
            int t = -1;
            int p = find_pos(s);
            int np = p + t;
            erase_at(p);
            insert_at(np, s);
            out << "Insert " << s << " " << t << "\n";
        }
        // Insert 4 1
        {
            int s = 4;
            int t = 1;
            int p = find_pos(s);
            int np = p + t;
            erase_at(p);
            insert_at(np, s);
            out << "Insert " << s << " " << t << "\n";
        }
        // Insert 5 0
        {
            int s = 5;
            int t = 0;
            int p = find_pos(s);
            int np = p + t;
            erase_at(p);
            insert_at(np, s);
            out << "Insert " << s << " " << t << "\n";
        }

        // Seed-dependent read-only operations: Ask and Query.
        // We have 3 operations left (m=8, used 5). Use 2 Ask and 1 Query.
        int ask1 = (int)(rng() % n) + 1;
        int ask2 = (int)(rng() % n) + 1;
        int qk = (int)(rng() % n) + 1;

        out << "Ask " << ask1 << "\n";
        out << "Ask " << ask2 << "\n";
        out << "Query " << qk << "\n";

        // Top 5 (last operation)
        {
            int s = 5;
            int p = find_pos(s);
            erase_at(p);
            insert_at(0, s);
            out << "Top " << s << "\n";
        }

        return;
    }

    if (profile == "large" && case_kind == "upper_bound") {
        int n = 80000;
        int m = 80000;
        out << n << " " << m << "\n";
        for (int i = 1; i <= n; ++i) {
            if (i > 1) out << " ";
            out << i;
        }
        out << "\n";
        for (int i = 0; i < m; ++i) {
            out << "Query 1\n";
        }
        return;
    }

    if (profile == "large" && case_kind == "random") {
        std::mt19937_64 rng(seed);
        int n = 80000;
        int m = 80000;
        out << n << " " << m << "\n";
        for (int i = 1; i <= n; ++i) {
            if (i > 1) out << " ";
            out << i;
        }
        out << "\n";

        // Only Ask and Query are allowed for large/random.
        // Alternate between Ask and Query, with seed-derived arguments.
        for (int i = 0; i < m; ++i) {
            if (i % 2 == 0) {
                int s = (int)(rng() % n) + 1;
                out << "Ask " << s << "\n";
            } else {
                int k = (int)(rng() % n) + 1;
                out << "Query " << k << "\n";
            }
        }
        return;
    }

    // Unreachable in normal operation; emit minimal valid input as fallback.
    out << "1 0\n1\n";
}
