#include <algorithm>
#include <cstdint>
#include <ostream>
#include <random>
#include <string>
#include <vector>

namespace {

struct BookList {
    std::vector<int> v;
    explicit BookList(int n) : v(n) {
        for (int i = 0; i < n; ++i) v[i] = i + 1;
    }
    int find_pos(int book) const {
        for (int i = 0; i < (int)v.size(); ++i)
            if (v[i] == book) return i;
        return -1;
    }
    void top(int book) {
        int p = find_pos(book);
        v.erase(v.begin() + p);
        v.insert(v.begin(), book);
    }
    void bottom(int book) {
        int p = find_pos(book);
        v.erase(v.begin() + p);
        v.push_back(book);
    }
    void insert_after(int book, int t) {
        int p = find_pos(book);
        v.erase(v.begin() + p);
        int np = p + t;
        if (np < 0) np = 0;
        if (np > (int)v.size()) np = (int)v.size();
        v.insert(v.begin() + np, book);
    }
    int ask(int book) const { return find_pos(book) + 1; }
    int query(int k) const { return v[k - 1]; }
};

void emit_small_lower_bound(std::ostream& out) {
    out << "1 0\n1\n";
}

void emit_small_random(std::ostream& out, unsigned long long seed) {
    std::mt19937_64 rng(seed);
    int n = 5, m = 8;
    out << n << ' ' << m << '\n';
    out << "1 2 3 4 5\n";

    BookList state(n);
    // Fixed legal skeleton from the blueprint.
    // Top 3
    out << "Top 3\n";
    state.top(3);
    // Bottom 1
    out << "Bottom 1\n";
    state.bottom(1);
    // Insert 2 -1
    out << "Insert 2 -1\n";
    state.insert_after(2, -1);
    // Insert 4 1
    out << "Insert 4 1\n";
    state.insert_after(4, 1);
    // Insert 5 0
    out << "Insert 5 0\n";
    state.insert_after(5, 0);
    // Ask 3 (read-only, safe to randomize the book argument)
    int ask_book = 1 + (int)(rng() % n);
    out << "Ask " << ask_book << '\n';
    // Query 2 (read-only, safe to randomize k)
    int query_k = 1 + (int)(rng() % n);
    out << "Query " << query_k << '\n';
    // Top 5
    out << "Top 5\n";
    state.top(5);
}

void emit_large_upper_bound(std::ostream& out) {
    int n = 80000, m = 80000;
    out << n << ' ' << m << '\n';
    for (int i = 1; i <= n; ++i) {
        if (i > 1) out << ' ';
        out << i;
    }
    out << '\n';
    for (int i = 1; i <= 40000; ++i) {
        out << "Top " << i << '\n';
    }
    for (int i = 1; i <= 40000; ++i) {
        out << "Query " << i << '\n';
    }
}

void emit_large_random(std::ostream& out, unsigned long long seed) {
    std::mt19937_64 rng(seed);
    int n = 80000, m = 80000;
    out << n << ' ' << m << '\n';
    for (int i = 1; i <= n; ++i) {
        if (i > 1) out << ' ';
        out << i;
    }
    out << '\n';

    // First 40000 Top operations on distinct books 1..40000 (legal, no state
    // verification needed because each book is distinct and exists).
    for (int i = 1; i <= 40000; ++i) {
        out << "Top " << i << '\n';
    }

    // Remaining 40000 Query operations. The blueprint says k cycles 1..n.
    // We keep the cycle but perturb the starting offset using the seed so that
    // the seed genuinely affects emitted semantic fields.
    int start = 1 + (int)(rng() % n);
    for (int i = 0; i < 40000; ++i) {
        int k = start + i;
        if (k > n) k -= n;
        out << "Query " << k << '\n';
    }
}

}  // namespace

void acm_generate_case(unsigned long long seed, const std::string& profile,
                       const std::string& case_kind, std::ostream& out) {
    if (profile == "small" && case_kind == "lower_bound") {
        emit_small_lower_bound(out);
    } else if (profile == "small" && case_kind == "random") {
        emit_small_random(out, seed);
    } else if (profile == "large" && case_kind == "upper_bound") {
        emit_large_upper_bound(out);
    } else if (profile == "large" && case_kind == "random") {
        emit_large_random(out, seed);
    }
}
