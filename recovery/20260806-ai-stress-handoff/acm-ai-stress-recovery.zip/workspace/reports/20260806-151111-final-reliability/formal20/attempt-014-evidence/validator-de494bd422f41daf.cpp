#include <bits/stdc++.h>
using namespace std;

static string esc(long long x) { return to_string(x); }

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    string token;
    if (!(cin >> token)) {
        cerr << "ERR_NO_INPUT\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
        return 0;
    }
    if (token.size() > 9) {
        cerr << "ERR_N_OVERFLOW\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
        return 0;
    }
    long long n = 0;
    for (char c : token) {
        if (c < '0' || c > '9') {
            cerr << "ERR_N_NOT_INT\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
            return 0;
        }
        n = n * 10 + (c - '0');
        if (n > 80000) {
            cerr << "ERR_N_RANGE\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
            return 0;
        }
    }

    if (!(cin >> token)) {
        cerr << "ERR_NO_M\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
        return 0;
    }
    if (token.size() > 9) {
        cerr << "ERR_M_OVERFLOW\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
        return 0;
    }
    long long m = 0;
    for (char c : token) {
        if (c < '0' || c > '9') {
            cerr << "ERR_M_NOT_INT\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
            return 0;
        }
        m = m * 10 + (c - '0');
        if (m > 80000) {
            cerr << "ERR_M_RANGE\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
            return 0;
        }
    }

    if (n < 1) {
        cerr << "ERR_N_MIN\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
        return 0;
    }
    if (m < 0) {
        cerr << "ERR_M_MIN\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
        return 0;
    }

    vector<int> perm;
    perm.reserve((size_t)n);
    vector<char> seen((size_t)n + 1, 0);
    for (long long i = 0; i < n; ++i) {
        if (!(cin >> token)) {
            cerr << "ERR_PERM_SHORT\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
            return 0;
        }
        if (token.size() > 9) {
            cerr << "ERR_PERM_OVERFLOW\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
            return 0;
        }
        long long x = 0;
        for (char c : token) {
            if (c < '0' || c > '9') {
                cerr << "ERR_PERM_NOT_INT\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            x = x * 10 + (c - '0');
            if (x > 80000) {
                cerr << "ERR_PERM_RANGE\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
        }
        if (x < 1 || x > n) {
            cerr << "ERR_PERM_RANGE\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
            return 0;
        }
        if (seen[(size_t)x]) {
            cerr << "ERR_PERM_DUP\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
            return 0;
        }
        seen[(size_t)x] = 1;
        perm.push_back((int)x);
    }

    list<int> books;
    vector<list<int>::iterator> pos((size_t)n + 1);
    for (int i = 0; i < (int)n; ++i) {
        books.push_back(perm[(size_t)i]);
        pos[(size_t)perm[(size_t)i]] = prev(books.end());
    }

    vector<string> tags;
    bool hasTop = false, hasBottom = false, hasInsert = false, hasAsk = false, hasQuery = false;
    bool hasTopMin = false, hasTopMax = false;
    bool hasBottomMin = false, hasBottomMax = false;
    bool hasInsertMin = false, hasInsertMax = false;
    bool hasAskMin = false, hasAskMax = false;
    bool hasQueryMin = false, hasQueryMax = false;
    bool hasInsertTMin = false, hasInsertTMax = false;
    long long records = m;

    for (long long idx = 0; idx < m; ++idx) {
        string op;
        if (!(cin >> op)) {
            cerr << "ERR_OP_SHORT " << idx << "\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
            return 0;
        }
        if (op == "Top") {
            hasTop = true;
            if (!(cin >> token)) {
                cerr << "ERR_TOP_ARG " << idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            long long s = 0;
            for (char c : token) {
                if (c < '0' || c > '9') {
                    cerr << "ERR_TOP_NOT_INT " << idx << "\n";
                    cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                    return 0;
                }
                s = s * 10 + (c - '0');
                if (s > 80000) {
                    cerr << "ERR_TOP_RANGE " << idx << "\n";
                    cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                    return 0;
                }
            }
            if (s < 1 || s > n) {
                cerr << "ERR_TOP_RANGE " << idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (s == 1) hasTopMin = true;
            if (s == n) hasTopMax = true;
            auto it = pos[(size_t)s];
            if (it != books.begin()) {
                books.splice(books.begin(), books, it);
            }
        } else if (op == "Bottom") {
            hasBottom = true;
            if (!(cin >> token)) {
                cerr << "ERR_BOT_ARG " << idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            long long s = 0;
            for (char c : token) {
                if (c < '0' || c > '9') {
                    cerr << "ERR_BOT_NOT_INT " << idx << "\n";
                    cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                    return 0;
                }
                s = s * 10 + (c - '0');
                if (s > 80000) {
                    cerr << "ERR_BOT_RANGE " << idx << "\n";
                    cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                    return 0;
                }
            }
            if (s < 1 || s > n) {
                cerr << "ERR_BOT_RANGE " << idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (s == 1) hasBottomMin = true;
            if (s == n) hasBottomMax = true;
            auto it = pos[(size_t)s];
            if (it != prev(books.end())) {
                books.splice(books.end(), books, it);
            }
        } else if (op == "Insert") {
            hasInsert = true;
            if (!(cin >> token)) {
                cerr << "ERR_INS_S " << idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            long long s = 0;
            for (char c : token) {
                if (c < '0' || c > '9') {
                    cerr << "ERR_INS_S_NOT_INT " << idx << "\n";
                    cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                    return 0;
                }
                s = s * 10 + (c - '0');
                if (s > 80000) {
                    cerr << "ERR_INS_S_RANGE " << idx << "\n";
                    cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                    return 0;
                }
            }
            if (s < 1 || s > n) {
                cerr << "ERR_INS_S_RANGE " << idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (s == 1) hasInsertMin = true;
            if (s == n) hasInsertMax = true;
            if (!(cin >> token)) {
                cerr << "ERR_INS_T " << idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            long long t = 0;
            bool neg = false;
            size_t p = 0;
            if (!token.empty() && token[0] == '-') {
                neg = true;
                p = 1;
            }
            if (p >= token.size()) {
                cerr << "ERR_INS_T_NOT_INT " << idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            for (; p < token.size(); ++p) {
                char c = token[p];
                if (c < '0' || c > '9') {
                    cerr << "ERR_INS_T_NOT_INT " << idx << "\n";
                    cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                    return 0;
                }
                t = t * 10 + (c - '0');
                if (t > 80000) {
                    cerr << "ERR_INS_T_RANGE " << idx << "\n";
                    cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                    return 0;
                }
            }
            if (neg) t = -t;
            if (t < -1 || t > 1) {
                cerr << "ERR_INS_T_RANGE " << idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (t == -1) hasInsertTMin = true;
            if (t == 1) hasInsertTMax = true;
            auto it = pos[(size_t)s];
            if (t == -1) {
                if (it != books.begin()) {
                    auto target = prev(it);
                    books.splice(target, books, it);
                }
            } else if (t == 1) {
                auto nxt = next(it);
                if (nxt != books.end()) {
                    auto target = next(nxt);
                    books.splice(target, books, it);
                }
            }
        } else if (op == "Ask") {
            hasAsk = true;
            if (!(cin >> token)) {
                cerr << "ERR_ASK_ARG " << idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            long long s = 0;
            for (char c : token) {
                if (c < '0' || c > '9') {
                    cerr << "ERR_ASK_NOT_INT " << idx << "\n";
                    cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                    return 0;
                }
                s = s * 10 + (c - '0');
                if (s > 80000) {
                    cerr << "ERR_ASK_RANGE " << idx << "\n";
                    cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                    return 0;
                }
            }
            if (s < 1 || s > n) {
                cerr << "ERR_ASK_RANGE " << idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (s == 1) hasAskMin = true;
            if (s == n) hasAskMax = true;
        } else if (op == "Query") {
            hasQuery = true;
            if (!(cin >> token)) {
                cerr << "ERR_QRY_ARG " << idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            long long k = 0;
            for (char c : token) {
                if (c < '0' || c > '9') {
                    cerr << "ERR_QRY_NOT_INT " << idx << "\n";
                    cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                    return 0;
                }
                k = k * 10 + (c - '0');
                if (k > 80000) {
                    cerr << "ERR_QRY_RANGE " << idx << "\n";
                    cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                    return 0;
                }
            }
            if (k < 1 || k > n) {
                cerr << "ERR_QRY_RANGE " << idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (k == 1) hasQueryMin = true;
            if (k == n) hasQueryMax = true;
        } else {
            cerr << "ERR_OP_UNKNOWN " << idx << "\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
            return 0;
        }
    }

    if (cin >> token) {
        cerr << "ERR_TRAILING\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
        return 0;
    }

    if (hasTop) tags.push_back("auto_operation_top");
    if (hasBottom) tags.push_back("auto_operation_bottom");
    if (hasInsert) tags.push_back("auto_operation_insert");
    if (hasAsk) tags.push_back("auto_operation_ask");
    if (hasQuery) tags.push_back("auto_operation_query");

    if (n == 1 && m == 0) tags.push_back("auto_c1_minimum");
    if (n == 80000 && m == 80000) tags.push_back("auto_c1_maximum");
    if (m == 0) tags.push_back("auto_c2_minimum");
    if (m == 80000) tags.push_back("auto_c2_maximum");

    if (hasTopMin) tags.push_back("auto_c4_minimum");
    if (hasTopMax) tags.push_back("auto_c4_maximum");
    if (hasBottomMin) tags.push_back("auto_c4_minimum");
    if (hasBottomMax) tags.push_back("auto_c4_maximum");
    if (hasInsertMin) tags.push_back("auto_c4_minimum");
    if (hasInsertMax) tags.push_back("auto_c4_maximum");
    if (hasAskMin) tags.push_back("auto_c4_minimum");
    if (hasAskMax) tags.push_back("auto_c4_maximum");

    if (hasQueryMin) tags.push_back("auto_c5_minimum");
    if (hasQueryMax) tags.push_back("auto_c5_maximum");

    if (hasInsertTMin) tags.push_back("auto_c6_minimum");
    if (hasInsertTMax) tags.push_back("auto_c6_maximum");

    cout << "{\"valid\":true,\"dimensions\":{\"n\":" << n << ",\"m\":" << m << "},\"coverage_tags\":[";
    for (size_t i = 0; i < tags.size(); ++i) {
        if (i) cout << ",";
        cout << "\"" << tags[i] << "\"";
    }
    cout << "],\"records\":" << records << "}\n";
    return 0;
}
