# AI Stress Benchmark Report

## Outcome

| Metric | Value |
|---|---:|
| Attempts | 20 |
| Successes | 14 |
| Success rate | 70.0% |
| First-round success rate | 55.0% |
| Unsafe applies | 0 |
| Successful time p50 / p95 | 109.511 / 167.395 s |
| Successful tokens p50 / p95 | 31039.000 / 61632.000 |
| Provider requests | 154.000 |
| Retries | 2.000 |

## Failure stages

| Stage | Attempts |
|---|---:|
| extract_contract | 3 |
| preflight_helpers | 1 |
| prepare_helpers | 2 |

## Repair roles

| Role | Attempts |
|---|---:|
| contract | 1 |
| generator | 2 |
| validator | 4 |

## Stage duration percentiles

| Stage | p50 | p95 | max |
|---|---:|---:|---:|
| apply_helpers | 0.910 | 1.007 | 1.007 |
| audit_brute_attempt_1 | 1.142 | 2.038 | 2.038 |
| audit_generator_attempt_1 | 1.318 | 2.391 | 2.391 |
| audit_helpers | 1.525 | 44.422 | 44.422 |
| audit_validator_attempt_1 | 1.271 | 3.752 | 3.752 |
| audit_validator_attempt_2 | 1.172 | 2.207 | 2.207 |
| check_isolation | 2.590 | 3.194 | 3.533 |
| create_stress_run | 21.558 | 28.425 | 28.425 |
| extract_contract | 7.820 | 13.973 | 15.865 |
| extract_contract/provider_request | 7.725 | 13.966 | 15.850 |
| generate_blueprint/provider_request | 3.022 | 3.920 | 3.920 |
| generate_brute | 0.000 | 0.000 | 0.000 |
| generate_brute/provider_request | 2.879 | 4.115 | 4.115 |
| generate_generator | 3.023 | 3.920 | 3.920 |
| generate_generator/provider_finalizer | 7.076 | 9.553 | 9.553 |
| generate_generator/provider_request | 6.667 | 55.469 | 55.469 |
| generate_validator | 0.000 | 0.000 | 0.000 |
| generate_validator/provider_patch_fallback | 9.821 | 20.346 | 20.346 |
| generate_validator/provider_request | 12.795 | 64.993 | 64.993 |
| preflight_helpers | 22.104 | 25.366 | 25.366 |
| prepare_reference | 46.848 | 104.456 | 104.456 |
| queued | 0.035 | 0.054 | 0.096 |
| repair_validator_attempt_1 | 34.793 | 34.793 | 34.793 |

## Token category percentiles

| Category | p50 | p95 | max |
|---|---:|---:|---:|
| completion_tokens | 5991.000 | 15163.000 | 19225.000 |
| prompt_cache_hit_tokens | 8320.000 | 11904.000 | 18560.000 |
| prompt_cache_miss_tokens | 16434.000 | 25045.000 | 37040.000 |
| prompt_tokens | 24542.000 | 42407.000 | 48944.000 |
| reasoning_tokens | 4096.000 | 4096.000 | 4096.000 |
| total_tokens | 31039.000 | 61632.000 | 64107.000 |
