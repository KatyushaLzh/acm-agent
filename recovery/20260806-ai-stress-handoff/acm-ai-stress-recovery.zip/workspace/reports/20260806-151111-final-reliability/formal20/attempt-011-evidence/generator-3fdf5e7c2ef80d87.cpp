#include <algorithm>
#include <cstdint>
#include <ostream>
#include <random>
#include <string>
#include <vector>

void acm_generate_case(unsigned long long seed, const std::string& profile,
                       const std::string& case_kind, std::ostream& out) {
    if (profile == "small" && case_kind == "lower_bound") {
        out << "1 0\n";
        out << "1\n";
        return;
    }

    if (profile == "small" && case_kind == "random") {
        std::mt19937_64 rng(seed);
        int n = 5;
        int m = 6;
        out << n << ' ' << m << '\n';
        out << "1 2 3 4 5\n";

        std::vector<int> state = {1, 2, 3, 4, 5};

        auto find_pos = [&](int val) -> int {
            for (int i = 0; i < (int)state.size(); ++i) {
                if (state[i] == val) return i;
            }
            return -1;
        };

        auto emit_top = [&](int s) {
            int pos = find_pos(s);
            int val = state[pos];
            state.erase(state.begin() + pos);
            state.insert(state.begin(), val);
            out << "Top " << s << '\n';
        };

        auto emit_bottom = [&](int s) {
            int pos = find_pos(s);
            int val = state[pos];
            state.erase(state.begin() + pos);
            state.push_back(val);
            out << "Bottom " << s << '\n';
        };

        auto emit_insert = [&](int s, int t) {
            int pos = find_pos(s);
            int val = state[pos];
            state.erase(state.begin() + pos);
            int new_pos = pos + t;
            if (new_pos < 0) new_pos = 0;
            if (new_pos > (int)state.size()) new_pos = (int)state.size();
            state.insert(state.begin() + new_pos, val);
            out << "Insert " << s << ' ' << t << '\n';
        };

        auto emit_ask = [&](int s) {
            int pos = find_pos(s);
            out << "Ask " << s << '\n';
            (void)pos;
        };

        auto emit_query = [&](int k) {
            out << "Query " << k << '\n';
        };

        emit_top(3);
        emit_bottom(1);
        emit_insert(2, 1);
        emit_insert(4, -1);

        int ask_arg = 3;
        int query_arg = 2;
        if (seed % 2 == 0) {
            ask_arg = 1 + (int)(rng() % 5);
        } else {
            query_arg = 1 + (int)(rng() % 5);
        }
        emit_ask(ask_arg);
        emit_query(query_arg);
        return;
    }

    if (profile == "large" && case_kind == "upper_bound") {
        int n = 80000;
        int m = 80000;
        out << n << ' ' << m << '\n';
        for (int i = 1; i <= n; ++i) {
            if (i > 1) out << ' ';
            out << i;
        }
        out << '\n';
        for (int i = 0; i < m; ++i) {
            out << "Query 1\n";
        }
        return;
    }

    if (profile == "large" && case_kind == "random") {
        std::mt19937_64 rng(seed);
        int n = 80000;
        int m = 80000;
        out << n << ' ' << m << '\n';
        for (int i = 1; i <= n; ++i) {
            if (i > 1) out << ' ';
            out << i;
        }
        out << '\n';

        for (int i = 0; i < m; ++i) {
            if (rng() % 2 == 0) {
                int k = 1 + (int)(rng() % n);
                out << "Query " << k << '\n';
            } else {
                int s = 1 + (int)(rng() % n);
                out << "Ask " << s << '\n';
            }
        }
        return;
    }
}
