#include <bits/stdc++.h>
using namespace std;

static string esc(const string& s) {
    string r;
    for (char c : s) {
        if (c == '"' || c == '\\') { r += '\\'; r += c; }
        else if (c == '\n') r += "\\n";
        else if (c == '\r') r += "\\r";
        else if (c == '\t') r += "\\t";
        else if ((unsigned char)c < 0x20) {
            char buf[8];
            snprintf(buf, sizeof(buf), "\\u%04x", (unsigned char)c);
            r += buf;
        } else r += c;
    }
    return r;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    auto fail = [&](const string& msg) {
        cerr << msg << "\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
        return 0;
    };

    long long n, m;
    if (!(cin >> n >> m)) return fail("ERR_READ_HEADER");
    if (n < 1 || n > 80000) return fail("ERR_N_RANGE");
    if (m < 0 || m > 80000) return fail("ERR_M_RANGE");

    vector<int> perm;
    perm.reserve((size_t)n);
    vector<char> seen((size_t)n + 1, 0);
    for (long long i = 0; i < n; ++i) {
        long long x;
        if (!(cin >> x)) return fail("ERR_READ_PERM");
        if (x < 1 || x > n) return fail("ERR_PERM_VAL");
        if (seen[(size_t)x]) return fail("ERR_PERM_DUP");
        seen[(size_t)x] = 1;
        perm.push_back((int)x);
    }

    list<int> seq;
    unordered_map<int, list<int>::iterator> pos;
    pos.reserve((size_t)n * 2);
    for (int v : perm) {
        seq.push_back(v);
        pos[v] = prev(seq.end());
    }

    vector<string> tags;
    auto addTag = [&](const string& t) {
        if (find(tags.begin(), tags.end(), t) == tags.end()) tags.push_back(t);
    };

    long long records = 0;
    bool hasTop = false, hasBottom = false, hasInsert = false, hasAsk = false, hasQuery = false;
    bool hasC4Min = false, hasC4Max = false, hasC5Min = false, hasC5Max = false, hasC6Min = false, hasC6Max = false;

    for (long long opIdx = 0; opIdx < m; ++opIdx) {
        string op;
        if (!(cin >> op)) return fail("ERR_READ_OP");
        records++;

        if (op == "Top") {
            long long s;
            if (!(cin >> s)) return fail("ERR_READ_ARG");
            if (s < 1 || s > n) return fail("ERR_ARG_RANGE");
            auto it = pos.find((int)s);
            if (it == pos.end()) return fail("ERR_NOT_IN_SEQ");
            auto lit = it->second;
            seq.splice(seq.begin(), seq, lit);
            addTag("auto_operation_top");
            hasTop = true;
            if (s == 1) hasC4Min = true;
            if (s == n) hasC4Max = true;
        } else if (op == "Bottom") {
            long long s;
            if (!(cin >> s)) return fail("ERR_READ_ARG");
            if (s < 1 || s > n) return fail("ERR_ARG_RANGE");
            auto it = pos.find((int)s);
            if (it == pos.end()) return fail("ERR_NOT_IN_SEQ");
            auto lit = it->second;
            seq.splice(seq.end(), seq, lit);
            addTag("auto_operation_bottom");
            hasBottom = true;
            if (s == 1) hasC4Min = true;
            if (s == n) hasC4Max = true;
        } else if (op == "Insert") {
            long long s, t;
            if (!(cin >> s >> t)) return fail("ERR_READ_ARG");
            if (s < 1 || s > n) return fail("ERR_ARG_RANGE");
            if (t < -1 || t > 1) return fail("ERR_T_RANGE");
            auto it = pos.find((int)s);
            if (it == pos.end()) return fail("ERR_NOT_IN_SEQ");
            auto lit = it->second;
            if (t == -1) {
                if (lit == seq.begin()) return fail("ERR_INSERT_FRONT");
                auto target = prev(lit);
                seq.splice(target, seq, lit);
            } else if (t == 1) {
                auto nxt = next(lit);
                if (nxt == seq.end()) return fail("ERR_INSERT_BACK");
                auto target = next(nxt);
                seq.splice(target, seq, lit);
            }
            addTag("auto_operation_insert");
            hasInsert = true;
            if (s == 1) hasC4Min = true;
            if (s == n) hasC4Max = true;
            if (t == -1) hasC6Min = true;
            if (t == 1) hasC6Max = true;
            if (t == 0) { hasC6Min = true; hasC6Max = true; }
        } else if (op == "Ask") {
            long long s;
            if (!(cin >> s)) return fail("ERR_READ_ARG");
            if (s < 1 || s > n) return fail("ERR_ARG_RANGE");
            if (pos.find((int)s) == pos.end()) return fail("ERR_NOT_IN_SEQ");
            addTag("auto_operation_ask");
            hasAsk = true;
            if (s == 1) hasC4Min = true;
            if (s == n) hasC4Max = true;
        } else if (op == "Query") {
            long long k;
            if (!(cin >> k)) return fail("ERR_READ_ARG");
            if (k < 1 || k > n) return fail("ERR_ARG_RANGE");
            addTag("auto_operation_query");
            hasQuery = true;
            if (k == 1) hasC5Min = true;
            if (k == n) hasC5Max = true;
        } else {
            return fail("ERR_UNKNOWN_OP");
        }
    }

    string extra;
    if (cin >> extra) return fail("ERR_TRAILING");

    if (n == 1) addTag("auto_c1_minimum");
    if (n == 80000) addTag("auto_c1_maximum");
    if (m == 0) addTag("auto_c2_minimum");
    if (m == 80000) addTag("auto_c2_maximum");
    if (hasC4Min) addTag("auto_c4_minimum");
    if (hasC4Max) addTag("auto_c4_maximum");
    if (hasC5Min) addTag("auto_c5_minimum");
    if (hasC5Max) addTag("auto_c5_maximum");
    if (hasC6Min) addTag("auto_c6_minimum");
    if (hasC6Max) addTag("auto_c6_maximum");

    cout << "{\"valid\":true,\"dimensions\":{\"n\":" << n << ",\"m\":" << m << "},\"coverage_tags\":[";
    for (size_t i = 0; i < tags.size(); ++i) {
        if (i) cout << ",";
        cout << "\"" << esc(tags[i]) << "\"";
    }
    cout << "],\"records\":" << records << "}\n";
    return 0;
}
