#include <algorithm>
#include <cstdint>
#include <iostream>
#include <random>
#include <sstream>
#include <string>
#include <vector>

static void emit_small_lower_bound(std::ostream& out) {
    out << "1 0\n1\n";
}

static void emit_small_random(unsigned long long seed, std::ostream& out) {
    std::mt19937_64 rng(seed);
    int n = 5;
    int m = 6;
    out << n << ' ' << m << '\n';
    out << "1 2 3 4 5\n";

    // Fixed legal skeleton: Top 3, Bottom 1, Insert 2 1, Insert 4 -1, Ask 3, Query 2
    // Seed only changes the Ask argument (read-only, unconditionally legal).
    int ask_arg = 1 + static_cast<int>(rng() % n); // 1..5

    out << "Top 3\n";
    out << "Bottom 1\n";
    out << "Insert 2 1\n";
    out << "Insert 4 -1\n";
    out << "Ask " << ask_arg << '\n';
    out << "Query 2\n";
}

static void emit_large_upper_bound(std::ostream& out) {
    int n = 80000;
    int m = 80000;
    out << n << ' ' << m << '\n';
    for (int i = 1; i <= n; ++i) {
        if (i > 1) out << ' ';
        out << i;
    }
    out << '\n';
    for (int i = 0; i < m; ++i) {
        out << "Ask 1\n";
    }
}

static void emit_large_random(unsigned long long seed, std::ostream& out) {
    std::mt19937_64 rng(seed);
    int n = 80000;
    int m = 80000;
    out << n << ' ' << m << '\n';
    for (int i = 1; i <= n; ++i) {
        if (i > 1) out << ' ';
        out << i;
    }
    out << '\n';
    for (int i = 0; i < m; ++i) {
        int ask_arg = 1 + static_cast<int>(rng() % n); // 1..80000
        out << "Ask " << ask_arg << '\n';
    }
}

void acm_generate_case(unsigned long long seed,
                       const std::string& profile,
                       const std::string& case_kind,
                       std::ostream& out) {
    if (profile == "small" && case_kind == "lower_bound") {
        emit_small_lower_bound(out);
    } else if (profile == "small" && case_kind == "random") {
        emit_small_random(seed, out);
    } else if (profile == "large" && case_kind == "upper_bound") {
        emit_large_upper_bound(out);
    } else if (profile == "large" && case_kind == "random") {
        emit_large_random(seed, out);
    } else {
        // Should not happen with the trusted harness, but emit a minimal valid case.
        emit_small_lower_bound(out);
    }
}
