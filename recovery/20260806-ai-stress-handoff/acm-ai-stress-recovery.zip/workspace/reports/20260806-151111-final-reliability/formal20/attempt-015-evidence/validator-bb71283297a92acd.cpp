#include <bits/stdc++.h>
using namespace std;

static string esc(long long x) { return to_string(x); }

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    string token;
    if (!(cin >> token)) {
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
        return 0;
    }
    long long n, m;
    try {
        size_t pos1 = 0;
        n = stoll(token, &pos1);
        if (pos1 != token.size()) throw invalid_argument("bad");
    } catch (...) {
        cerr << "ERR header n" << "\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
        return 0;
    }
    if (!(cin >> token)) {
        cerr << "ERR header m" << "\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
        return 0;
    }
    try {
        size_t pos2 = 0;
        m = stoll(token, &pos2);
        if (pos2 != token.size()) throw invalid_argument("bad");
    } catch (...) {
        cerr << "ERR header m" << "\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
        return 0;
    }

    if (n < 1 || n > 80000 || m < 0 || m > 80000) {
        cerr << "ERR header range" << "\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
        return 0;
    }

    vector<long long> perm;
    perm.reserve((size_t)n);
    vector<char> seen((size_t)n + 1, 0);
    for (long long i = 0; i < n; ++i) {
        if (!(cin >> token)) {
            cerr << "ERR perm token " << i << "\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
            return 0;
        }
        long long v;
        try {
            size_t p = 0;
            v = stoll(token, &p);
            if (p != token.size()) throw invalid_argument("bad");
        } catch (...) {
            cerr << "ERR perm val " << i << "\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
            return 0;
        }
        if (v < 1 || v > n || seen[(size_t)v]) {
            cerr << "ERR perm range " << i << "\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
            return 0;
        }
        seen[(size_t)v] = 1;
        perm.push_back(v);
    }

    list<long long> seq;
    unordered_map<long long, list<long long>::iterator> pos;
    for (long long v : perm) {
        seq.push_back(v);
        pos[v] = prev(seq.end());
    }

    vector<string> tags;
    bool hasTop = false, hasBottom = false, hasInsert = false, hasAsk = false, hasQuery = false;
    bool hasC4min = false, hasC4max = false, hasC5min = false, hasC5max = false;
    bool hasC6min = false, hasC6max = false;

    long long records = 0;
    for (long long i = 0; i < m; ++i) {
        if (!(cin >> token)) {
            cerr << "ERR op token " << i << "\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
            return 0;
        }
        string op = token;
        if (op == "Top") {
            long long s;
            if (!(cin >> token)) {
                cerr << "ERR top arg " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            try {
                size_t p = 0;
                s = stoll(token, &p);
                if (p != token.size()) throw invalid_argument("bad");
            } catch (...) {
                cerr << "ERR top val " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            if (s < 1 || s > n) {
                cerr << "ERR top range " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            auto it = pos.find(s);
            if (it == pos.end()) {
                cerr << "ERR top missing " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            auto lit = it->second;
            if (lit != seq.begin()) {
                seq.splice(seq.begin(), seq, lit);
            }
            hasTop = true;
            if (s == 1) hasC4min = true;
            if (s == n) hasC4max = true;
            records++;
        } else if (op == "Bottom") {
            long long s;
            if (!(cin >> token)) {
                cerr << "ERR bottom arg " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            try {
                size_t p = 0;
                s = stoll(token, &p);
                if (p != token.size()) throw invalid_argument("bad");
            } catch (...) {
                cerr << "ERR bottom val " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            if (s < 1 || s > n) {
                cerr << "ERR bottom range " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            auto it = pos.find(s);
            if (it == pos.end()) {
                cerr << "ERR bottom missing " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            auto lit = it->second;
            if (next(lit) != seq.end()) {
                seq.splice(seq.end(), seq, lit);
            }
            hasBottom = true;
            if (s == 1) hasC4min = true;
            if (s == n) hasC4max = true;
            records++;
        } else if (op == "Insert") {
            long long s, t;
            if (!(cin >> token)) {
                cerr << "ERR insert s " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            try {
                size_t p = 0;
                s = stoll(token, &p);
                if (p != token.size()) throw invalid_argument("bad");
            } catch (...) {
                cerr << "ERR insert s val " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            if (!(cin >> token)) {
                cerr << "ERR insert t " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            try {
                size_t p = 0;
                t = stoll(token, &p);
                if (p != token.size()) throw invalid_argument("bad");
            } catch (...) {
                cerr << "ERR insert t val " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            if (s < 1 || s > n) {
                cerr << "ERR insert s range " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            if (t < -1 || t > 1) {
                cerr << "ERR insert t range " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            auto it = pos.find(s);
            if (it == pos.end()) {
                cerr << "ERR insert missing " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            auto lit = it->second;
            if (t == -1) {
                if (lit != seq.begin()) {
                    auto target = prev(lit);
                    seq.splice(target, seq, lit);
                }
            } else if (t == 1) {
                auto nxt = next(lit);
                if (nxt != seq.end()) {
                    auto target = next(nxt);
                    seq.splice(target, seq, lit);
                }
            }
            hasInsert = true;
            if (s == 1) hasC4min = true;
            if (s == n) hasC4max = true;
            if (t == -1) hasC6min = true;
            if (t == 1) hasC6max = true;
            if (t == 0) { hasC6min = true; hasC6max = true; }
            records++;
        } else if (op == "Ask") {
            long long s;
            if (!(cin >> token)) {
                cerr << "ERR ask arg " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            try {
                size_t p = 0;
                s = stoll(token, &p);
                if (p != token.size()) throw invalid_argument("bad");
            } catch (...) {
                cerr << "ERR ask val " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            if (s < 1 || s > n) {
                cerr << "ERR ask range " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            if (pos.find(s) == pos.end()) {
                cerr << "ERR ask missing " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            hasAsk = true;
            if (s == 1) hasC4min = true;
            if (s == n) hasC4max = true;
            records++;
        } else if (op == "Query") {
            long long k;
            if (!(cin >> token)) {
                cerr << "ERR query arg " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            try {
                size_t p = 0;
                k = stoll(token, &p);
                if (p != token.size()) throw invalid_argument("bad");
            } catch (...) {
                cerr << "ERR query val " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            if (k < 1 || k > n) {
                cerr << "ERR query range " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            hasQuery = true;
            if (k == 1) hasC5min = true;
            if (k == n) hasC5max = true;
            records++;
        } else {
            cerr << "ERR op unknown " << i << "\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
            return 0;
        }
    }

    if (cin >> token) {
        cerr << "ERR extra token" << "\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
        return 0;
    }

    vector<string> cov;
    if (n == 1 && m == 0) cov.push_back("auto_c1_minimum");
    if (n == 80000) cov.push_back("auto_c1_maximum");
    if (m == 0) cov.push_back("auto_c2_minimum");
    if (m == 80000) cov.push_back("auto_c2_maximum");
    if (hasC4min) cov.push_back("auto_c4_minimum");
    if (hasC4max) cov.push_back("auto_c4_maximum");
    if (hasC5min) cov.push_back("auto_c5_minimum");
    if (hasC5max) cov.push_back("auto_c5_maximum");
    if (hasC6min) cov.push_back("auto_c6_minimum");
    if (hasC6max) cov.push_back("auto_c6_maximum");
    if (hasTop) cov.push_back("auto_operation_top");
    if (hasBottom) cov.push_back("auto_operation_bottom");
    if (hasInsert) cov.push_back("auto_operation_insert");
    if (hasAsk) cov.push_back("auto_operation_ask");
    if (hasQuery) cov.push_back("auto_operation_query");

    cout << "{\"valid\":true,\"dimensions\":{\"n\":" << n << ",\"m\":" << m << "},\"coverage_tags\":[";
    for (size_t i = 0; i < cov.size(); ++i) {
        if (i) cout << ",";
        cout << "\"" << cov[i] << "\"";
    }
    cout << "],\"records\":" << records << "}";
    return 0;
}
