#include <bits/stdc++.h>
using namespace std;

static string esc(const string& s) {
    string r;
    for (char c : s) {
        if (c == '"' || c == '\\') { r += '\\'; r += c; }
        else if (c == '\n') r += "\\n";
        else if (c == '\r') r += "\\r";
        else if (c == '\t') r += "\\t";
        else if ((unsigned char)c < 0x20) {
            char buf[8];
            snprintf(buf, sizeof(buf), "\\u%04x", (unsigned char)c);
            r += buf;
        } else r += c;
    }
    return r;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    long long n, m;
    if (!(cin >> n >> m)) {
        cerr << "ERR_HEADER 0\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
        return 0;
    }
    if (n < 1 || n > 80000 || m < 0 || m > 80000) {
        cerr << "ERR_HEADER_RANGE 0\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
        return 0;
    }

    vector<int> perm((size_t)n);
    vector<bool> seen((size_t)n + 1, false);
    for (int i = 0; i < (int)n; ++i) {
        if (!(cin >> perm[i])) {
            cerr << "ERR_PERM_TOKEN " << i << "\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
            return 0;
        }
        if (perm[i] < 1 || perm[i] > n || seen[perm[i]]) {
            cerr << "ERR_PERM_VALUE " << i << "\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
            return 0;
        }
        seen[perm[i]] = true;
    }

    list<int> seq;
    vector<list<int>::iterator> pos((size_t)n + 1);
    for (int i = 0; i < (int)n; ++i) {
        pos[perm[i]] = seq.insert(seq.end(), perm[i]);
    }

    vector<string> tags;
    bool has_top = false, has_bottom = false, has_insert = false, has_ask = false, has_query = false;
    bool has_c1_min = false, has_c1_max = false, has_c2_min = false, has_c2_max = false;
    bool has_c4_min = false, has_c4_max = false, has_c5_min = false, has_c5_max = false;
    bool has_c6_min = false, has_c6_max = false;

    if (n == 1) has_c1_min = true;
    if (n == 80000) has_c1_max = true;
    if (m == 0) has_c2_min = true;
    if (m == 80000) has_c2_max = true;

    for (long long idx = 0; idx < m; ++idx) {
        string op;
        if (!(cin >> op)) {
            cerr << "ERR_OP_TOKEN " << idx << "\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
            return 0;
        }
        if (op == "Top") {
            long long s;
            if (!(cin >> s)) {
                cerr << "ERR_TOP_ARG " << idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (s < 1 || s > n) {
                cerr << "ERR_TOP_RANGE " << idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (s == 1) has_c4_min = true;
            if (s == n) has_c4_max = true;
            has_top = true;
            auto it = pos[(int)s];
            seq.splice(seq.begin(), seq, it);
        } else if (op == "Bottom") {
            long long s;
            if (!(cin >> s)) {
                cerr << "ERR_BOTTOM_ARG " << idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (s < 1 || s > n) {
                cerr << "ERR_BOTTOM_RANGE " << idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (s == 1) has_c4_min = true;
            if (s == n) has_c4_max = true;
            has_bottom = true;
            auto it = pos[(int)s];
            seq.splice(seq.end(), seq, it);
        } else if (op == "Insert") {
            long long s, t;
            if (!(cin >> s >> t)) {
                cerr << "ERR_INSERT_ARG " << idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (s < 1 || s > n || t < -1 || t > 1) {
                cerr << "ERR_INSERT_RANGE " << idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (s == 1) has_c4_min = true;
            if (s == n) has_c4_max = true;
            if (t == -1) has_c6_min = true;
            if (t == 1) has_c6_max = true;
            if (t == 0) has_c6_min = has_c6_max = true;
            has_insert = true;
            auto it = pos[(int)s];
            if (t == 0) {
                // no-op
            } else if (t == -1) {
                auto prv = prev(it);
                if (it == seq.begin()) {
                    cerr << "ERR_INSERT_LEGAL " << idx << "\n";
                    cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                    return 0;
                }
                seq.splice(prv, seq, it);
            } else { // t == 1
                auto nxt = next(it);
                if (nxt == seq.end()) {
                    cerr << "ERR_INSERT_LEGAL " << idx << "\n";
                    cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                    return 0;
                }
                auto target = next(nxt);
                seq.splice(target, seq, it);
            }
        } else if (op == "Ask") {
            long long s;
            if (!(cin >> s)) {
                cerr << "ERR_ASK_ARG " << idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (s < 1 || s > n) {
                cerr << "ERR_ASK_RANGE " << idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (s == 1) has_c4_min = true;
            if (s == n) has_c4_max = true;
            has_ask = true;
        } else if (op == "Query") {
            long long k;
            if (!(cin >> k)) {
                cerr << "ERR_QUERY_ARG " << idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (k < 1 || k > n) {
                cerr << "ERR_QUERY_RANGE " << idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (k == 1) has_c5_min = true;
            if (k == n) has_c5_max = true;
            has_query = true;
        } else {
            cerr << "ERR_OP_UNKNOWN " << idx << "\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
            return 0;
        }
    }

    string extra;
    if (cin >> extra) {
        cerr << "ERR_EXTRA_TOKEN 0\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
        return 0;
    }

    if (has_top) tags.push_back("auto_operation_top");
    if (has_bottom) tags.push_back("auto_operation_bottom");
    if (has_insert) tags.push_back("auto_operation_insert");
    if (has_ask) tags.push_back("auto_operation_ask");
    if (has_query) tags.push_back("auto_operation_query");
    if (has_c1_min) tags.push_back("auto_c1_minimum");
    if (has_c1_max) tags.push_back("auto_c1_maximum");
    if (has_c2_min) tags.push_back("auto_c2_minimum");
    if (has_c2_max) tags.push_back("auto_c2_maximum");
    if (has_c4_min) tags.push_back("auto_c4_minimum");
    if (has_c4_max) tags.push_back("auto_c4_maximum");
    if (has_c5_min) tags.push_back("auto_c5_minimum");
    if (has_c5_max) tags.push_back("auto_c5_maximum");
    if (has_c6_min) tags.push_back("auto_c6_minimum");
    if (has_c6_max) tags.push_back("auto_c6_maximum");

    cout << "{\"valid\":true,\"dimensions\":{\"n\":" << n << ",\"m\":" << m << "},\"coverage_tags\":[";
    for (size_t i = 0; i < tags.size(); ++i) {
        if (i) cout << ",";
        cout << "\"" << esc(tags[i]) << "\"";
    }
    cout << "],\"records\":" << m << "}\n";
    return 0;
}
