#include <bits/stdc++.h>
using namespace std;

static uint64_t splitmix64(uint64_t x) {
    x += 0x9e3779b97f4a7c15ULL;
    x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ULL;
    x = (x ^ (x >> 27)) * 0x94d049bb133111ebULL;
    return x ^ (x >> 31);
}

static vector<int> make_initial_permutation(int n) {
    vector<int> p(n);
    for (int i = 0; i < n; ++i) p[i] = i + 1;
    return p;
}

static void emit_permutation(const vector<int>& p, ostream& out) {
    for (size_t i = 0; i < p.size(); ++i) {
        if (i) out << ' ';
        out << p[i];
    }
    out << '\n';
}

void acm_generate_case(unsigned long long seed, const string& profile, const string& case_kind, ostream& out) {
    if (profile == "small" && case_kind == "lower_bound") {
        out << "1 0\n";
        out << "1\n";
        return;
    }
    if (profile == "small" && case_kind == "random") {
        // Fixed legal skeleton: n=5, m=8, initial 1 2 3 4 5.
        // Operations: Top 3, Bottom 1, Insert 2 1, Insert 4 -1, Insert 5 0,
        //             Ask 3, Query 2, Ask 1.
        // Seed changes only the read-only Query argument (and Ask argument).
        uint64_t rng = splitmix64(seed);
        int n = 5, m = 8;
        out << n << ' ' << m << '\n';
        out << "1 2 3 4 5\n";

        // Simulate to keep legality (though skeleton is already legal).
        vector<int> cur = {1, 2, 3, 4, 5};

        auto find_pos = [&](int val) -> int {
            for (int i = 0; i < (int)cur.size(); ++i)
                if (cur[i] == val) return i;
            return -1;
        };

        // Op 1: Top 3
        {
            int s = 3;
            int pos = find_pos(s);
            cur.erase(cur.begin() + pos);
            cur.insert(cur.begin(), s);
            out << "Top " << s << '\n';
        }
        // Op 2: Bottom 1
        {
            int s = 1;
            int pos = find_pos(s);
            cur.erase(cur.begin() + pos);
            cur.push_back(s);
            out << "Bottom " << s << '\n';
        }
        // Op 3: Insert 2 1
        {
            int s = 2, t = 1;
            int pos = find_pos(s);
            cur.erase(cur.begin() + pos);
            int newpos = pos + t;
            if (newpos < 0) newpos = 0;
            if (newpos > (int)cur.size()) newpos = (int)cur.size();
            cur.insert(cur.begin() + newpos, s);
            out << "Insert " << s << ' ' << t << '\n';
        }
        // Op 4: Insert 4 -1
        {
            int s = 4, t = -1;
            int pos = find_pos(s);
            cur.erase(cur.begin() + pos);
            int newpos = pos + t;
            if (newpos < 0) newpos = 0;
            if (newpos > (int)cur.size()) newpos = (int)cur.size();
            cur.insert(cur.begin() + newpos, s);
            out << "Insert " << s << ' ' << t << '\n';
        }
        // Op 5: Insert 5 0
        {
            int s = 5, t = 0;
            int pos = find_pos(s);
            cur.erase(cur.begin() + pos);
            int newpos = pos + t;
            if (newpos < 0) newpos = 0;
            if (newpos > (int)cur.size()) newpos = (int)cur.size();
            cur.insert(cur.begin() + newpos, s);
            out << "Insert " << s << ' ' << t << '\n';
        }
        // Op 6: Ask 3 (read-only; seed may change this argument)
        {
            int s = 3;
            // Seed may change s to any 1..n; keep it legal.
            int ask_arg = (int)(rng % n) + 1;
            // But skeleton says Ask 3; we can vary it safely since Ask is read-only.
            // To preserve skeleton, use 3 unless seed forces otherwise? The rule says
            // seed must change at least one safe field. We'll use seed for Ask arg.
            // However the skeleton explicitly lists Ask 3. The blueprint says
            // "Assign at least one actually emitted argument in one of those families
            //  from the consumed PRNG." Top and Query are safe families. Ask is also
            // read-only. We'll vary the Ask argument.
            out << "Ask " << ask_arg << '\n';
            // No state change.
        }
        // Op 7: Query 2 (read-only; seed may change this argument)
        {
            int k = (int)(rng % n) + 1;
            out << "Query " << k << '\n';
        }
        // Op 8: Ask 1 (read-only; seed may change this argument)
        {
            int s = (int)(rng % n) + 1;
            out << "Ask " << s << '\n';
        }
        return;
    }
    if (profile == "large" && case_kind == "upper_bound") {
        int n = 80000, m = 80000;
        out << n << ' ' << m << '\n';
        for (int i = 1; i <= n; ++i) {
            if (i > 1) out << ' ';
            out << i;
        }
        out << '\n';
        for (int i = 0; i < m; ++i) {
            out << "Top 1\n";
        }
        return;
    }
    if (profile == "large" && case_kind == "random") {
        // n=80000, m=80000. Initial 1..n.
        // Operations: 40000 Top 1 (no-op), 40000 Query 1.
        // Seed changes only the Query argument (read-only).
        uint64_t rng = splitmix64(seed);
        int n = 80000, m = 80000;
        out << n << ' ' << m << '\n';
        for (int i = 1; i <= n; ++i) {
            if (i > 1) out << ' ';
            out << i;
        }
        out << '\n';
        int top_count = 40000;
        int query_count = 40000;
        for (int i = 0; i < m; ++i) {
            if (top_count > 0) {
                out << "Top 1\n";
                --top_count;
            } else {
                int k = (int)(rng % n) + 1;
                out << "Query " << k << '\n';
                --query_count;
            }
        }
        return;
    }
    // Should not reach here; but emit a minimal valid case to avoid UB.
    out << "1 0\n1\n";
}
