#include <algorithm>
#include <cstdint>
#include <ostream>
#include <random>
#include <string>
#include <vector>

namespace {

void emit_small_lower_bound(std::ostream& out) {
    out << "1 0\n";
    out << "1\n";
}

void emit_small_random(std::ostream& out, unsigned long long seed) {
    std::mt19937_64 rng(seed);
    int n = 5;
    int m = 8;
    out << n << ' ' << m << '\n';
    out << "1 2 3 4 5\n";

    // Fixed legal skeleton from the blueprint.
    // Top 3, Bottom 1, Insert 2 -1, Insert 4 1, Insert 5 0,
    // Ask 2, Query 3, Top 5.
    // We keep all state-changing ops fixed; seed only changes
    // the read-only Ask/Query arguments.
    std::vector<int> seq = {1, 2, 3, 4, 5};

    auto find_pos = [&](int val) -> int {
        for (int i = 0; i < (int)seq.size(); ++i) {
            if (seq[i] == val) return i;
        }
        return -1;
    };

    // Op 1: Top 3
    {
        int s = 3;
        int p = find_pos(s);
        seq.erase(seq.begin() + p);
        seq.insert(seq.begin(), s);
        out << "Top " << s << '\n';
    }
    // Op 2: Bottom 1
    {
        int s = 1;
        int p = find_pos(s);
        seq.erase(seq.begin() + p);
        seq.push_back(s);
        out << "Bottom " << s << '\n';
    }
    // Op 3: Insert 2 -1
    {
        int s = 2;
        int t = -1;
        int p = find_pos(s);
        seq.erase(seq.begin() + p);
        int np = p + t;
        if (np < 0) np = 0;
        if (np > (int)seq.size()) np = (int)seq.size();
        seq.insert(seq.begin() + np, s);
        out << "Insert " << s << ' ' << t << '\n';
    }
    // Op 4: Insert 4 1
    {
        int s = 4;
        int t = 1;
        int p = find_pos(s);
        seq.erase(seq.begin() + p);
        int np = p + t;
        if (np < 0) np = 0;
        if (np > (int)seq.size()) np = (int)seq.size();
        seq.insert(seq.begin() + np, s);
        out << "Insert " << s << ' ' << t << '\n';
    }
    // Op 5: Insert 5 0
    {
        int s = 5;
        int t = 0;
        int p = find_pos(s);
        seq.erase(seq.begin() + p);
        int np = p + t;
        if (np < 0) np = 0;
        if (np > (int)seq.size()) np = (int)seq.size();
        seq.insert(seq.begin() + np, s);
        out << "Insert " << s << ' ' << t << '\n';
    }
    // Op 6: Ask (seed-dependent argument)
    {
        int s = (int)(rng() % n) + 1;
        out << "Ask " << s << '\n';
    }
    // Op 7: Query (seed-dependent argument)
    {
        int k = (int)(rng() % n) + 1;
        out << "Query " << k << '\n';
    }
    // Op 8: Top 5
    {
        int s = 5;
        int p = find_pos(s);
        seq.erase(seq.begin() + p);
        seq.insert(seq.begin(), s);
        out << "Top " << s << '\n';
    }
}

void emit_large_upper_bound(std::ostream& out) {
    int n = 80000;
    int m = 80000;
    out << n << ' ' << m << '\n';
    for (int i = 1; i <= n; ++i) {
        if (i > 1) out << ' ';
        out << i;
    }
    out << '\n';
    for (int i = 0; i < m; ++i) {
        out << "Query 1\n";
    }
}

void emit_large_random(std::ostream& out, unsigned long long seed) {
    std::mt19937_64 rng(seed);
    int n = 80000;
    int m = 80000;
    out << n << ' ' << m << '\n';
    for (int i = 1; i <= n; ++i) {
        if (i > 1) out << ' ';
        out << i;
    }
    out << '\n';
    for (int i = 0; i < m; ++i) {
        // Only read-only operations: Ask and Query.
        // Seed decides which family and the argument.
        if ((rng() & 1ULL) == 0) {
            int s = (int)(rng() % n) + 1;
            out << "Ask " << s << '\n';
        } else {
            int k = (int)(rng() % n) + 1;
            out << "Query " << k << '\n';
        }
    }
}

}  // namespace

void acm_generate_case(unsigned long long seed,
                       const std::string& profile,
                       const std::string& case_kind,
                       std::ostream& out) {
    if (profile == "small" && case_kind == "lower_bound") {
        emit_small_lower_bound(out);
    } else if (profile == "small" && case_kind == "random") {
        emit_small_random(out, seed);
    } else if (profile == "large" && case_kind == "upper_bound") {
        emit_large_upper_bound(out);
    } else if (profile == "large" && case_kind == "random") {
        emit_large_random(out, seed);
    }
}
