#include <bits/stdc++.h>
using namespace std;

static string esc(long long x) { return to_string(x); }

static string esc_str(const string& s) {
    string r;
    for (char c : s) {
        if (c == '"' || c == '\\') { r += '\\'; r += c; }
        else if (c == '\n') { r += "\\n"; }
        else if (c == '\r') { r += "\\r"; }
        else if (c == '\t') { r += "\\t"; }
        else if ((unsigned char)c < 0x20) {
            char buf[8];
            snprintf(buf, sizeof(buf), "\\u%04x", (unsigned char)c);
            r += buf;
        } else r += c;
    }
    return r;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    long long n, m;
    if (!(cin >> n >> m)) {
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
        return 0;
    }
    if (n < 1 || n > 80000 || m < 0 || m > 80000) {
        cerr << "ERR_HEADER_RANGE 0\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
        return 0;
    }

    vector<int> perm(n);
    vector<int> pos(n + 1);
    vector<bool> seen(n + 1, false);
    for (int i = 0; i < n; ++i) {
        int x;
        if (!(cin >> x)) {
            cerr << "ERR_PERM_TOKEN " << i << "\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
            return 0;
        }
        if (x < 1 || x > n || seen[x]) {
            cerr << "ERR_PERM_VALUE " << i << "\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
            return 0;
        }
        seen[x] = true;
        perm[i] = x;
        pos[x] = i;
    }

    list<int> seq(perm.begin(), perm.end());
    vector<list<int>::iterator> it(n + 1);
    {
        auto itl = seq.begin();
        for (int i = 0; i < n; ++i, ++itl) it[perm[i]] = itl;
    }

    set<string> tags;
    bool has_top = false, has_bottom = false, has_insert = false, has_ask = false, has_query = false;
    bool has_c1_min = false, has_c1_max = false, has_c2_min = false, has_c2_max = false;
    bool has_c4_min = false, has_c4_max = false, has_c5_min = false, has_c5_max = false;
    bool has_c6_min = false, has_c6_max = false;

    if (n == 1) has_c1_min = true;
    if (n == 80000) has_c1_max = true;
    if (m == 0) has_c2_min = true;
    if (m == 80000) has_c2_max = true;

    long long records = 0;
    for (long long op_idx = 0; op_idx < m; ++op_idx) {
        string op;
        if (!(cin >> op)) {
            cerr << "ERR_OP_TOKEN " << op_idx << "\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
            return 0;
        }
        if (op == "Top") {
            int s;
            if (!(cin >> s)) {
                cerr << "ERR_OP_ARG " << op_idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            if (s < 1 || s > n) {
                cerr << "ERR_ARG_RANGE " << op_idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            if (s == 1) has_c4_min = true;
            if (s == n) has_c4_max = true;
            has_top = true;
            auto cur = it[s];
            if (cur != seq.begin()) {
                seq.splice(seq.begin(), seq, cur);
            }
        } else if (op == "Bottom") {
            int s;
            if (!(cin >> s)) {
                cerr << "ERR_OP_ARG " << op_idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            if (s < 1 || s > n) {
                cerr << "ERR_ARG_RANGE " << op_idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            if (s == 1) has_c4_min = true;
            if (s == n) has_c4_max = true;
            has_bottom = true;
            auto cur = it[s];
            auto last = seq.end();
            --last;
            if (cur != last) {
                seq.splice(seq.end(), seq, cur);
            }
        } else if (op == "Insert") {
            int s, t;
            if (!(cin >> s >> t)) {
                cerr << "ERR_OP_ARG " << op_idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            if (s < 1 || s > n || t < -1 || t > 1) {
                cerr << "ERR_ARG_RANGE " << op_idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            if (t == -1) has_c6_min = true;
            if (t == 1) has_c6_max = true;
            if (t == 0) has_c6_min = has_c6_max = true;
            if (s == 1) has_c4_min = true;
            if (s == n) has_c4_max = true;
            has_insert = true;
            auto cur = it[s];
            if (t == -1) {
                if (cur != seq.begin()) {
                    auto prev_it = prev(cur);
                    seq.splice(prev_it, seq, cur);
                }
            } else if (t == 1) {
                auto nxt = next(cur);
                if (nxt != seq.end()) {
                    auto target = next(nxt);
                    seq.splice(target, seq, cur);
                }
            }
        } else if (op == "Ask") {
            int s;
            if (!(cin >> s)) {
                cerr << "ERR_OP_ARG " << op_idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            if (s < 1 || s > n) {
                cerr << "ERR_ARG_RANGE " << op_idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            if (s == 1) has_c4_min = true;
            if (s == n) has_c4_max = true;
            has_ask = true;
        } else if (op == "Query") {
            int k;
            if (!(cin >> k)) {
                cerr << "ERR_OP_ARG " << op_idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            if (k < 1 || k > n) {
                cerr << "ERR_ARG_RANGE " << op_idx << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            if (k == 1) has_c5_min = true;
            if (k == n) has_c5_max = true;
            has_query = true;
        } else {
            cerr << "ERR_OP_NAME " << op_idx << "\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
            return 0;
        }
        ++records;
    }

    string extra;
    if (!(cin >> extra)) {
        // ok
    } else {
        cerr << "ERR_TRAILING " << m << "\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
        return 0;
    }

    if (has_top) tags.insert("auto_operation_top");
    if (has_bottom) tags.insert("auto_operation_bottom");
    if (has_insert) tags.insert("auto_operation_insert");
    if (has_ask) tags.insert("auto_operation_ask");
    if (has_query) tags.insert("auto_operation_query");
    if (has_c1_min) tags.insert("auto_c1_minimum");
    if (has_c1_max) tags.insert("auto_c1_maximum");
    if (has_c2_min) tags.insert("auto_c2_minimum");
    if (has_c2_max) tags.insert("auto_c2_maximum");
    if (has_c4_min) tags.insert("auto_c4_minimum");
    if (has_c4_max) tags.insert("auto_c4_maximum");
    if (has_c5_min) tags.insert("auto_c5_minimum");
    if (has_c5_max) tags.insert("auto_c5_maximum");
    if (has_c6_min) tags.insert("auto_c6_minimum");
    if (has_c6_max) tags.insert("auto_c6_maximum");

    string tags_json = "[";
    bool first = true;
    for (const auto& t : tags) {
        if (!first) tags_json += ",";
        tags_json += "\"" + esc_str(t) + "\"";
        first = false;
    }
    tags_json += "]";

    cout << "{\"valid\":true,\"dimensions\":{\"n\":" << n << ",\"m\":" << m << "},\"coverage_tags\":" << tags_json << ",\"records\":" << records << "}";
    return 0;
}
