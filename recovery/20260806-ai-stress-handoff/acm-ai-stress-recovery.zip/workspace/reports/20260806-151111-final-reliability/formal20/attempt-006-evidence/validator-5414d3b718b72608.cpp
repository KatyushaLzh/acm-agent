#include <bits/stdc++.h>
using namespace std;

struct Op {
    string type;
    long long a, b;
};

static string esc(long long x) {
    return to_string(x);
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    string line;
    if (!getline(cin, line)) {
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
        return 0;
    }
    stringstream ss(line);
    long long n, m;
    if (!(ss >> n >> m)) {
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
        return 0;
    }
    if (n < 1 || n > 80000 || m < 0 || m > 80000) {
        cerr << "ERR_HEADER 0\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
        return 0;
    }

    vector<long long> perm;
    perm.reserve((size_t)n);
    for (long long i = 0; i < n; ++i) {
        long long x;
        if (!(cin >> x)) {
            cerr << "ERR_PERM " << i << "\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
            return 0;
        }
        if (x < 1 || x > n) {
            cerr << "ERR_PERM_VAL " << i << "\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
            return 0;
        }
        perm.push_back(x);
    }
    vector<char> seen((size_t)n + 1, 0);
    for (long long x : perm) {
        if (seen[(size_t)x]) {
            cerr << "ERR_PERM_DUP 0\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
            return 0;
        }
        seen[(size_t)x] = 1;
    }

    vector<Op> ops;
    ops.reserve((size_t)m);
    for (long long i = 0; i < m; ++i) {
        string t;
        if (!(cin >> t)) {
            cerr << "ERR_OP " << i << "\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
            return 0;
        }
        Op op;
        op.type = t;
        if (t == "Top" || t == "Bottom" || t == "Ask") {
            long long s;
            if (!(cin >> s)) {
                cerr << "ERR_OP_ARG " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            op.a = s;
            op.b = 0;
        } else if (t == "Insert") {
            long long s, tt;
            if (!(cin >> s >> tt)) {
                cerr << "ERR_OP_ARG " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            op.a = s;
            op.b = tt;
        } else if (t == "Query") {
            long long k;
            if (!(cin >> k)) {
                cerr << "ERR_OP_ARG " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            op.a = k;
            op.b = 0;
        } else {
            cerr << "ERR_OP_TYPE " << i << "\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
            return 0;
        }
        ops.push_back(op);
    }

    string extra;
    if (cin >> extra) {
        cerr << "ERR_EXTRA 0\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
        return 0;
    }

    // validate op args
    for (long long i = 0; i < m; ++i) {
        const Op& op = ops[(size_t)i];
        if (op.type == "Top" || op.type == "Bottom" || op.type == "Ask") {
            if (op.a < 1 || op.a > n) {
                cerr << "ERR_ARG " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
        } else if (op.type == "Insert") {
            if (op.a < 1 || op.a > n || op.b < -1 || op.b > 1) {
                cerr << "ERR_ARG " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
        } else if (op.type == "Query") {
            if (op.a < 1 || op.a > n) {
                cerr << "ERR_ARG " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
        }
    }

    // dynamic legality simulation
    list<long long> L(perm.begin(), perm.end());
    unordered_map<long long, list<long long>::iterator> pos;
    {
        auto it = L.begin();
        for (long long x : perm) {
            pos[x] = it;
            ++it;
        }
    }

    for (long long i = 0; i < m; ++i) {
        const Op& op = ops[(size_t)i];
        if (op.type == "Top") {
            auto it = pos[op.a];
            L.splice(L.begin(), L, it);
        } else if (op.type == "Bottom") {
            auto it = pos[op.a];
            L.splice(L.end(), L, it);
        } else if (op.type == "Insert") {
            auto it = pos[op.a];
            if (op.b == -1) {
                if (it == L.begin()) {
                    cerr << "ERR_ILLEGAL " << i << "\n";
                    cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                    return 0;
                }
                auto target = prev(it);
                L.splice(target, L, it);
            } else if (op.b == 1) {
                auto nxt = next(it);
                if (nxt == L.end()) {
                    cerr << "ERR_ILLEGAL " << i << "\n";
                    cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                    return 0;
                }
                auto target = next(nxt);
                L.splice(target, L, it);
            }
            // t == 0: no move
        } else if (op.type == "Ask" || op.type == "Query") {
            // only boundary checked already
        }
    }

    // coverage tags
    vector<string> tags;
    if (n == 1 && m == 0) tags.push_back("auto_c1_minimum");
    if (n == 80000 && m == 80000) tags.push_back("auto_c1_maximum");
    if (m == 0) tags.push_back("auto_c2_minimum");
    if (m == 80000) tags.push_back("auto_c2_maximum");
    if (n == 1) tags.push_back("auto_c4_minimum");
    if (n == 80000) tags.push_back("auto_c4_maximum");
    if (m == 0) tags.push_back("auto_c5_minimum");
    if (m == 80000) tags.push_back("auto_c5_maximum");
    if (n == 1) tags.push_back("auto_c6_minimum");
    if (n == 80000) tags.push_back("auto_c6_maximum");

    bool hasTop=false, hasBottom=false, hasInsert=false, hasAsk=false, hasQuery=false;
    for (const Op& op : ops) {
        if (op.type == "Top") hasTop = true;
        else if (op.type == "Bottom") hasBottom = true;
        else if (op.type == "Insert") hasInsert = true;
        else if (op.type == "Ask") hasAsk = true;
        else if (op.type == "Query") hasQuery = true;
    }
    if (hasTop) tags.push_back("auto_operation_top");
    if (hasBottom) tags.push_back("auto_operation_bottom");
    if (hasInsert) tags.push_back("auto_operation_insert");
    if (hasAsk) tags.push_back("auto_operation_ask");
    if (hasQuery) tags.push_back("auto_operation_query");

    // deduplicate tags
    sort(tags.begin(), tags.end());
    tags.erase(unique(tags.begin(), tags.end()), tags.end());

    cout << "{\"valid\":true,\"dimensions\":{\"n\":" << n << ",\"m\":" << m << "},\"coverage_tags\":[";
    for (size_t i = 0; i < tags.size(); ++i) {
        if (i) cout << ",";
        cout << "\"" << tags[i] << "\"";
    }
    cout << "],\"records\":" << m << "}\n";
    return 0;
}
