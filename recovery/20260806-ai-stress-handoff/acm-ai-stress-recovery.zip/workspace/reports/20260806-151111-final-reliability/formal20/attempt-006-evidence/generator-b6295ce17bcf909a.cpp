#include <algorithm>
#include <cstdint>
#include <ostream>
#include <random>
#include <string>
#include <vector>

static void emit_small_lower_bound(std::ostream& out) {
    out << "1 0\n";
    out << "1\n";
}

static void emit_small_random(unsigned long long seed, std::ostream& out) {
    std::mt19937_64 rng(seed);
    int n = 5;
    int m = 8;
    out << n << ' ' << m << '\n';
    out << "1 2 3 4 5\n";

    // Fixed legal skeleton from the blueprint.
    // Top 3, Bottom 1, Insert 2 -1, Insert 4 1, Insert 5 0, Ask 3, Query 2, Top 5.
    // We keep this exact sequence. The seed only changes the Query argument
    // (a read-only operation) to a value in 1..n.
    int query_k = 1 + static_cast<int>(rng() % static_cast<unsigned long long>(n));

    out << "Top 3\n";
    out << "Bottom 1\n";
    out << "Insert 2 -1\n";
    out << "Insert 4 1\n";
    out << "Insert 5 0\n";
    out << "Ask 3\n";
    out << "Query " << query_k << '\n';
    out << "Top 5\n";
}

static void emit_large_upper_bound(std::ostream& out) {
    int n = 80000;
    int m = 80000;
    out << n << ' ' << m << '\n';
    for (int i = 1; i <= n; ++i) {
        if (i > 1) out << ' ';
        out << i;
    }
    out << '\n';
    // 40000 Top operations on distinct books.
    for (int i = 1; i <= 40000; ++i) {
        out << "Top " << i << '\n';
    }
    // 40000 Query operations with k=1.
    for (int i = 0; i < 40000; ++i) {
        out << "Query 1\n";
    }
}

static void emit_large_random(unsigned long long seed, std::ostream& out) {
    std::mt19937_64 rng(seed);
    int n = 80000;
    int m = 80000;
    out << n << ' ' << m << '\n';
    for (int i = 1; i <= n; ++i) {
        if (i > 1) out << ' ';
        out << i;
    }
    out << '\n';

    // 40000 Top operations on distinct books (fixed skeleton).
    for (int i = 1; i <= 40000; ++i) {
        out << "Top " << i << '\n';
    }

    // 40000 Query operations. The seed changes the k argument
    // (read-only, unconditionally legal) for each query.
    for (int i = 0; i < 40000; ++i) {
        int k = 1 + static_cast<int>(rng() % static_cast<unsigned long long>(n));
        out << "Query " << k << '\n';
    }
}

void acm_generate_case(unsigned long long seed,
                       const std::string& profile,
                       const std::string& case_kind,
                       std::ostream& out) {
    if (profile == "small" && case_kind == "lower_bound") {
        emit_small_lower_bound(out);
    } else if (profile == "small" && case_kind == "random") {
        emit_small_random(seed, out);
    } else if (profile == "large" && case_kind == "upper_bound") {
        emit_large_upper_bound(out);
    } else if (profile == "large" && case_kind == "random") {
        emit_large_random(seed, out);
    }
}
