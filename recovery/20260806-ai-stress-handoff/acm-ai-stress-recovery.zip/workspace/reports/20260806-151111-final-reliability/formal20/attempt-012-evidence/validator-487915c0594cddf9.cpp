#include <bits/stdc++.h>
using namespace std;

static string esc(const string& s) {
    string r;
    for (char c : s) {
        if (c == '"' || c == '\\') { r += '\\'; r += c; }
        else if (c == '\n') { r += "\\n"; }
        else if (c == '\r') { r += "\\r"; }
        else if (c == '\t') { r += "\\t"; }
        else if (static_cast<unsigned char>(c) < 0x20) {
            char buf[8];
            snprintf(buf, sizeof(buf), "\\u%04x", c);
            r += buf;
        } else r += c;
    }
    return r;
}

static void fail(const string& msg, int idx) {
    cerr << "ERR " << msg << " " << idx << "\n";
    cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
    exit(0);
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    long long n, m;
    if (!(cin >> n >> m)) fail("header", 0);
    if (n < 1 || n > 80000) fail("n_range", 0);
    if (m < 0 || m > 80000) fail("m_range", 0);

    vector<int> perm;
    perm.reserve((size_t)n);
    vector<bool> seen((size_t)n + 1, false);
    for (long long i = 0; i < n; ++i) {
        long long x;
        if (!(cin >> x)) fail("perm", (int)i);
        if (x < 1 || x > n) fail("perm_val", (int)i);
        if (seen[(size_t)x]) fail("perm_dup", (int)i);
        seen[(size_t)x] = true;
        perm.push_back((int)x);
    }

    vector<string> tags;
    bool has_top = false, has_bottom = false, has_insert = false, has_ask = false, has_query = false;
    bool has_c1_min = false, has_c1_max = false, has_c2_min = false, has_c2_max = false;
    bool has_c4_min = false, has_c4_max = false, has_c5_min = false, has_c5_max = false;
    bool has_c6_min = false, has_c6_max = false;

    if (n == 1) has_c1_min = true;
    if (n == 80000) has_c1_max = true;
    if (m == 0) has_c2_min = true;
    if (m == 80000) has_c2_max = true;

    for (long long op_idx = 0; op_idx < m; ++op_idx) {
        string op;
        if (!(cin >> op)) fail("op", (int)op_idx);
        if (op == "Top") {
            long long s;
            if (!(cin >> s)) fail("top_s", (int)op_idx);
            if (s < 1 || s > n) fail("top_range", (int)op_idx);
            if (s == 1) has_c4_min = true;
            if (s == n) has_c4_max = true;
            has_top = true;
        } else if (op == "Bottom") {
            long long s;
            if (!(cin >> s)) fail("bottom_s", (int)op_idx);
            if (s < 1 || s > n) fail("bottom_range", (int)op_idx);
            if (s == 1) has_c4_min = true;
            if (s == n) has_c4_max = true;
            has_bottom = true;
        } else if (op == "Insert") {
            long long s, t;
            if (!(cin >> s >> t)) fail("insert_st", (int)op_idx);
            if (s < 1 || s > n) fail("insert_s_range", (int)op_idx);
            if (t < -1 || t > 1) fail("insert_t_range", (int)op_idx);
            if (s == 1) has_c4_min = true;
            if (s == n) has_c4_max = true;
            if (t == -1) has_c6_min = true;
            if (t == 1) has_c6_max = true;
            has_insert = true;
        } else if (op == "Ask") {
            long long s;
            if (!(cin >> s)) fail("ask_s", (int)op_idx);
            if (s < 1 || s > n) fail("ask_range", (int)op_idx);
            if (s == 1) has_c4_min = true;
            if (s == n) has_c4_max = true;
            has_ask = true;
        } else if (op == "Query") {
            long long k;
            if (!(cin >> k)) fail("query_k", (int)op_idx);
            if (k < 1 || k > n) fail("query_range", (int)op_idx);
            if (k == 1) has_c5_min = true;
            if (k == n) has_c5_max = true;
            has_query = true;
        } else {
            fail("op_unknown", (int)op_idx);
        }
    }

    string extra;
    if (cin >> extra) fail("trailing", (int)m);

    if (has_top) tags.push_back("auto_operation_top");
    if (has_bottom) tags.push_back("auto_operation_bottom");
    if (has_insert) tags.push_back("auto_operation_insert");
    if (has_ask) tags.push_back("auto_operation_ask");
    if (has_query) tags.push_back("auto_operation_query");
    if (has_c1_min) tags.push_back("auto_c1_minimum");
    if (has_c1_max) tags.push_back("auto_c1_maximum");
    if (has_c2_min) tags.push_back("auto_c2_minimum");
    if (has_c2_max) tags.push_back("auto_c2_maximum");
    if (has_c4_min) tags.push_back("auto_c4_minimum");
    if (has_c4_max) tags.push_back("auto_c4_maximum");
    if (has_c5_min) tags.push_back("auto_c5_minimum");
    if (has_c5_max) tags.push_back("auto_c5_maximum");
    if (has_c6_min) tags.push_back("auto_c6_minimum");
    if (has_c6_max) tags.push_back("auto_c6_maximum");

    cout << "{\"valid\":true,\"dimensions\":{";
    cout << "\"n\":" << n << ",\"m\":" << m;
    cout << "},\"coverage_tags\":[";
    for (size_t i = 0; i < tags.size(); ++i) {
        if (i) cout << ",";
        cout << "\"" << esc(tags[i]) << "\"";
    }
    cout << "],\"records\":" << m << "}\n";
    return 0;
}
