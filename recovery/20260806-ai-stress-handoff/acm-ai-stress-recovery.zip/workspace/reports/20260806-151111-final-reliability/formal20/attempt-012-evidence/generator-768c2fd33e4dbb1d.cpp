#include <algorithm>
#include <cstdint>
#include <iostream>
#include <numeric>
#include <random>
#include <string>
#include <vector>

void acm_generate_case(unsigned long long seed, const std::string& profile,
                       const std::string& case_kind, std::ostream& out) {
    if (profile == "small" && case_kind == "lower_bound") {
        out << "1 0\n";
        out << "1\n";
        return;
    }

    if (profile == "small" && case_kind == "random") {
        std::mt19937_64 rng(seed);
        int n = 5;
        int m = 8;
        out << n << " " << m << "\n";
        out << "1 2 3 4 5\n";

        std::vector<int> state = {1, 2, 3, 4, 5};

        auto find_pos = [&](int val) -> int {
            for (int i = 0; i < (int)state.size(); ++i) {
                if (state[i] == val) return i;
            }
            return -1;
        };

        auto erase_at = [&](int idx) {
            state.erase(state.begin() + idx);
        };

        auto insert_at = [&](int idx, int val) {
            state.insert(state.begin() + idx, val);
        };

        auto do_top = [&](int s) {
            int pos = find_pos(s);
            erase_at(pos);
            insert_at(0, s);
        };

        auto do_bottom = [&](int s) {
            int pos = find_pos(s);
            erase_at(pos);
            state.push_back(s);
        };

        auto do_insert = [&](int s, int t) {
            int pos = find_pos(s);
            erase_at(pos);
            int new_pos = pos + t;
            if (new_pos < 0) new_pos = 0;
            if (new_pos > (int)state.size()) new_pos = (int)state.size();
            insert_at(new_pos, s);
        };

        auto do_ask = [&](int s) -> int {
            return find_pos(s) + 1;
        };

        auto do_query = [&](int k) -> int {
            return state[k - 1];
        };

        struct Op {
            std::string name;
            int a;
            int b;
        };

        std::vector<Op> ops;
        ops.push_back({"Top", 3, 0});
        ops.push_back({"Bottom", 1, 0});
        ops.push_back({"Insert", 4, -1});
        ops.push_back({"Insert", 2, 0});
        ops.push_back({"Insert", 5, 1});
        ops.push_back({"Ask", 3, 0});
        ops.push_back({"Query", 2, 0});
        ops.push_back({"Ask", 1, 0});

        for (auto& op : ops) {
            if (op.name == "Top") {
                do_top(op.a);
            } else if (op.name == "Bottom") {
                do_bottom(op.a);
            } else if (op.name == "Insert") {
                do_insert(op.a, op.b);
            } else if (op.name == "Ask") {
                do_ask(op.a);
            } else if (op.name == "Query") {
                do_query(op.a);
            }
        }

        // Now emit the operations, but let the seed affect the last Ask argument.
        // The last operation is Ask 1; we can change it to Ask (1 + rng()%5) safely.
        int last_ask_arg = 1 + (int)(rng() % 5);
        ops[7].a = last_ask_arg;

        for (const auto& op : ops) {
            if (op.name == "Top") {
                out << "Top " << op.a << "\n";
            } else if (op.name == "Bottom") {
                out << "Bottom " << op.a << "\n";
            } else if (op.name == "Insert") {
                out << "Insert " << op.a << " " << op.b << "\n";
            } else if (op.name == "Ask") {
                out << "Ask " << op.a << "\n";
            } else if (op.name == "Query") {
                out << "Query " << op.a << "\n";
            }
        }
        return;
    }

    if (profile == "large" && case_kind == "upper_bound") {
        int n = 80000;
        int m = 80000;
        out << n << " " << m << "\n";
        for (int i = 1; i <= n; ++i) {
            if (i > 1) out << " ";
            out << i;
        }
        out << "\n";
        for (int i = 0; i < m; ++i) {
            out << "Query 1\n";
        }
        return;
    }

    if (profile == "large" && case_kind == "random") {
        std::mt19937_64 rng(seed);
        int n = 80000;
        int m = 80000;
        out << n << " " << m << "\n";
        for (int i = 1; i <= n; ++i) {
            if (i > 1) out << " ";
            out << i;
        }
        out << "\n";
        for (int i = 0; i < 40000; ++i) {
            out << "Top 1\n";
        }
        for (int i = 0; i < 40000; ++i) {
            int q = 1 + (int)(rng() % n);
            out << "Query " << q << "\n";
        }
        return;
    }
}
