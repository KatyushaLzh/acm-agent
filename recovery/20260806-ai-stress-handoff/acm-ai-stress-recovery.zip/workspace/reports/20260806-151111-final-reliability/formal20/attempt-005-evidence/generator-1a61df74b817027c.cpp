#include <algorithm>
#include <cstdint>
#include <iostream>
#include <numeric>
#include <random>
#include <string>
#include <vector>

void acm_generate_case(unsigned long long seed, const std::string& profile,
                       const std::string& case_kind, std::ostream& out) {
    if (profile == "small" && case_kind == "lower_bound") {
        out << "1 0\n";
        out << "1\n";
        return;
    }

    if (profile == "small" && case_kind == "random") {
        std::mt19937_64 rng(seed);
        int n = 5;
        int m = 8;
        out << n << " " << m << "\n";
        out << "1 2 3 4 5\n";

        std::vector<int> state = {1, 2, 3, 4, 5};

        auto find_pos = [&](int book) -> int {
            for (int i = 0; i < (int)state.size(); ++i) {
                if (state[i] == book) return i;
            }
            return -1;
        };

        auto erase_at = [&](int pos) {
            state.erase(state.begin() + pos);
        };

        auto insert_at = [&](int pos, int book) {
            state.insert(state.begin() + pos, book);
        };

        // Fixed legal skeleton from the blueprint.
        // Top 3
        {
            int book = 3;
            int pos = find_pos(book);
            erase_at(pos);
            insert_at(0, book);
            out << "Top " << book << "\n";
        }
        // Bottom 1
        {
            int book = 1;
            int pos = find_pos(book);
            erase_at(pos);
            insert_at((int)state.size(), book);
            out << "Bottom " << book << "\n";
        }
        // Insert 2 -1
        {
            int book = 2;
            int pos = find_pos(book);
            int new_pos = pos - 1;
            erase_at(pos);
            insert_at(new_pos, book);
            out << "Insert " << book << " -1\n";
        }
        // Insert 4 1
        {
            int book = 4;
            int pos = find_pos(book);
            int new_pos = pos + 1;
            erase_at(pos);
            insert_at(new_pos, book);
            out << "Insert " << book << " 1\n";
        }
        // Insert 5 0
        {
            int book = 5;
            out << "Insert " << book << " 0\n";
        }
        // Ask 3 -- seed-dependent read-only argument.
        {
            int book = 3;
            out << "Ask " << book << "\n";
        }
        // Query -- seed-dependent read-only argument.
        {
            int k = 1 + (int)(rng() % n);
            out << "Query " << k << "\n";
        }
        // Ask 1
        {
            int book = 1;
            out << "Ask " << book << "\n";
        }
        return;
    }

    if (profile == "large" && case_kind == "upper_bound") {
        int n = 80000;
        int m = 80000;
        out << n << " " << m << "\n";
        for (int i = 1; i <= n; ++i) {
            if (i > 1) out << " ";
            out << i;
        }
        out << "\n";
        for (int i = 0; i < m; ++i) {
            out << "Ask 1\n";
        }
        return;
    }

    if (profile == "large" && case_kind == "random") {
        std::mt19937_64 rng(seed);
        int n = 80000;
        int m = 80000;
        out << n << " " << m << "\n";
        for (int i = 1; i <= n; ++i) {
            if (i > 1) out << " ";
            out << i;
        }
        out << "\n";
        int half = m / 2;
        for (int i = 0; i < half; ++i) {
            out << "Ask 1\n";
        }
        for (int i = half; i < m; ++i) {
            int k = 1 + (int)(rng() % n);
            out << "Query " << k << "\n";
        }
        return;
    }
}
