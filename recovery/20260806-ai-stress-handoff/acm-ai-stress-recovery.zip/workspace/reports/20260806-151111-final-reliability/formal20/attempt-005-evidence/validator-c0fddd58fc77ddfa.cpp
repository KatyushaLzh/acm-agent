#include <bits/stdc++.h>
using namespace std;

static string esc(const string& s) {
    string r;
    for (char c : s) {
        if (c == '"' || c == '\\') { r.push_back('\\'); r.push_back(c); }
        else if (c == '\n') { r += "\\n"; }
        else if (c == '\r') { r += "\\r"; }
        else if (c == '\t') { r += "\\t"; }
        else if ((unsigned char)c < 0x20) {
            char buf[8]; snprintf(buf, sizeof(buf), "\\u%04x", (unsigned char)c);
            r += buf;
        } else r.push_back(c);
    }
    return r;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    auto fail = [&](const string& msg) {
        cerr << msg << "\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
        return 0;
    };

    long long n, m;
    if (!(cin >> n >> m)) return fail("ERR_IO 0");
    if (n < 1 || n > 80000) return fail("ERR_N 0");
    if (m < 0 || m > 80000) return fail("ERR_M 0");

    vector<int> perm;
    perm.reserve((size_t)n);
    vector<char> seen((size_t)n + 1, 0);
    for (long long i = 0; i < n; ++i) {
        long long x;
        if (!(cin >> x)) return fail("ERR_PERM " + to_string(i));
        if (x < 1 || x > n) return fail("ERR_PERM_VAL " + to_string(i));
        if (seen[(size_t)x]) return fail("ERR_PERM_DUP " + to_string(i));
        seen[(size_t)x] = 1;
        perm.push_back((int)x);
    }

    list<int> seq(perm.begin(), perm.end());
    unordered_map<int, list<int>::iterator> pos;
    {
        auto it = seq.begin();
        for (int v : perm) {
            pos[v] = it;
            ++it;
        }
    }

    vector<string> tags;
    bool has_top = false, has_bottom = false, has_insert = false, has_ask = false, has_query = false;
    bool has_c1min = (n == 1), has_c1max = (n == 80000);
    bool has_c2min = (m == 0), has_c2max = (m == 80000);
    bool has_c4min = false, has_c4max = false;
    bool has_c5min = false, has_c5max = false;
    bool has_c6min = false, has_c6max = false;

    long long records = 0;
    for (long long idx = 0; idx < m; ++idx) {
        string op;
        if (!(cin >> op)) return fail("ERR_OP " + to_string(idx));
        if (op == "Top") {
            long long s;
            if (!(cin >> s)) return fail("ERR_ARG " + to_string(idx));
            if (s < 1 || s > n) return fail("ERR_S " + to_string(idx));
            auto it = pos.find((int)s);
            if (it == pos.end()) return fail("ERR_NOEXIST " + to_string(idx));
            auto node = it->second;
            seq.splice(seq.begin(), seq, node);
            pos[(int)s] = node;
            has_top = true;
            if (s == 1) has_c4min = true;
            if (s == n) has_c4max = true;
        } else if (op == "Bottom") {
            long long s;
            if (!(cin >> s)) return fail("ERR_ARG " + to_string(idx));
            if (s < 1 || s > n) return fail("ERR_S " + to_string(idx));
            auto it = pos.find((int)s);
            if (it == pos.end()) return fail("ERR_NOEXIST " + to_string(idx));
            auto node = it->second;
            seq.splice(seq.end(), seq, node);
            pos[(int)s] = node;
            has_bottom = true;
            if (s == 1) has_c4min = true;
            if (s == n) has_c4max = true;
        } else if (op == "Insert") {
            long long s, t;
            if (!(cin >> s >> t)) return fail("ERR_ARG " + to_string(idx));
            if (s < 1 || s > n) return fail("ERR_S " + to_string(idx));
            if (t < -1 || t > 1) return fail("ERR_T " + to_string(idx));
            auto it = pos.find((int)s);
            if (it == pos.end()) return fail("ERR_NOEXIST " + to_string(idx));
            auto node = it->second;
            if (t == -1) {
                if (node == seq.begin()) return fail("ERR_ILLEGAL " + to_string(idx));
                auto target = prev(node);
                seq.splice(target, seq, node);
            } else if (t == 1) {
                auto nxt = next(node);
                if (nxt == seq.end()) return fail("ERR_ILLEGAL " + to_string(idx));
                auto after = next(nxt);
                seq.splice(after, seq, node);
            }
            pos[(int)s] = node;
            has_insert = true;
            if (s == 1) has_c4min = true;
            if (s == n) has_c4max = true;
            if (t == -1) has_c6min = true;
            if (t == 1) has_c6max = true;
            if (t == 0) { has_c6min = true; has_c6max = true; }
        } else if (op == "Ask") {
            long long s;
            if (!(cin >> s)) return fail("ERR_ARG " + to_string(idx));
            if (s < 1 || s > n) return fail("ERR_S " + to_string(idx));
            if (pos.find((int)s) == pos.end()) return fail("ERR_NOEXIST " + to_string(idx));
            has_ask = true;
            if (s == 1) has_c4min = true;
            if (s == n) has_c4max = true;
        } else if (op == "Query") {
            long long k;
            if (!(cin >> k)) return fail("ERR_ARG " + to_string(idx));
            if (k < 1 || k > n) return fail("ERR_K " + to_string(idx));
            has_query = true;
            if (k == 1) has_c5min = true;
            if (k == n) has_c5max = true;
        } else {
            return fail("ERR_OPNAME " + to_string(idx));
        }
        ++records;
    }

    string extra;
    if (cin >> extra) return fail("ERR_TRAILING " + to_string(m));

    if (has_top) tags.push_back("auto_operation_top");
    if (has_bottom) tags.push_back("auto_operation_bottom");
    if (has_insert) tags.push_back("auto_operation_insert");
    if (has_ask) tags.push_back("auto_operation_ask");
    if (has_query) tags.push_back("auto_operation_query");
    if (has_c1min) tags.push_back("auto_c1_minimum");
    if (has_c1max) tags.push_back("auto_c1_maximum");
    if (has_c2min) tags.push_back("auto_c2_minimum");
    if (has_c2max) tags.push_back("auto_c2_maximum");
    if (has_c4min) tags.push_back("auto_c4_minimum");
    if (has_c4max) tags.push_back("auto_c4_maximum");
    if (has_c5min) tags.push_back("auto_c5_minimum");
    if (has_c5max) tags.push_back("auto_c5_maximum");
    if (has_c6min) tags.push_back("auto_c6_minimum");
    if (has_c6max) tags.push_back("auto_c6_maximum");

    cout << "{\"valid\":true,\"dimensions\":{\"n\":" << n << ",\"m\":" << m << "},\"coverage_tags\":[";
    for (size_t i = 0; i < tags.size(); ++i) {
        if (i) cout << ",";
        cout << "\"" << esc(tags[i]) << "\"";
    }
    cout << "],\"records\":" << records << "}\n";
    return 0;
}
