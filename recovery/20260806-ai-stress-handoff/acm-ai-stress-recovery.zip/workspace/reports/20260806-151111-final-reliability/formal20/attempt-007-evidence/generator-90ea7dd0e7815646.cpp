#include <bits/stdc++.h>
using namespace std;

static uint64_t splitmix64(uint64_t x) {
    x += 0x9e3779b97f4a7c15ULL;
    x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ULL;
    x = (x ^ (x >> 27)) * 0x94d049bb133111ebULL;
    return x ^ (x >> 31);
}

static vector<int> gen_perm(int n) {
    vector<int> p(n);
    for (int i = 0; i < n; ++i) p[i] = i + 1;
    return p;
}

void acm_generate_case(unsigned long long seed, const std::string& profile,
                       const std::string& case_kind, std::ostream& out) {
    if (profile == "small" && case_kind == "lower_bound") {
        out << "1 0\n";
        out << "1\n";
        return;
    }
    if (profile == "small" && case_kind == "random") {
        int n = 5, m = 8;
        out << n << " " << m << "\n";
        vector<int> p = gen_perm(n);
        for (int i = 0; i < n; ++i) {
            if (i) out << " ";
            out << p[i];
        }
        out << "\n";
        vector<int> cur = p;
        auto find_pos = [&](int x) {
            for (int i = 0; i < (int)cur.size(); ++i)
                if (cur[i] == x) return i;
            return -1;
        };
        auto do_top = [&](int s) {
            int pos = find_pos(s);
            cur.erase(cur.begin() + pos);
            cur.insert(cur.begin(), s);
        };
        auto do_bottom = [&](int s) {
            int pos = find_pos(s);
            cur.erase(cur.begin() + pos);
            cur.push_back(s);
        };
        auto do_insert = [&](int s, int t) {
            int pos = find_pos(s);
            cur.erase(cur.begin() + pos);
            int newpos = pos + t;
            if (newpos < 0) newpos = 0;
            if (newpos > (int)cur.size()) newpos = (int)cur.size();
            cur.insert(cur.begin() + newpos, s);
        };
        uint64_t rng = splitmix64(seed);
        auto rnd = [&](int lo, int hi) {
            rng = splitmix64(rng);
            return lo + (int)(rng % (uint64_t)(hi - lo + 1));
        };
        out << "Top 3\n";
        do_top(3);
        out << "Bottom 1\n";
        do_bottom(1);
        out << "Insert 2 1\n";
        do_insert(2, 1);
        out << "Insert 4 -1\n";
        do_insert(4, -1);
        out << "Insert 5 0\n";
        do_insert(5, 0);
        int ask_arg = rnd(1, n);
        out << "Ask " << ask_arg << "\n";
        int q_arg = rnd(1, n);
        out << "Query " << q_arg << "\n";
        out << "Ask 5\n";
        return;
    }
    if (profile == "large" && case_kind == "upper_bound") {
        int n = 80000, m = 80000;
        out << n << " " << m << "\n";
        for (int i = 1; i <= n; ++i) {
            if (i > 1) out << " ";
            out << i;
        }
        out << "\n";
        for (int i = 0; i < m; ++i) {
            out << "Ask 1\n";
        }
        return;
    }
    if (profile == "large" && case_kind == "random") {
        int n = 80000, m = 80000;
        out << n << " " << m << "\n";
        for (int i = 1; i <= n; ++i) {
            if (i > 1) out << " ";
            out << i;
        }
        out << "\n";
        uint64_t rng = splitmix64(seed);
        auto rnd = [&](int lo, int hi) {
            rng = splitmix64(rng);
            return lo + (int)(rng % (uint64_t)(hi - lo + 1));
        };
        for (int i = 0; i < 40000; ++i) {
            int arg = rnd(1, n);
            out << "Ask " << arg << "\n";
        }
        for (int i = 0; i < 40000; ++i) {
            int arg = rnd(1, n);
            out << "Query " << arg << "\n";
        }
        return;
    }
    // Fallback: should not happen with valid harness.
    out << "1 0\n1\n";
}
