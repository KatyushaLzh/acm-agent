#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, m;
    cin >> n >> m;

    vector<int> pos(n + 1);
    vector<int> shelf(n);
    for (int i = 0; i < n; ++i) {
        cin >> shelf[i];
        pos[shelf[i]] = i;
    }

    for (int i = 0; i < m; ++i) {
        string op;
        cin >> op;
        if (op == "Top") {
            int s;
            cin >> s;
            int p = pos[s];
            shelf.erase(shelf.begin() + p);
            shelf.insert(shelf.begin(), s);
            for (int j = 0; j < n; ++j) pos[shelf[j]] = j;
        } else if (op == "Bottom") {
            int s;
            cin >> s;
            int p = pos[s];
            shelf.erase(shelf.begin() + p);
            shelf.push_back(s);
            for (int j = 0; j < n; ++j) pos[shelf[j]] = j;
        } else if (op == "Insert") {
            int s, t;
            cin >> s >> t;
            if (t == 0) continue;
            int p = pos[s];
            int q = p + t;
            swap(shelf[p], shelf[q]);
            pos[shelf[p]] = p;
            pos[shelf[q]] = q;
        } else if (op == "Ask") {
            int s;
            cin >> s;
            cout << pos[s] << '\n';
        } else if (op == "Query") {
            int k;
            cin >> k;
            cout << shelf[k - 1] << '\n';
        }
    }

    return 0;
}
