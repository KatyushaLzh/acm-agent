#include <algorithm>
#include <cstdint>
#include <ostream>
#include <random>
#include <string>
#include <vector>

void acm_generate_case(unsigned long long seed, const std::string& profile,
                       const std::string& case_kind, std::ostream& out) {
    if (profile == "small" && case_kind == "lower_bound") {
        out << "1 0\n";
        out << "1\n";
        return;
    }

    if (profile == "small" && case_kind == "random") {
        std::mt19937_64 rng(seed);
        int n = 5;
        int m = 8;
        out << n << ' ' << m << '\n';
        out << "1 2 3 4 5\n";

        std::vector<int> state = {1, 2, 3, 4, 5};

        auto find_pos = [&](int val) -> int {
            for (int i = 0; i < (int)state.size(); ++i) {
                if (state[i] == val) return i;
            }
            return -1;
        };

        auto erase_at = [&](int pos) {
            state.erase(state.begin() + pos);
        };

        auto insert_at = [&](int pos, int val) {
            state.insert(state.begin() + pos, val);
        };

        // Operation 1: Top 3
        {
            int s = 3;
            int pos = find_pos(s);
            erase_at(pos);
            insert_at(0, s);
            out << "Top " << s << '\n';
        }
        // Operation 2: Bottom 1
        {
            int s = 1;
            int pos = find_pos(s);
            erase_at(pos);
            insert_at((int)state.size(), s);
            out << "Bottom " << s << '\n';
        }
        // Operation 3: Insert 2 -1
        {
            int s = 2;
            int t = -1;
            int pos = find_pos(s);
            erase_at(pos);
            int new_pos = pos + t;
            if (new_pos < 0) new_pos = 0;
            if (new_pos > (int)state.size()) new_pos = (int)state.size();
            insert_at(new_pos, s);
            out << "Insert " << s << ' ' << t << '\n';
        }
        // Operation 4: Insert 4 1
        {
            int s = 4;
            int t = 1;
            int pos = find_pos(s);
            erase_at(pos);
            int new_pos = pos + t;
            if (new_pos < 0) new_pos = 0;
            if (new_pos > (int)state.size()) new_pos = (int)state.size();
            insert_at(new_pos, s);
            out << "Insert " << s << ' ' << t << '\n';
        }
        // Operation 5: Insert 5 0
        {
            int s = 5;
            int t = 0;
            int pos = find_pos(s);
            erase_at(pos);
            int new_pos = pos + t;
            if (new_pos < 0) new_pos = 0;
            if (new_pos > (int)state.size()) new_pos = (int)state.size();
            insert_at(new_pos, s);
            out << "Insert " << s << ' ' << t << '\n';
        }
        // Operation 6: Ask 3 (seed-dependent)
        {
            int s = (int)(rng() % n) + 1;
            out << "Ask " << s << '\n';
        }
        // Operation 7: Query 2 (seed-dependent)
        {
            int k = (int)(rng() % n) + 1;
            out << "Query " << k << '\n';
        }
        // Operation 8: Ask 1 (seed-dependent)
        {
            int s = (int)(rng() % n) + 1;
            out << "Ask " << s << '\n';
        }
        return;
    }

    if (profile == "large" && case_kind == "upper_bound") {
        int n = 80000;
        int m = 80000;
        out << n << ' ' << m << '\n';
        for (int i = 1; i <= n; ++i) {
            if (i > 1) out << ' ';
            out << i;
        }
        out << '\n';
        for (int i = 0; i < m; ++i) {
            out << "Query 1\n";
        }
        return;
    }

    if (profile == "large" && case_kind == "random") {
        std::mt19937_64 rng(seed);
        int n = 80000;
        int m = 80000;
        out << n << ' ' << m << '\n';
        for (int i = 1; i <= n; ++i) {
            if (i > 1) out << ' ';
            out << i;
        }
        out << '\n';
        for (int i = 0; i < 40000; ++i) {
            int s = (int)(rng() % n) + 1;
            out << "Ask " << s << '\n';
        }
        for (int i = 0; i < 40000; ++i) {
            int k = (int)(rng() % n) + 1;
            out << "Query " << k << '\n';
        }
        return;
    }
}
