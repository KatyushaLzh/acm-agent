#include <bits/stdc++.h>
using namespace std;

struct JsonWriter {
    string s;
    void begin_obj() { s += '{'; }
    void end_obj() { s += '}'; }
    void begin_arr() { s += '['; }
    void end_arr() { s += ']'; }
    void key(const string& k) { s += '"' + k + "\":"; }
    void val(bool b) { s += b ? "true" : "false"; }
    void val(long long v) { s += to_string(v); }
    void val_str(const string& v) {
        s += '"';
        for (char c : v) {
            if (c == '"' || c == '\\') { s += '\\'; s += c; }
            else if (c == '\n') s += "\\n";
            else if (c == '\r') s += "\\r";
            else if (c == '\t') s += "\\t";
            else if ((unsigned char)c < 0x20) {
                char buf[8]; snprintf(buf, sizeof(buf), "\\u%04x", c);
                s += buf;
            } else s += c;
        }
        s += '"';
    }
    void comma() { s += ','; }
};

struct Fail {
    string code;
    int idx;
    long long state;
};

static string err_msg(const string& code, int idx, long long state) {
    return code + " idx=" + to_string(idx) + " state=" + to_string(state);
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    string line;
    if (!getline(cin, line)) {
        cerr << "NO_INPUT idx=-1 state=0\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
        return 0;
    }
    stringstream ss(line);
    long long n, m;
    if (!(ss >> n >> m)) {
        cerr << "BAD_HEADER idx=0 state=0\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
        return 0;
    }
    string extra;
    if (ss >> extra) {
        cerr << "EXTRA_HEADER idx=0 state=0\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
        return 0;
    }
    if (n < 1 || n > 80000 || m < 0 || m > 80000) {
        cerr << "HEADER_RANGE idx=0 state=0\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
        return 0;
    }

    vector<int> perm;
    perm.reserve((size_t)n);
    vector<char> seen((size_t)n + 1, 0);
    for (long long i = 0; i < n; ++i) {
        long long x;
        if (!(cin >> x)) {
            cerr << "PERM_SHORT idx=" << i << " state=0\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
            return 0;
        }
        if (x < 1 || x > n || seen[(size_t)x]) {
            cerr << "PERM_BAD idx=" << i << " state=" << x << "\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
            return 0;
        }
        seen[(size_t)x] = 1;
        perm.push_back((int)x);
    }

    list<int> seq(perm.begin(), perm.end());
    unordered_map<int, list<int>::iterator> pos;
    pos.reserve((size_t)n * 2);
    {
        auto it = seq.begin();
        for (int v : perm) {
            pos[v] = it;
            ++it;
        }
    }

    vector<string> tags;
    auto add_tag = [&](const string& t) {
        if (find(tags.begin(), tags.end(), t) == tags.end()) tags.push_back(t);
    };

    bool has_top = false, has_bottom = false, has_insert = false, has_ask = false, has_query = false;
    bool c1_min = false, c1_max = false, c2_min = false, c2_max = false;
    bool c4_min = false, c4_max = false, c5_min = false, c5_max = false, c6_min = false, c6_max = false;

    if (n == 1) c1_min = true;
    if (n == 80000) c1_max = true;
    if (m == 0) c2_min = true;
    if (m == 80000) c2_max = true;

    long long records = 0;
    for (long long op_idx = 0; op_idx < m; ++op_idx) {
        string op;
        if (!(cin >> op)) {
            cerr << "OP_SHORT idx=" << op_idx << " state=0\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
            return 0;
        }
        if (op == "Top") {
            long long s;
            if (!(cin >> s)) {
                cerr << "ARG_SHORT idx=" << op_idx << " state=0\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (s < 1 || s > n) {
                cerr << "ARG_RANGE idx=" << op_idx << " state=" << s << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            auto it = pos[(int)s];
            if (it != seq.begin()) {
                seq.splice(seq.begin(), seq, it);
            }
            has_top = true;
            if (s == 1) c4_min = true;
            if (s == n) c4_max = true;
        } else if (op == "Bottom") {
            long long s;
            if (!(cin >> s)) {
                cerr << "ARG_SHORT idx=" << op_idx << " state=0\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (s < 1 || s > n) {
                cerr << "ARG_RANGE idx=" << op_idx << " state=" << s << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            auto it = pos[(int)s];
            auto last = seq.end();
            --last;
            if (it != last) {
                seq.splice(seq.end(), seq, it);
            }
            has_bottom = true;
            if (s == 1) c4_min = true;
            if (s == n) c4_max = true;
        } else if (op == "Insert") {
            long long s, t;
            if (!(cin >> s >> t)) {
                cerr << "ARG_SHORT idx=" << op_idx << " state=0\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (s < 1 || s > n || t < -1 || t > 1) {
                cerr << "ARG_RANGE idx=" << op_idx << " state=" << s << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            auto it = pos[(int)s];
            if (t == -1) {
                if (it == seq.begin()) {
                    cerr << "DYN_ILLEGAL idx=" << op_idx << " state=" << s << "\n";
                    cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                    return 0;
                }
                auto target = prev(it);
                seq.splice(target, seq, it);
            } else if (t == 1) {
                auto nxt = next(it);
                if (nxt == seq.end()) {
                    cerr << "DYN_ILLEGAL idx=" << op_idx << " state=" << s << "\n";
                    cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                    return 0;
                }
                auto target = next(nxt);
                seq.splice(target, seq, it);
            }
            has_insert = true;
            if (s == 1) c4_min = true;
            if (s == n) c4_max = true;
            if (t == -1) c6_min = true;
            if (t == 1) c6_max = true;
            if (t == 0) { c6_min = true; c6_max = true; }
        } else if (op == "Ask") {
            long long s;
            if (!(cin >> s)) {
                cerr << "ARG_SHORT idx=" << op_idx << " state=0\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (s < 1 || s > n) {
                cerr << "ARG_RANGE idx=" << op_idx << " state=" << s << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            has_ask = true;
            if (s == 1) c4_min = true;
            if (s == n) c4_max = true;
        } else if (op == "Query") {
            long long k;
            if (!(cin >> k)) {
                cerr << "ARG_SHORT idx=" << op_idx << " state=0\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            if (k < 1 || k > n) {
                cerr << "ARG_RANGE idx=" << op_idx << " state=" << k << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
                return 0;
            }
            has_query = true;
            if (k == 1) c5_min = true;
            if (k == n) c5_max = true;
        } else {
            cerr << "BAD_OP idx=" << op_idx << " state=0\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
            return 0;
        }
        ++records;
    }

    string trailing;
    if (cin >> trailing) {
        cerr << "EXTRA_TOKEN idx=" << m << " state=0\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
        return 0;
    }

    if (has_top) add_tag("auto_operation_top");
    if (has_bottom) add_tag("auto_operation_bottom");
    if (has_insert) add_tag("auto_operation_insert");
    if (has_ask) add_tag("auto_operation_ask");
    if (has_query) add_tag("auto_operation_query");
    if (c1_min) add_tag("auto_c1_minimum");
    if (c1_max) add_tag("auto_c1_maximum");
    if (c2_min) add_tag("auto_c2_minimum");
    if (c2_max) add_tag("auto_c2_maximum");
    if (c4_min) add_tag("auto_c4_minimum");
    if (c4_max) add_tag("auto_c4_maximum");
    if (c5_min) add_tag("auto_c5_minimum");
    if (c5_max) add_tag("auto_c5_maximum");
    if (c6_min) add_tag("auto_c6_minimum");
    if (c6_max) add_tag("auto_c6_maximum");

    JsonWriter jw;
    jw.begin_obj();
    jw.key("valid"); jw.val(true); jw.comma();
    jw.key("dimensions");
    jw.begin_obj();
    jw.key("n"); jw.val(n); jw.comma();
    jw.key("m"); jw.val(m);
    jw.end_obj(); jw.comma();
    jw.key("coverage_tags");
    jw.begin_arr();
    for (size_t i = 0; i < tags.size(); ++i) {
        if (i) jw.comma();
        jw.val_str(tags[i]);
    }
    jw.end_arr(); jw.comma();
    jw.key("records"); jw.val(records);
    jw.end_obj();
    cout << jw.s << "\n";
    return 0;
}
