#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, m;
    cin >> n >> m;

    vector<int> pos(n + 1);
    vector<int> book(n + 1);
    for (int i = 1; i <= n; ++i) {
        cin >> book[i];
        pos[book[i]] = i;
    }

    for (int i = 0; i < m; ++i) {
        string op;
        cin >> op;
        if (op == "Top") {
            int s;
            cin >> s;
            int p = pos[s];
            for (int j = p; j > 1; --j) {
                book[j] = book[j - 1];
                pos[book[j]] = j;
            }
            book[1] = s;
            pos[s] = 1;
        } else if (op == "Bottom") {
            int s;
            cin >> s;
            int p = pos[s];
            for (int j = p; j < n; ++j) {
                book[j] = book[j + 1];
                pos[book[j]] = j;
            }
            book[n] = s;
            pos[s] = n;
        } else if (op == "Insert") {
            int s, t;
            cin >> s >> t;
            if (t == 0) continue;
            int p = pos[s];
            int q = p + t;
            swap(book[p], book[q]);
            pos[book[p]] = p;
            pos[book[q]] = q;
        } else if (op == "Ask") {
            int s;
            cin >> s;
            cout << pos[s] - 1 << '\n';
        } else if (op == "Query") {
            int k;
            cin >> k;
            cout << book[k] << '\n';
        }
    }

    return 0;
}
