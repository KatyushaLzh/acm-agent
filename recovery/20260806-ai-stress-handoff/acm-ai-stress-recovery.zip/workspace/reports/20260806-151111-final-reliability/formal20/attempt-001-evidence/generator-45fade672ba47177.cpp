#include <algorithm>
#include <cstdint>
#include <ostream>
#include <random>
#include <string>
#include <vector>

void acm_generate_case(unsigned long long seed, const std::string& profile,
                       const std::string& case_kind, std::ostream& out) {
    if (profile == "small" && case_kind == "lower_bound") {
        out << "1 0\n";
        out << "1\n";
        return;
    }
    if (profile == "small" && case_kind == "random") {
        std::mt19937_64 rng(seed);
        int n = 5;
        int m = 8;
        out << n << ' ' << m << '\n';
        out << "1 2 3 4 5\n";

        std::vector<int> seq = {1, 2, 3, 4, 5};

        auto find_pos = [&](int val) -> int {
            for (int i = 0; i < (int)seq.size(); ++i) {
                if (seq[i] == val) return i;
            }
            return -1;
        };

        auto do_top = [&](int s) {
            int p = find_pos(s);
            seq.erase(seq.begin() + p);
            seq.insert(seq.begin(), s);
        };
        auto do_bottom = [&](int s) {
            int p = find_pos(s);
            seq.erase(seq.begin() + p);
            seq.push_back(s);
        };
        auto do_insert = [&](int s, int t) {
            int p = find_pos(s);
            int q = p + t;
            seq.erase(seq.begin() + p);
            seq.insert(seq.begin() + q, s);
        };

        // Fixed legal skeleton from the blueprint.
        out << "Top 3\n";
        do_top(3);
        out << "Bottom 1\n";
        do_bottom(1);
        out << "Insert 2 1\n";
        do_insert(2, 1);
        out << "Insert 4 -1\n";
        do_insert(4, -1);
        out << "Insert 5 0\n";
        do_insert(5, 0);

        // Seed-dependent read-only arguments.
        int ask_arg = (int)(rng() % n) + 1;
        out << "Ask " << ask_arg << '\n';

        int query_arg = (int)(rng() % n) + 1;
        out << "Query " << query_arg << '\n';

        out << "Top 5\n";
        do_top(5);
        return;
    }
    if (profile == "large" && case_kind == "upper_bound") {
        int n = 80000;
        int m = 80000;
        out << n << ' ' << m << '\n';
        for (int i = 1; i <= n; ++i) {
            if (i > 1) out << ' ';
            out << i;
        }
        out << '\n';
        for (int i = 0; i < m; ++i) {
            out << "Query 1\n";
        }
        return;
    }
    if (profile == "large" && case_kind == "random") {
        std::mt19937_64 rng(seed);
        int n = 80000;
        int m = 80000;
        out << n << ' ' << m << '\n';
        for (int i = 1; i <= n; ++i) {
            if (i > 1) out << ' ';
            out << i;
        }
        out << '\n';
        for (int i = 0; i < m; ++i) {
            if ((rng() & 1ULL) == 0) {
                int k = (int)(rng() % n) + 1;
                out << "Query " << k << '\n';
            } else {
                int s = (int)(rng() % n) + 1;
                out << "Ask " << s << '\n';
            }
        }
        return;
    }
}
