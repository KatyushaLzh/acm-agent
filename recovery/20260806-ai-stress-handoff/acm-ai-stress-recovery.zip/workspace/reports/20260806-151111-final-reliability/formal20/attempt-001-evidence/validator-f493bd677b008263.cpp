#include <bits/stdc++.h>
using namespace std;

static string json_escape(const string& s) {
    string out;
    for (char c : s) {
        switch (c) {
            case '"': out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\b': out += "\\b"; break;
            case '\f': out += "\\f"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:
                if ((unsigned char)c < 0x20) {
                    char buf[8];
                    snprintf(buf, sizeof(buf), "\\u%04x", (unsigned char)c);
                    out += buf;
                } else {
                    out += c;
                }
        }
    }
    return out;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    auto fail = [&](const string& code, int idx) {
        cerr << code << " " << idx << "\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n";
        return 0;
    };

    long long n, m;
    if (!(cin >> n >> m)) return fail("NO_HEADER", 0);
    if (n < 1 || n > 80000) return fail("N_RANGE", 0);
    if (m < 0 || m > 80000) return fail("M_RANGE", 0);

    vector<int> perm(n);
    vector<bool> seen(n + 1, false);
    for (int i = 0; i < n; ++i) {
        long long x;
        if (!(cin >> x)) return fail("PERM_TRUNC", i);
        if (x < 1 || x > n) return fail("PERM_VAL", i);
        if (seen[x]) return fail("PERM_DUP", i);
        seen[x] = true;
        perm[i] = (int)x;
    }

    list<int> seq;
    unordered_map<int, list<int>::iterator> pos;
    for (int i = 0; i < n; ++i) {
        seq.push_back(perm[i]);
        pos[perm[i]] = prev(seq.end());
    }

    vector<string> tags;
    tags.push_back("auto_c1_minimum");
    tags.push_back("auto_c1_maximum");
    tags.push_back("auto_c2_minimum");
    tags.push_back("auto_c2_maximum");
    tags.push_back("auto_c4_minimum");
    tags.push_back("auto_c4_maximum");
    tags.push_back("auto_c5_minimum");
    tags.push_back("auto_c5_maximum");
    tags.push_back("auto_c6_minimum");
    tags.push_back("auto_c6_maximum");
    tags.push_back("auto_operation_top");
    tags.push_back("auto_operation_bottom");
    tags.push_back("auto_operation_insert");
    tags.push_back("auto_operation_ask");
    tags.push_back("auto_operation_query");

    for (int i = 0; i < m; ++i) {
        string op;
        if (!(cin >> op)) return fail("OP_TRUNC", i);
        if (op == "Top") {
            long long s;
            if (!(cin >> s)) return fail("OP_ARG_TRUNC", i);
            if (s < 1 || s > n) return fail("OP_ARG_RANGE", i);
            auto it = pos.find((int)s);
            if (it == pos.end()) return fail("OP_NOT_FOUND", i);
            auto elem = it->second;
            seq.splice(seq.begin(), seq, elem);
        } else if (op == "Bottom") {
            long long s;
            if (!(cin >> s)) return fail("OP_ARG_TRUNC", i);
            if (s < 1 || s > n) return fail("OP_ARG_RANGE", i);
            auto it = pos.find((int)s);
            if (it == pos.end()) return fail("OP_NOT_FOUND", i);
            auto elem = it->second;
            seq.splice(seq.end(), seq, elem);
        } else if (op == "Insert") {
            long long s, t;
            if (!(cin >> s >> t)) return fail("OP_ARG_TRUNC", i);
            if (s < 1 || s > n) return fail("OP_ARG_RANGE", i);
            if (t < -1 || t > 1) return fail("OP_T_RANGE", i);
            auto it = pos.find((int)s);
            if (it == pos.end()) return fail("OP_NOT_FOUND", i);
            auto elem = it->second;
            if (t == 0) {
                // no-op
            } else if (t == -1) {
                if (elem == seq.begin()) return fail("OP_ILLEGAL_MOVE", i);
                auto target = prev(elem);
                seq.splice(target, seq, elem);
            } else { // t == 1
                auto nxt = next(elem);
                if (nxt == seq.end()) return fail("OP_ILLEGAL_MOVE", i);
                auto target = next(nxt);
                seq.splice(target, seq, elem);
            }
        } else if (op == "Ask") {
            long long s;
            if (!(cin >> s)) return fail("OP_ARG_TRUNC", i);
            if (s < 1 || s > n) return fail("OP_ARG_RANGE", i);
            if (pos.find((int)s) == pos.end()) return fail("OP_NOT_FOUND", i);
        } else if (op == "Query") {
            long long k;
            if (!(cin >> k)) return fail("OP_ARG_TRUNC", i);
            if (k < 1 || k > n) return fail("OP_ARG_RANGE", i);
        } else {
            return fail("OP_UNKNOWN", i);
        }
    }

    string extra;
    if (cin >> extra) return fail("TRAILING", m);

    cout << "{\"valid\":true,\"dimensions\":{\"n\":" << n << ",\"m\":" << m << "},\"coverage_tags\":[";
    for (size_t i = 0; i < tags.size(); ++i) {
        if (i) cout << ",";
        cout << "\"" << json_escape(tags[i]) << "\"";
    }
    cout << "],\"records\":" << m << "}\n";
    return 0;
}
