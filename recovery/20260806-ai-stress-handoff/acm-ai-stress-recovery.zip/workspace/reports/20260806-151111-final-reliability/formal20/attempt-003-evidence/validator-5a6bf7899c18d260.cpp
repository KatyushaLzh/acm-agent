#include <bits/stdc++.h>
using namespace std;

static string esc(const string& s) {
    string r;
    for (char c : s) {
        if (c == '"' || c == '\\') { r += '\\'; r += c; }
        else if (c == '\n') r += "\\n";
        else if (c == '\r') r += "\\r";
        else if (c == '\t') r += "\\t";
        else if ((unsigned char)c < 0x20) {
            char buf[8];
            snprintf(buf, sizeof(buf), "\\u%04x", (unsigned char)c);
            r += buf;
        } else r += c;
    }
    return r;
}

static void fail(const string& msg, int idx) {
    fprintf(stderr, "%s %d\n", msg.c_str(), idx);
    printf("{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}\n");
    exit(0);
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, m;
    if (!(cin >> n >> m)) fail("ERR_HEADER", 0);
    if (n < 1 || n > 80000) fail("ERR_N", 0);
    if (m < 0 || m > 80000) fail("ERR_M", 0);

    vector<int> perm(n);
    vector<bool> seen(n + 1, false);
    for (int i = 0; i < n; ++i) {
        if (!(cin >> perm[i])) fail("ERR_PERM", i);
        if (perm[i] < 1 || perm[i] > n || seen[perm[i]]) fail("ERR_PERM_VAL", i);
        seen[perm[i]] = true;
    }

    list<int> seq;
    for (int v : perm) seq.push_back(v);
    unordered_map<int, list<int>::iterator> pos;
    {
        auto it = seq.begin();
        for (int v : perm) {
            pos[v] = it;
            ++it;
        }
    }

    vector<string> tags;
    bool has_top = false, has_bottom = false, has_insert = false, has_ask = false, has_query = false;
    bool has_c1_min = (n == 1), has_c1_max = (n == 80000);
    bool has_c2_min = (m == 0), has_c2_max = (m == 80000);
    bool has_c4_min = false, has_c4_max = false;
    bool has_c5_min = false, has_c5_max = false;
    bool has_c6_min = false, has_c6_max = false;

    for (int i = 0; i < m; ++i) {
        string op;
        if (!(cin >> op)) fail("ERR_OP", i);
        if (op == "Top") {
            int s;
            if (!(cin >> s)) fail("ERR_ARG", i);
            if (s < 1 || s > n) fail("ERR_S", i);
            if (pos.find(s) == pos.end()) fail("ERR_S_EXIST", i);
            auto it = pos[s];
            seq.splice(seq.begin(), seq, it);
            pos[s] = seq.begin();
            has_top = true;
            if (s == 1) has_c4_min = true;
            if (s == n) has_c4_max = true;
        } else if (op == "Bottom") {
            int s;
            if (!(cin >> s)) fail("ERR_ARG", i);
            if (s < 1 || s > n) fail("ERR_S", i);
            if (pos.find(s) == pos.end()) fail("ERR_S_EXIST", i);
            auto it = pos[s];
            seq.splice(seq.end(), seq, it);
            pos[s] = prev(seq.end());
            has_bottom = true;
            if (s == 1) has_c4_min = true;
            if (s == n) has_c4_max = true;
        } else if (op == "Insert") {
            int s, t;
            if (!(cin >> s >> t)) fail("ERR_ARG", i);
            if (s < 1 || s > n) fail("ERR_S", i);
            if (t < -1 || t > 1) fail("ERR_T", i);
            if (pos.find(s) == pos.end()) fail("ERR_S_EXIST", i);
            auto it = pos[s];
            if (t == -1) {
                if (it == seq.begin()) fail("ERR_INSERT_PREV", i);
                auto target = prev(it);
                seq.splice(target, seq, it);
                pos[s] = target;
            } else if (t == 1) {
                auto nxt = next(it);
                if (nxt == seq.end()) fail("ERR_INSERT_NEXT", i);
                seq.splice(nxt, seq, it);
                pos[s] = nxt;
            }
            has_insert = true;
            if (s == 1) has_c4_min = true;
            if (s == n) has_c4_max = true;
            if (t == -1) has_c6_min = true;
            if (t == 1) has_c6_max = true;
            if (t == 0) { has_c6_min = true; has_c6_max = true; }
        } else if (op == "Ask") {
            int s;
            if (!(cin >> s)) fail("ERR_ARG", i);
            if (s < 1 || s > n) fail("ERR_S", i);
            if (pos.find(s) == pos.end()) fail("ERR_S_EXIST", i);
            has_ask = true;
            if (s == 1) has_c4_min = true;
            if (s == n) has_c4_max = true;
        } else if (op == "Query") {
            int k;
            if (!(cin >> k)) fail("ERR_ARG", i);
            if (k < 1 || k > n) fail("ERR_K", i);
            has_query = true;
            if (k == 1) has_c5_min = true;
            if (k == n) has_c5_max = true;
        } else {
            fail("ERR_OP_UNKNOWN", i);
        }
    }

    string extra;
    if (cin >> extra) fail("ERR_TRAILING", m);

    if (has_top) tags.push_back("auto_operation_top");
    if (has_bottom) tags.push_back("auto_operation_bottom");
    if (has_insert) tags.push_back("auto_operation_insert");
    if (has_ask) tags.push_back("auto_operation_ask");
    if (has_query) tags.push_back("auto_operation_query");
    if (has_c1_min) tags.push_back("auto_c1_minimum");
    if (has_c1_max) tags.push_back("auto_c1_maximum");
    if (has_c2_min) tags.push_back("auto_c2_minimum");
    if (has_c2_max) tags.push_back("auto_c2_maximum");
    if (has_c4_min) tags.push_back("auto_c4_minimum");
    if (has_c4_max) tags.push_back("auto_c4_maximum");
    if (has_c5_min) tags.push_back("auto_c5_minimum");
    if (has_c5_max) tags.push_back("auto_c5_maximum");
    if (has_c6_min) tags.push_back("auto_c6_minimum");
    if (has_c6_max) tags.push_back("auto_c6_maximum");

    printf("{\"valid\":true,\"dimensions\":{\"n\":%d,\"m\":%d},\"coverage_tags\":[", n, m);
    for (size_t i = 0; i < tags.size(); ++i) {
        if (i) printf(",");
        printf("\"%s\"", esc(tags[i]).c_str());
    }
    printf("],\"records\":%d}\n", m);
    return 0;
}
