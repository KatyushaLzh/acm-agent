#include <bits/stdc++.h>
using namespace std;

static unsigned long long rng_state;
static unsigned long long rng_next() {
    rng_state ^= rng_state << 7;
    rng_state ^= rng_state >> 9;
    return rng_state;
}

void acm_generate_case(unsigned long long seed, const string& profile, const string& case_kind, ostream& out) {
    if (profile == "small" && case_kind == "lower_bound") {
        out << "1 0\n1\n";
        return;
    }
    if (profile == "small" && case_kind == "random") {
        int n = 5, m = 8;
        out << n << " " << m << "\n";
        out << "1 2 3 4 5\n";
        rng_state = seed;
        unsigned long long r = rng_next();
        int qk = (int)(r % n) + 1;
        out << "Top 3\n";
        out << "Bottom 1\n";
        out << "Insert 4 -1\n";
        out << "Insert 2 0\n";
        out << "Insert 5 1\n";
        out << "Ask 3\n";
        out << "Query " << qk << "\n";
        out << "Top 5\n";
        return;
    }
    if (profile == "large" && case_kind == "upper_bound") {
        int n = 80000, m = 80000;
        out << n << " " << m << "\n";
        for (int i = 1; i <= n; ++i) {
            if (i > 1) out << " ";
            out << i;
        }
        out << "\n";
        for (int i = 0; i < m; ++i) {
            out << "Query 1\n";
        }
        return;
    }
    if (profile == "large" && case_kind == "random") {
        int n = 80000, m = 80000;
        out << n << " " << m << "\n";
        for (int i = 1; i <= n; ++i) {
            if (i > 1) out << " ";
            out << i;
        }
        out << "\n";
        rng_state = seed;
        for (int i = 1; i <= 40000; ++i) {
            out << "Top " << i << "\n";
        }
        for (int i = 0; i < 40000; ++i) {
            unsigned long long r = rng_next();
            int k = (int)(r % n) + 1;
            out << "Query " << k << "\n";
        }
        return;
    }
}
