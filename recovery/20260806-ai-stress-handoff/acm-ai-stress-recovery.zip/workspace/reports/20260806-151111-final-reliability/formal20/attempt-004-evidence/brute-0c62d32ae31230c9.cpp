#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, m;
    cin >> n >> m;

    vector<int> a(n);
    for (int i = 0; i < n; ++i) {
        cin >> a[i];
    }

    for (int i = 0; i < m; ++i) {
        string op;
        cin >> op;
        if (op == "Top") {
            int s;
            cin >> s;
            auto it = find(a.begin(), a.end(), s);
            int val = *it;
            a.erase(it);
            a.insert(a.begin(), val);
        } else if (op == "Bottom") {
            int s;
            cin >> s;
            auto it = find(a.begin(), a.end(), s);
            int val = *it;
            a.erase(it);
            a.push_back(val);
        } else if (op == "Insert") {
            int s, t;
            cin >> s >> t;
            if (t == 0) continue;
            auto it = find(a.begin(), a.end(), s);
            int idx = it - a.begin();
            int other = idx + t;
            swap(a[idx], a[other]);
        } else if (op == "Ask") {
            int s;
            cin >> s;
            auto it = find(a.begin(), a.end(), s);
            cout << (it - a.begin()) << '\n';
        } else if (op == "Query") {
            int k;
            cin >> k;
            cout << a[k - 1] << '\n';
        }
    }

    return 0;
}
