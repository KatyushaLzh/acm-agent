#include <algorithm>
#include <cstdint>
#include <ostream>
#include <random>
#include <string>
#include <vector>

namespace {

struct SmallState {
    std::vector<int> books;
    int n;

    explicit SmallState(int n_) : n(n_) {
        books.reserve(n);
        for (int i = 1; i <= n; ++i) {
            books.push_back(i);
        }
    }

    int find_pos(int book) const {
        for (int i = 0; i < n; ++i) {
            if (books[i] == book) {
                return i;
            }
        }
        return -1;
    }

    void top(int book) {
        int pos = find_pos(book);
        if (pos < 0) {
            return;
        }
        int val = books[pos];
        books.erase(books.begin() + pos);
        books.insert(books.begin(), val);
    }

    void bottom(int book) {
        int pos = find_pos(book);
        if (pos < 0) {
            return;
        }
        int val = books[pos];
        books.erase(books.begin() + pos);
        books.push_back(val);
    }

    void insert(int book, int t) {
        int pos = find_pos(book);
        if (pos < 0) {
            return;
        }
        int val = books[pos];
        books.erase(books.begin() + pos);
        int new_pos = pos + t;
        if (new_pos < 0) {
            new_pos = 0;
        }
        if (new_pos > n - 1) {
            new_pos = n - 1;
        }
        books.insert(books.begin() + new_pos, val);
    }

    int ask(int book) const {
        return find_pos(book) + 1;
    }

    int query(int k) const {
        if (k < 1 || k > n) {
            return -1;
        }
        return books[k - 1];
    }
};

void emit_small_lower_bound(std::ostream& out) {
    out << "1 0\n";
    out << "1\n";
}

void emit_small_random(unsigned long long seed, std::ostream& out) {
    std::mt19937_64 rng(seed);
    int n = 5;
    int m = 6;
    out << n << " " << m << "\n";
    out << "1 2 3 4 5\n";

    SmallState st(n);

    // Fixed legal skeleton: Top 3, Bottom 1, Insert 4 -1, Insert 2 0, Ask 3, Query 2
    // Seed affects Ask argument and Query argument (both read-only).
    // Ask argument: choose from 1..5 via rng.
    // Query argument: choose from 1..5 via rng.
    // Keep the rest fixed.

    // Operation 1: Top 3
    st.top(3);
    out << "Top 3\n";

    // Operation 2: Bottom 1
    st.bottom(1);
    out << "Bottom 1\n";

    // Operation 3: Insert 4 -1
    st.insert(4, -1);
    out << "Insert 4 -1\n";

    // Operation 4: Insert 2 0
    st.insert(2, 0);
    out << "Insert 2 0\n";

    // Operation 5: Ask (seed-dependent argument, must be 1..5)
    int ask_arg = static_cast<int>(rng() % 5) + 1;
    // Ensure the book exists (it always does, since books are 1..5 and never removed).
    out << "Ask " << ask_arg << "\n";

    // Operation 6: Query (seed-dependent argument, must be 1..5)
    int query_arg = static_cast<int>(rng() % 5) + 1;
    out << "Query " << query_arg << "\n";
}

void emit_large_upper_bound(std::ostream& out) {
    int n = 80000;
    int m = 80000;
    out << n << " " << m << "\n";
    for (int i = 1; i <= n; ++i) {
        if (i > 1) {
            out << " ";
        }
        out << i;
    }
    out << "\n";
    for (int i = 0; i < m; ++i) {
        out << "Ask 1\n";
    }
}

void emit_large_random(unsigned long long seed, std::ostream& out) {
    std::mt19937_64 rng(seed);
    int n = 80000;
    int m = 80000;
    out << n << " " << m << "\n";
    for (int i = 1; i <= n; ++i) {
        if (i > 1) {
            out << " ";
        }
        out << i;
    }
    out << "\n";

    // Blueprint: 40000 Ask operations on book 1, then 40000 Query operations on position 1.
    // Seed changes the Ask argument (book id) and Query argument (position) within legal ranges.
    // To keep the skeleton valid, we use Ask with a book that always exists (1..n) and Query with position 1..n.
    // We'll make the first 40000 Ask operations use a seed-dependent book id in [1, n].
    // The second 40000 Query operations use a seed-dependent position in [1, n].
    // This keeps the skeleton (all Ask then all Query) and uses the seed.

    int ask_book = static_cast<int>(rng() % n) + 1;
    int query_pos = static_cast<int>(rng() % n) + 1;

    for (int i = 0; i < 40000; ++i) {
        out << "Ask " << ask_book << "\n";
    }
    for (int i = 0; i < 40000; ++i) {
        out << "Query " << query_pos << "\n";
    }
}

}  // namespace

void acm_generate_case(unsigned long long seed,
                       const std::string& profile,
                       const std::string& case_kind,
                       std::ostream& out) {
    if (profile == "small" && case_kind == "lower_bound") {
        emit_small_lower_bound(out);
    } else if (profile == "small" && case_kind == "random") {
        emit_small_random(seed, out);
    } else if (profile == "large" && case_kind == "upper_bound") {
        emit_large_upper_bound(out);
    } else if (profile == "large" && case_kind == "random") {
        emit_large_random(seed, out);
    }
}
