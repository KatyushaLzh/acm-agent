#include <bits/stdc++.h>
using namespace std;

static string esc(const string& s) {
    string r;
    for (char c : s) {
        if (c == '"' || c == '\\') { r += '\\'; r += c; }
        else if (c == '\n') r += "\\n";
        else if (c == '\r') r += "\\r";
        else if (c == '\t') r += "\\t";
        else if ((unsigned char)c < 0x20) {
            char buf[8];
            snprintf(buf, sizeof(buf), "\\u%04x", (unsigned char)c);
            r += buf;
        } else r += c;
    }
    return r;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    long long n, m;
    if (!(cin >> n >> m)) {
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
        return 0;
    }
    if (n < 1 || n > 80000 || m < 0 || m > 80000) {
        cerr << "ERR_HEADER 0\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
        return 0;
    }

    vector<int> perm((size_t)n);
    vector<bool> seen((size_t)n + 1, false);
    for (int i = 0; i < (int)n; ++i) {
        int x;
        if (!(cin >> x)) {
            cerr << "ERR_PERM " << i << "\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
            return 0;
        }
        if (x < 1 || x > (int)n || seen[(size_t)x]) {
            cerr << "ERR_PERM " << i << "\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
            return 0;
        }
        seen[(size_t)x] = true;
        perm[(size_t)i] = x;
    }

    list<int> books;
    for (int x : perm) books.push_back(x);
    unordered_map<int, list<int>::iterator> itmap;
    {
        auto it = books.begin();
        for (int x : perm) {
            itmap[x] = it;
            ++it;
        }
    }

    vector<string> tags;
    bool hasTop=false, hasBottom=false, hasInsert=false, hasAsk=false, hasQuery=false;
    bool c4min=false, c4max=false, c5min=false, c5max=false, c6min=false, c6max=false;

    auto addTag = [&](const string& id) {
        if (find(tags.begin(), tags.end(), id) == tags.end()) tags.push_back(id);
    };

    for (long long i = 0; i < m; ++i) {
        string op;
        if (!(cin >> op)) {
            cerr << "ERR_OP " << i << "\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
            return 0;
        }
        if (op == "Top") {
            int s;
            if (!(cin >> s)) {
                cerr << "ERR_ARG " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            if (s < 1 || s > (int)n || itmap.find(s) == itmap.end()) {
                cerr << "ERR_ARG " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            if (s == 1) c4min = true;
            if (s == (int)n) c4max = true;
            auto it = itmap[s];
            books.splice(books.begin(), books, it);
            hasTop = true;
        } else if (op == "Bottom") {
            int s;
            if (!(cin >> s)) {
                cerr << "ERR_ARG " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            if (s < 1 || s > (int)n || itmap.find(s) == itmap.end()) {
                cerr << "ERR_ARG " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            if (s == 1) c4min = true;
            if (s == (int)n) c4max = true;
            auto it = itmap[s];
            books.splice(books.end(), books, it);
            hasBottom = true;
        } else if (op == "Insert") {
            int s, t;
            if (!(cin >> s >> t)) {
                cerr << "ERR_ARG " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            if (s < 1 || s > (int)n || t < -1 || t > 1 || itmap.find(s) == itmap.end()) {
                cerr << "ERR_ARG " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            if (s == 1) c4min = true;
            if (s == (int)n) c4max = true;
            if (t == -1) c6min = true;
            if (t == 1) c6max = true;
            if (t == 0) { c6min = true; c6max = true; }
            auto it = itmap[s];
            if (t == -1) {
                if (it == books.begin()) {
                    cerr << "ERR_LEGAL " << i << "\n";
                    cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                    return 0;
                }
                auto prevIt = prev(it);
                books.splice(prevIt, books, it);
            } else if (t == 1) {
                auto nxt = next(it);
                if (nxt == books.end()) {
                    cerr << "ERR_LEGAL " << i << "\n";
                    cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                    return 0;
                }
                auto target = next(nxt);
                books.splice(target, books, it);
            }
            hasInsert = true;
        } else if (op == "Ask") {
            int s;
            if (!(cin >> s)) {
                cerr << "ERR_ARG " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            if (s < 1 || s > (int)n || itmap.find(s) == itmap.end()) {
                cerr << "ERR_ARG " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            if (s == 1) c4min = true;
            if (s == (int)n) c4max = true;
            hasAsk = true;
        } else if (op == "Query") {
            int k;
            if (!(cin >> k)) {
                cerr << "ERR_ARG " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            if (k < 1 || k > (int)n) {
                cerr << "ERR_ARG " << i << "\n";
                cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
                return 0;
            }
            if (k == 1) c5min = true;
            if (k == (int)n) c5max = true;
            hasQuery = true;
        } else {
            cerr << "ERR_OP " << i << "\n";
            cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
            return 0;
        }
    }

    string extra;
    if (cin >> extra) {
        cerr << "ERR_EXTRA " << m << "\n";
        cout << "{\"valid\":false,\"dimensions\":{},\"coverage_tags\":[],\"records\":0}";
        return 0;
    }

    if (hasTop) addTag("auto_operation_top");
    if (hasBottom) addTag("auto_operation_bottom");
    if (hasInsert) addTag("auto_operation_insert");
    if (hasAsk) addTag("auto_operation_ask");
    if (hasQuery) addTag("auto_operation_query");

    if (n == 1 && m == 0) addTag("auto_c1_minimum");
    if (n == 80000) addTag("auto_c1_maximum");
    if (m == 0) addTag("auto_c2_minimum");
    if (m == 80000) addTag("auto_c2_maximum");
    if (c4min) addTag("auto_c4_minimum");
    if (c4max) addTag("auto_c4_maximum");
    if (c5min) addTag("auto_c5_minimum");
    if (c5max) addTag("auto_c5_maximum");
    if (c6min) addTag("auto_c6_minimum");
    if (c6max) addTag("auto_c6_maximum");

    cout << "{\"valid\":true,\"dimensions\":{\"n\":" << n << ",\"m\":" << m << "},\"coverage_tags\":[";
    for (size_t i = 0; i < tags.size(); ++i) {
        if (i) cout << ",";
        cout << "\"" << esc(tags[i]) << "\"";
    }
    cout << "],\"records\":" << m << "}";
    return 0;
}
