#include <bits/stdc++.h>
using namespace std;

static unsigned long long rng_state;
static unsigned long long rng_next() {
    rng_state ^= rng_state << 7;
    rng_state ^= rng_state >> 9;
    return rng_state;
}

static void emit_small_random(unsigned long long seed, ostream& out) {
    rng_state = seed;
    int n = 5, m = 8;
    out << n << " " << m << "\n";
    out << "1 2 3 4 5\n";

    vector<int> seq = {1,2,3,4,5};

    auto find_pos = [&](int x) -> int {
        for (int i = 0; i < (int)seq.size(); ++i) if (seq[i] == x) return i;
        return -1;
    };

    auto do_top = [&](int s) {
        int p = find_pos(s);
        seq.erase(seq.begin() + p);
        seq.insert(seq.begin(), s);
    };
    auto do_bottom = [&](int s) {
        int p = find_pos(s);
        seq.erase(seq.begin() + p);
        seq.push_back(s);
    };
    auto do_insert = [&](int s, int t) {
        int p = find_pos(s);
        seq.erase(seq.begin() + p);
        int np = p + t;
        if (np < 0) np = 0;
        if (np > (int)seq.size()) np = (int)seq.size();
        seq.insert(seq.begin() + np, s);
    };

    auto ask = [&](int s) -> int {
        return find_pos(s) + 1;
    };
    auto query = [&](int k) -> int {
        return seq[k-1];
    };

    out << "Ask " << ask(1) << "\n";
    out << "Query " << query(1) << "\n";
    out << "Top 3\n"; do_top(3);
    out << "Ask " << ask(3) << "\n";
    out << "Insert 3 -1\n"; do_insert(3, -1);
    out << "Query " << query(2) << "\n";
    out << "Bottom 2\n"; do_bottom(2);
    out << "Query " << query(5) << "\n";
}

static void emit_large_random(unsigned long long seed, ostream& out) {
    rng_state = seed;
    int n = 80000, m = 80000;
    out << n << " " << m << "\n";
    for (int i = 1; i <= n; ++i) {
        if (i > 1) out << " ";
        out << i;
    }
    out << "\n";

    vector<int> top_books(n);
    for (int i = 0; i < n; ++i) top_books[i] = i + 1;
    for (int i = 0; i < 40000; ++i) {
        int idx = (int)(rng_next() % (n - i));
        swap(top_books[i], top_books[i + idx]);
    }

    for (int i = 0; i < 40000; ++i) {
        out << "Top " << top_books[i] << "\n";
    }
    for (int i = 0; i < 40000; ++i) {
        int k = (int)(rng_next() % n) + 1;
        out << "Query " << k << "\n";
    }
}

void acm_generate_case(unsigned long long seed, const string& profile, const string& case_kind, ostream& out) {
    if (profile == "small" && case_kind == "lower_bound") {
        out << "1 0\n1\n";
    } else if (profile == "small" && case_kind == "random") {
        emit_small_random(seed, out);
    } else if (profile == "large" && case_kind == "upper_bound") {
        int n = 80000, m = 80000;
        out << n << " " << m << "\n";
        for (int i = 1; i <= n; ++i) {
            if (i > 1) out << " ";
            out << i;
        }
        out << "\n";
        for (int i = 1; i <= 40000; ++i) {
            out << "Top " << i << "\n";
        }
        for (int i = 1; i <= 40000; ++i) {
            out << "Query " << i << "\n";
        }
    } else if (profile == "large" && case_kind == "random") {
        emit_large_random(seed, out);
    }
}
