#include <bits/stdc++.h>
using namespace std;

static unsigned long long splitmix64(unsigned long long x) {
    x += 0x9e3779b97f4a7c15ULL;
    x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ULL;
    x = (x ^ (x >> 27)) * 0x94d049bb133111ebULL;
    return x ^ (x >> 31);
}

static vector<int> make_permutation(int n, unsigned long long seed) {
    vector<int> p(n);
    iota(p.begin(), p.end(), 1);
    if (seed == 0) return p;
    mt19937_64 rng(seed);
    for (int i = n - 1; i > 0; --i) {
        int j = (int)(rng() % (unsigned long long)(i + 1));
        swap(p[i], p[j]);
    }
    return p;
}

void acm_generate_case(unsigned long long seed, const string& profile, const string& case_kind, ostream& out) {
    if (profile == "small" && case_kind == "lower_bound") {
        out << "1 0\n";
        out << "1\n";
        return;
    }

    if (profile == "small" && case_kind == "random") {
        int n = 5, m = 8;
        vector<int> perm = {1, 2, 3, 4, 5};

        // Fixed legal skeleton from blueprint.
        // We will let seed affect the Query argument (position 1..n).
        // Skeleton: Ask 1, Query ?, Top 3, Ask 3, Insert 3 -1, Query ?, Bottom 2, Query ?
        // The two Query positions are read-only; seed picks them.
        mt19937_64 rng(seed);
        int q1 = (int)(rng() % 5) + 1;
        int q2 = (int)(rng() % 5) + 1;
        int q3 = (int)(rng() % 5) + 1;

        out << n << " " << m << "\n";
        for (int i = 0; i < n; ++i) {
            if (i) out << " ";
            out << perm[i];
        }
        out << "\n";

        // Simulate state as a list of book IDs in current order.
        vector<int> state = perm;
        auto find_pos = [&](int book) {
            for (int i = 0; i < (int)state.size(); ++i) {
                if (state[i] == book) return i;
            }
            return -1;
        };

        // Ask 1: legal, no state change.
        out << "Ask 1\n";

        // Query q1: legal, no state change.
        out << "Query " << q1 << "\n";

        // Top 3: move book 3 to front.
        out << "Top 3\n";
        {
            int pos = find_pos(3);
            state.erase(state.begin() + pos);
            state.insert(state.begin(), 3);
        }

        // Ask 3: legal, no state change.
        out << "Ask 3\n";

        // Insert 3 -1: move book 3 one position toward front.
        out << "Insert 3 -1\n";
        {
            int pos = find_pos(3);
            if (pos > 0) {
                swap(state[pos], state[pos - 1]);
            }
        }

        // Query q2: legal, no state change.
        out << "Query " << q2 << "\n";

        // Bottom 2: move book 2 to back.
        out << "Bottom 2\n";
        {
            int pos = find_pos(2);
            state.erase(state.begin() + pos);
            state.push_back(2);
        }

        // Query q3: legal, no state change.
        out << "Query " << q3 << "\n";
        return;
    }

    if (profile == "large" && case_kind == "upper_bound") {
        int n = 80000, m = 80000;
        out << n << " " << m << "\n";
        for (int i = 1; i <= n; ++i) {
            if (i > 1) out << " ";
            out << i;
        }
        out << "\n";
        // 40000 Top on distinct books 1..40000
        for (int i = 1; i <= 40000; ++i) {
            out << "Top " << i << "\n";
        }
        // 40000 Query on positions 1..40000
        for (int i = 1; i <= 40000; ++i) {
            out << "Query " << i << "\n";
        }
        return;
    }

    if (profile == "large" && case_kind == "random") {
        int n = 80000, m = 80000;
        mt19937_64 rng(seed);

        // Initial permutation: seed-shuffled.
        vector<int> perm(n);
        iota(perm.begin(), perm.end(), 1);
        for (int i = n - 1; i > 0; --i) {
            int j = (int)(rng() % (unsigned long long)(i + 1));
            swap(perm[i], perm[j]);
        }

        out << n << " " << m << "\n";
        for (int i = 0; i < n; ++i) {
            if (i) out << " ";
            out << perm[i];
        }
        out << "\n";

        // 40000 Top operations on distinct books 1..40000.
        // These are always legal regardless of current order.
        for (int i = 1; i <= 40000; ++i) {
            out << "Top " << i << "\n";
        }

        // 40000 Query operations; positions are seed-driven.
        for (int i = 0; i < 40000; ++i) {
            int pos = (int)(rng() % (unsigned long long)n) + 1;
            out << "Query " << pos << "\n";
        }
        return;
    }

    // Unreachable in the harness contract; emit minimal valid input defensively.
    out << "1 0\n1\n";
}
