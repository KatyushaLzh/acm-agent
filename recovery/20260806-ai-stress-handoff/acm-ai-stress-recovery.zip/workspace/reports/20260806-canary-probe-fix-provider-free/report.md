# AI Stress Benchmark Report

## Outcome

| Metric | Value |
|---|---:|
| Attempts | 20 |
| Successes | 20 |
| Success rate | 100.0% |
| First-round success rate | 100.0% |
| Unsafe applies | 0 |
| Successful time p50 / p95 | 43.934 / 53.099 s |
| Successful tokens p50 / p95 | 0.000 / 0.000 |
| Provider requests | 0.000 |
| Retries | 0.000 |

## Failure stages

| Stage | Attempts |
|---|---:|
| none | 0 |

## Repair roles

| Role | Attempts |
|---|---:|
| none | 0 |

## Stage duration percentiles

| Stage | p50 | p95 | max |
|---|---:|---:|---:|
| none | n/a | n/a | n/a |

## Token category percentiles

| Category | p50 | p95 | max |
|---|---:|---:|---:|
| none | n/a | n/a | n/a |
