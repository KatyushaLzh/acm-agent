# ACM / XCPC Agent Profile

This directory is an algorithm-contest workspace. Prefer short standalone C++17 programs, fast iteration, problem-local reasoning, and code that matches the existing style. When inferring style from `2026`, ignore `test.cpp` files; many are copied stress-test/reference solutions rather than the user's normal style.

## Main Priority

- Start from the problem model, invariant, and correctness condition before choosing a template.
- When the user asks to generate ACM/XCPC/ICPC/Codeforces-style C++ solution code, default to using the `xcpc-jiangly-style` skill unless the user explicitly asks for a different style.
- Explain solutions in the order: model -> invariant -> algorithm -> edge cases -> complexity.
- When debugging, first state what each key variable/data structure is supposed to mean, then find where that meaning breaks.
- Think with a Hack mindset: actively look for counterexamples, boundary cases, overflow, stale state across tests, wrong graph direction, off-by-one errors, and invalid greedy assumptions.
- Do not overuse systems or AI-infra analogies. Mention memory layout/cache/SIMD only when performance optimization or performance debugging really depends on it.

## Stress Testing

- If confidence is low or the task is WA/debugging, prefer a local stress test over hand examples only.
- Keep stress tools separate from the submitted source unless asked otherwise.
- Typical files: `sol.cpp`, `bf.cpp`, `gen.cpp`, `check.py`.
- Brute force should follow the answer definition, not a simplified version of the optimized idea.
- Generators should target edge cases: minimum sizes, maximum small sizes, duplicates, sorted/reversed data, sparse/dense graphs, disconnected graphs, extreme weights, modulo/overflow boundaries.
- On mismatch, print failing input, expected output, actual output, and seed; then identify which invariant failed.

## Debug Checklist

- WA: check modeling error, index base, multi-test reset, overflow, compression, graph direction, impossible case, tie-breaking, and non-equivalent optimization.
- RE: check bounds, empty `front/back/top`, recursion depth, uninitialized values, iterator/reference invalidation, and array size.
- TLE/MLE: identify the hot operation or memory owner before micro-optimizing.
- Multi-test reset must cover adjacency lists, edge counters, DSU state, DP arrays, lazy tags, buckets, visited flags, and answer accumulators.

## Agent Safety

- Inspect nearby code before editing and match its style.
- Do not use `test.cpp` as the style source; prefer same-date non-test files or `template.cpp`.
- Do not mass-format unrelated code.
- Do not replace accepted-style compact contest code with library-heavy code.
- If changing an algorithm, state the correctness condition and asymptotic complexity.
- Put tests/examples outside the submitted source unless the user asks otherwise.
